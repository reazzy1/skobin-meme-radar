@echo off
cd /d "%~dp0"
title Install GMGN CLI
where npm >nul 2>&1
if errorlevel 1 (
  echo Node.js/npm not found.
  echo Install Node.js LTS from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)
echo Installing official gmgn-cli...
npm install -g gmgn-cli
if errorlevel 1 (
  echo Installation failed. Try opening Terminal as Administrator.
  pause
  exit /b 1
)
echo.
echo GMGN CLI installed.
echo Next: get an API key at https://gmgn.ai/ai
echo Then open Meme Radar - Settings - GMGN and apply the API key.
echo NEVER paste a private key into the app.
pause
