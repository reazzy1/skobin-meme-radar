# 🚀 Skobin Meme Radar v3 — Pre-Pump Detector

Локальное приложение для поиска ранних Solana-мемкоинов и проверки стратегии **до использования реальных денег**.


## Что нового в v3

Главная задача v3 — не просто найти новый токен, а заметить **ускорение спроса до большого движения**. Для этого радар хранит последовательные замеры и сравнивает:

- прирост holders/min и его ускорение;
- tx/min и ускорение сделок;
- свежую долю buys по дельтам между замерами;
- скорость прироста объёма;
- движение market cap примерно за последнюю минуту;
- GMGN net buy, smart-money/KOL и launch risk;
- Top10 / dev / snipers / bundlers / insiders / wash trading.

`PRE-PUMP` — ранний алгоритмический сигнал ускорения. Это не обещание будущего роста. `ENTRY` требует более сильного подтверждения.

Автоматические виртуальные тесты по PRE-PUMP и ENTRY закрываются на одинаковом горизонте (по умолчанию 60 минут), а Strategy Lab сравнивает долю 2x за 15/60 минут, 5x и средний пик.

## Что внутри

Приложение работает как полноценный локальный радар:

**Discovery → WATCH → PRE-PUMP → confirmed ENTRY → paper/test tracking → Strategy Lab**

### Источники

**DEX Screener fallback**
- свежие token profiles;
- boosts;
- community takeovers;
- market cap;
- liquidity;
- 5m volume;
- buys/sells;
- price change.

**GMGN — рекомендуемый режим**
- `market trenches`: new creation / near completion / completed;
- `market trending`;
- `market signal`: Smart Money Buy + KOL Buy;
- `token security`;
- smart-money holders;
- анализ сохранённых кошельков.

GMGN используется **только для query**. Приложение не просит и не хранит private key.

## Экраны

### Обзор
Показывает:
- сколько токенов сейчас в радаре;
- последние ENTRY;
- paper PnL;
- win rate;
- топ кандидатов;
- свежие сигналы.

### Радар
Сортирует токены по score и показывает:
- stage: NEW / WATCH / ENTRY / AVOID / COOLDOWN;
- MC;
- liquidity;
- volume 5m;
- buy share;
- 5m price change;
- GMGN security;
- тип сетапа;
- локальный график market cap;
- объяснение, почему score получился таким.

### Сигналы
Хранит всю историю:
- WATCH;
- ENTRY;
- TP1 / TP2 / TP3;
- TRAIL;
- STOP;
- TIME_EXIT.

### Paper Trading
На каждый ENTRY виртуально открывает позицию (по умолчанию $10).

Модель по умолчанию:
- stop: −20%;
- TP1: +35%, фиксируется 25%;
- TP2: +75%, ещё 25%;
- TP3: +150%, ещё 25%;
- остаток ведётся trailing;
- trailing включается после +50%;
- выход при откате 18% от максимума;
- time exit, если позиция долго не развивается;
- в PnL дополнительно заложены настраиваемые simulated costs на вход/выход.

Это позволяет проверить **expectancy**, а не судить стратегию по одному красивому x10.

### Анализ токена
Вставляешь CA → получаешь текущие рыночные метрики, score и GMGN security (если настроен).

### Кошельки
Можно сохранять адреса интересных трейдеров и через GMGN смотреть:
- wallet stats;
- 7d PnL;
- последние сделки.

## Как работает score

Score — это **не прогноз цены**. Это ранжирование по заранее понятным факторам:

- возраст;
- market cap;
- liquidity/MC;
- 5m volume/MC;
- доля покупок;
- число транзакций;
- контролируемый, а не вертикальный 5m momentum;
- наличие socials;
- GMGN Smart Money/KOL signal;
- pattern `pump → pullback → rebound`;
- GMGN security.

Бот специально штрафует монеты, которые уже летят почти вертикально, чтобы не превращать сигнал в покупку вершины.

## Два типа ENTRY

### EARLY_MOMENTUM
Для очень молодых токенов. Нужны одновременно:
- ранний возраст;
- достаточные liquidity и volume;
- заметный перевес buyers;
- рост уже начался, но 5m движение ещё не стало экстремальным;
- высокий общий score;
- отсутствие GMGN hard stop, если security доступен.

### RECLAIM
Более консервативный вариант:
1. был первый импульс;
2. произошёл откат;
3. минимум удержался;
4. покупатели вернулись;
5. цена начала rebound.

Идея — не угадывать самое дно, а входить после подтверждения спроса.

## GMGN hard stops

При доступном `token security` приложение помечает токен `AVOID`, если находит критические признаки, включая:
- mint authority не renounced;
- freeze authority не renounced;
- `rug_ratio > 30%`;
- `sell_tax > 10%`;
- `top10_holder_rate > 60%`;
- honeypot.

Также учитываются предупреждения по dev/insider/bundler/sniper концентрации.

Пороговые значения вынесены из официального workflow GMGN и могут со временем требовать пересмотра.

## Установка Windows

### 1. Python
Нужен Python 3.11+ с включённым **Add Python to PATH**.

### 2. Запуск
Дважды кликни:

`start.bat`

Он:
1. создаст `.venv`;
2. установит зависимости;
3. запустит scanner engine;
4. откроет Streamlit dashboard на `127.0.0.1:8501`.

Чтобы остановить фоновый scanner:

`stop.bat`

## GMGN setup

Это сильно улучшает приложение.

1. Установи Node.js LTS.
2. Запусти `install_gmgn.bat`.
3. Получи GMGN API key: `https://gmgn.ai/ai`
4. В интерфейсе открой `Настройки → GMGN`.
5. Вставь **API key**.
6. Нажми `Применить API key`.
7. Нажми `Проверить GMGN`.

**Не вставляй private key.** Для функций этого приложения он не нужен.

Официальный CLI:
`npm install -g gmgn-cli`

## Telegram

1. Создай своего бота через `@BotFather`.
2. Отправь ему `/start`.
3. Получи свой `chat_id`.
4. В приложении открой `Настройки → Telegram`.
5. Вставь Bot token + Chat ID.
6. Нажми `Тестовое сообщение`.

По умолчанию Telegram присылает ENTRY и события выхода. WATCH можно включить в `config.json`, если хочешь больше уведомлений.

## Настройки

Основные параметры редактируются прямо в приложении.

Полный набор лежит в `config.json`.

В том числе можно менять:
- min/max MC;
- min liquidity;
- min volume;
- WATCH score;
- ENTRY score;
- paper stake;
- stop;
- trailing;
- estimated costs;
- требовать ли обязательный GMGN Security PASS.

## Важные ограничения

1. Ни один фильтр не знает заранее, какая монета сделает x10.
2. Даже хороший on-chain профиль не гарантирует рост.
3. DEX Screener fallback — не полный firehose всех новых Pump.fun-токенов. Для раннего поиска лучше GMGN Trenches.
4. Market cap — удобная аппроксимация изменения paper-позиции, но реальная продажа зависит от liquidity, price impact и slippage.
5. Paper costs — оценка, а не фактическая комиссия конкретной сделки.
6. Сначала накопи нормальную выборку paper-сделок. 5–10 сделок ничего не доказывают.
7. Приложение специально не торгует реальными деньгами.

## Структура проекта

```text
skobin_meme_radar/
├─ app.py                  # dashboard
├─ engine.py               # scanner
├─ config.json             # стратегия
├─ requirements.txt
├─ start.bat
├─ stop.bat
├─ install_gmgn.bat
├─ QUICK_START.txt
├─ core/
│  ├─ config.py
│  ├─ db.py
│  ├─ dexscreener.py
│  ├─ gmgn.py
│  ├─ paper.py
│  ├─ strategy.py
│  ├─ telegram.py
│  └─ utils.py
└─ data/
   └─ radar.db             # создаётся автоматически
```

## Официальные источники API

- DEX Screener API: https://docs.dexscreener.com/api/reference
- GMGN Agent API: https://docs.gmgn.ai/index/gmgn-agent-api
- GMGN CLI: https://github.com/GMGNAI/gmgn-skills
- Telegram Bot API: https://core.telegram.org/bots/api

## v2.1 fix

Исправлен запуск после распаковки: папка `data/` теперь создаётся автоматически перед открытием SQLite. Это устраняет `sqlite3.OperationalError: unable to open database file` на чистой установке.


## v2.8.0 — Test Bets

Добавлен отдельный режим виртуальных тест-ставок. В Радаре можно выбрать найденную монету, указать любую сумму в долларах и нажать «Запустить тест». Приложение запоминает цену/market cap входа и продолжает отслеживать монету в фоне, даже когда она становится старше окна Fresh/Crowd. Раздел «Тест-ставки» показывает текущую виртуальную стоимость, PnL, лучший и худший момент. По умолчанию на каждый ENTRY автоматически открывается тест на $10; сумму и авто-режим можно изменить в Настройках. Реальные сделки не совершаются.
