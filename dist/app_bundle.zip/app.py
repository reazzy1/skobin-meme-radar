
from __future__ import annotations
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
from streamlit_autorefresh import st_autorefresh

from core.config import load_config, save_config, write_env_values, env_value
from core.db import init_db, connect, get_runtime, add_watchlist, remove_watchlist, add_wallet, remove_wallet
from core.utils import fmt_usd, dt_text, json_loads, now_ts
from core import gmgn
from core.dexscreener import fetch_one
from core.strategy import market_score, assess
from core.telegram import send as tg_send, get_me
from core.paper import portfolio_stats

ROOT = Path(__file__).resolve().parent
init_db()

st.set_page_config(
    page_title="Skobin Meme Radar",
    page_icon="📡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
:root { --accent:#25E0A3; }
.block-container {padding-top: 1.25rem; padding-bottom: 2rem;}
[data-testid="stSidebar"] {border-right: 1px solid rgba(255,255,255,.08);}
.hero {
  padding: 18px 22px; border:1px solid rgba(255,255,255,.10); border-radius:18px;
  background: linear-gradient(135deg, rgba(37,224,163,.10), rgba(80,96,255,.06));
  margin-bottom: 14px;
}
.hero h1 {margin:0 0 6px 0; font-size:30px;}
.muted {opacity:.68}
.good {color:#25E0A3;font-weight:700}
.warn {color:#f4c95d;font-weight:700}
.bad {color:#ff5f75;font-weight:700}
.small {font-size:13px; opacity:.75}
div[data-testid="stMetric"] {
  border:1px solid rgba(255,255,255,.08); border-radius:14px; padding:12px 14px;
  background:rgba(255,255,255,.025);
}
[data-testid="stDataFrame"] {border-radius:14px; overflow:hidden;}
hr {border-color:rgba(255,255,255,.08);}
</style>
""", unsafe_allow_html=True)

def qdf(sql, params=()):
    con = connect()
    try:
        return pd.read_sql_query(sql, con, params=params)
    finally:
        con.close()

def qrow(sql, params=()):
    con = connect()
    row = con.execute(sql, params).fetchone()
    con.close()
    return dict(row) if row else None

def stage_icon(stage):
    return {
        "ENTRY":"🟢 ENTRY","WATCH":"🟡 WATCH","AVOID":"🔴 AVOID",
        "COOLDOWN":"⚪ COOLDOWN","DISCOVERED":"⚫ NEW"
    }.get(stage, stage or "—")

def engine_info():
    hb = get_runtime("heartbeat")
    status = get_runtime("engine_status")
    age = None
    if hb:
        try: age = now_ts() - int(hb["value"])
        except Exception: pass
    online = age is not None and age < 90
    return online, age, status["value"] if status else "unknown"

def start_engine():
    pid_file = ROOT / "data" / "engine.pid"
    online, _, _ = engine_info()
    if online:
        return True, "Engine уже работает"
    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    try:
        subprocess.Popen([sys.executable, str(ROOT/"engine.py")], cwd=str(ROOT), **kwargs)
        time.sleep(1)
        return True, "Engine запущен"
    except Exception as e:
        return False, str(e)

cfg = load_config()

with st.sidebar:
    st.markdown("## 📡 Skobin Meme Radar")
    st.caption("Ранний поиск Solana-мемкоинов")
    page = st.radio(
        "Раздел",
        ["Обзор","Радар","Сигналы","Paper Trading","Анализ токена","Кошельки","Настройки"],
        label_visibility="collapsed"
    )
    st.divider()
    online, hb_age, eng_status = engine_info()
    if online:
        st.markdown("🟢 **Scanner online**")
        st.caption(f"heartbeat {hb_age} сек. назад")
    else:
        st.markdown("🔴 **Scanner offline**")
        if st.button("▶ Запустить scanner", use_container_width=True):
            ok,msg = start_engine()
            st.toast(msg, icon="✅" if ok else "❌")
            time.sleep(1); st.rerun()
    gmgn_ok, gmgn_msg = gmgn.check_config() if gmgn.installed() else (False, "не установлен")
    st.markdown(("🟢" if gmgn_ok else "🟡") + " **GMGN:** " + ("готов" if gmgn_ok else "fallback"))
    st.caption("GMGN даёт Trenches + safety + smart money. Без него работает DEX Screener fallback.")
    auto = st.toggle("Автообновление", value=True)
    if auto:
        st_autorefresh(interval=10_000, key="radar_refresh")

if page == "Обзор":
    st.markdown("""
    <div class="hero">
      <h1>📡 Meme Radar</h1>
      <div class="muted">Ищет ранние токены → WATCH → подтверждение → ENTRY → paper TP/STOP/TRAIL.</div>
    </div>
    """, unsafe_allow_html=True)

    ps = portfolio_stats()
    candidates = qrow("SELECT COUNT(*) n FROM tokens WHERE last_seen_ts>?", (now_ts()-300,))
    entries_today = qrow("SELECT COUNT(*) n FROM signals WHERE kind='ENTRY' AND ts>?", (now_ts()-86400,))
    c1,c2,c3,c4,c5 = st.columns(5)
    c1.metric("Токенов сейчас", int((candidates or {}).get("n",0)))
    c2.metric("ENTRY за 24ч", int((entries_today or {}).get("n",0)))
    c3.metric("Paper PnL", f"${ps['pnl']:+.2f}")
    c4.metric("Закрытых сделок", ps["closed"])
    c5.metric("Win rate", f"{ps['win_rate']*100:.0f}%" if ps["closed"] else "—")

    st.subheader("Лучшие кандидаты прямо сейчас")
    df = qdf("""
        SELECT symbol,stage,score,market_cap,liquidity,volume_m5,buys_m5,sells_m5,
               price_change_m5,security_status,setup_type,token,last_seen_ts
        FROM tokens
        WHERE last_seen_ts>?
        ORDER BY score DESC LIMIT 15
    """, (now_ts()-300,))
    if df.empty:
        st.info("Пока нет данных. Запусти scanner и дай ему 1–3 минуты накопить историю.")
    else:
        df["Статус"] = df["stage"].map(stage_icon)
        df["MC"] = df["market_cap"].map(fmt_usd)
        df["Liq"] = df["liquidity"].map(fmt_usd)
        df["Vol 5m"] = df["volume_m5"].map(fmt_usd)
        df["Buy %"] = (df["buys_m5"]/(df["buys_m5"]+df["sells_m5"]).clip(lower=1)*100).round(0)
        shown = df[["symbol","Статус","score","MC","Liq","Vol 5m","Buy %","price_change_m5","security_status","setup_type"]]
        shown.columns = ["Token","Статус","Score","MC","Liquidity","Volume 5m","Buy %","5m %","Security","Setup"]
        st.dataframe(shown, use_container_width=True, hide_index=True)

    st.subheader("Последние сигналы")
    sig = qdf("SELECT ts,symbol,kind,market_cap,score,title FROM signals ORDER BY ts DESC LIMIT 12")
    if not sig.empty:
        sig["Время"] = sig["ts"].map(dt_text)
        sig["MC"] = sig["market_cap"].map(fmt_usd)
        st.dataframe(sig[["Время","symbol","kind","MC","score","title"]],
                     use_container_width=True, hide_index=True)
    else:
        st.caption("Сигналов пока нет.")

    st.info(
        "Главная идея: бот не пытается угадать абсолютное дно. Он ищет ранний спрос, "
        "отбрасывает слабые токены и ждёт либо ранний контролируемый momentum, либо pump → pullback → rebound. "
        "Реальные деньги приложение не трогает — сначала оно собирает paper-статистику."
    )

elif page == "Радар":
    st.title("📡 Радар")
    c1,c2,c3,c4 = st.columns(4)
    min_score = c1.slider("Минимальный score", 0, 100, 45)
    stage_filter = c2.multiselect("Статус", ["DISCOVERED","WATCH","ENTRY","AVOID","COOLDOWN"],
                                  default=["DISCOVERED","WATCH","ENTRY"])
    max_mc = c3.number_input("MC до, $", 10_000, 5_000_000, 500_000, step=10_000)
    fresh = c4.selectbox("Свежесть", ["5 минут","15 минут","1 час"], index=1)
    fresh_sec = {"5 минут":300,"15 минут":900,"1 час":3600}[fresh]

    placeholders = ",".join(["?"]*len(stage_filter)) if stage_filter else "''"
    params = [now_ts()-fresh_sec, min_score, max_mc] + stage_filter
    sql = f"""
    SELECT symbol,name,stage,score,market_cap,liquidity,volume_m5,buys_m5,sells_m5,
           price_change_m5,security_status,setup_type,token,url,last_seen_ts
    FROM tokens
    WHERE last_seen_ts>=? AND score>=? AND market_cap<=?
      {"AND stage IN ("+placeholders+")" if stage_filter else ""}
    ORDER BY score DESC, market_cap ASC
    LIMIT 200
    """
    df = qdf(sql, tuple(params))
    if df.empty:
        st.warning("Под текущие фильтры ничего нет.")
    else:
        df["Статус"] = df["stage"].map(stage_icon)
        df["MC"] = df["market_cap"].map(fmt_usd)
        df["Liq"] = df["liquidity"].map(fmt_usd)
        df["Vol5"] = df["volume_m5"].map(fmt_usd)
        df["Buy %"] = (df["buys_m5"]/(df["buys_m5"]+df["sells_m5"]).clip(lower=1)*100).round(0)
        view = df[["symbol","Статус","score","MC","Liq","Vol5","Buy %","price_change_m5","security_status","setup_type"]]
        view.columns = ["Token","Статус","Score","MC","Liq","Vol 5m","Buy %","5m %","Security","Setup"]
        st.dataframe(view, use_container_width=True, hide_index=True, height=410)

        options = {f"{r.symbol} — {r.token[:8]}… | score {r.score:.0f}": r.token for r in df.itertuples()}
        chosen_label = st.selectbox("Разобрать токен", list(options.keys()))
        token = options[chosen_label]
        row = df[df["token"]==token].iloc[0].to_dict()
        ass_row = qrow("SELECT assessment_json FROM tokens WHERE token=?", (token,))
        ass = json_loads((ass_row or {}).get("assessment_json"), {})

        left,right = st.columns([1.5,1])
        with left:
            hist = qdf("SELECT ts,market_cap,liquidity,volume_m5 FROM snapshots WHERE token=? ORDER BY ts", (token,))
            if not hist.empty:
                hist["Время"] = pd.to_datetime(hist["ts"], unit="s")
                fig = px.line(hist, x="Время", y="market_cap", title=f"{row['symbol']} — Market Cap")
                fig.update_layout(height=350, margin=dict(l=10,r=10,t=45,b=10))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.caption("История ещё не накоплена.")
        with right:
            st.metric("Score", f"{row['score']:.0f}/100")
            st.metric("Market Cap", fmt_usd(row["market_cap"]))
            st.metric("Liquidity", fmt_usd(row["liquidity"]))
            st.metric("5m Volume", fmt_usd(row["volume_m5"]))
            if row.get("url"):
                st.link_button("Открыть график DEX Screener ↗", row["url"], use_container_width=True)
            if st.button("⭐ Добавить в ручной watchlist", use_container_width=True):
                add_watchlist(token, row["symbol"]); st.toast("Добавлено")

        if ass:
            st.markdown("#### Почему такой score")
            market = ass.get("market",{})
            col1,col2 = st.columns(2)
            with col1:
                st.write("**Плюсы / факторы:**")
                for x in market.get("reasons",[]): st.write("•", x)
            with col2:
                st.write("**Ограничения:**")
                hard = market.get("hard_reasons",[])
                if hard:
                    for x in hard: st.write("•", x)
                else: st.write("• базовые market-фильтры пройдены")
                sec = ass.get("security",{})
                st.write("• Security:", sec.get("status","UNKNOWN"))
                for x in sec.get("warnings",[]): st.write("• ⚠️", x)
                for x in sec.get("hard_stops",[]): st.write("• 🛑", x)

elif page == "Сигналы":
    st.title("🔔 Сигналы")
    kinds = st.multiselect("Тип", ["WATCH","ENTRY","TP1","TP2","TP3","TRAIL","STOP","TIME_EXIT"],
                           default=["ENTRY","TP1","TP2","TP3","TRAIL","STOP"])
    if kinds:
        ph = ",".join(["?"]*len(kinds))
        sig = qdf(f"SELECT * FROM signals WHERE kind IN ({ph}) ORDER BY ts DESC LIMIT 300", tuple(kinds))
    else:
        sig = qdf("SELECT * FROM signals ORDER BY ts DESC LIMIT 300")
    if sig.empty:
        st.info("Сигналов пока нет.")
    else:
        sig["Время"] = sig["ts"].map(dt_text)
        sig["MC"] = sig["market_cap"].map(fmt_usd)
        st.dataframe(sig[["Время","symbol","kind","MC","score","title"]],
                     use_container_width=True, hide_index=True, height=420)
        labels = {f"#{r.id} {r.symbol} {r.kind} — {dt_text(r.ts)}": r.id for r in sig.itertuples()}
        sid = labels[st.selectbox("Открыть сигнал", list(labels.keys()))]
        row = sig[sig["id"]==sid].iloc[0]
        st.code(row["message"], language=None)

elif page == "Paper Trading":
    st.title("🧪 Paper Trading")
    ps = portfolio_stats()
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Сделок", ps["trades"])
    c2.metric("Открыто", ps["open"])
    c3.metric("Win rate", f"{ps['win_rate']*100:.1f}%" if ps["closed"] else "—")
    c4.metric("Итоговый PnL", f"${ps['pnl']:+.2f}",
              delta=f"{(ps['pnl']/ps['invested']*100):+.1f}%" if ps["invested"] else None)

    trades = qdf("SELECT * FROM paper_trades ORDER BY id DESC")
    if trades.empty:
        st.info("Когда появится ENTRY, бот автоматически откроет виртуальную сделку. Реальные деньги не используются.")
    else:
        open_df = trades[trades["status"]=="OPEN"].copy()
        closed_df = trades[trades["status"]=="CLOSED"].copy()
        st.subheader("Открытые")
        if open_df.empty:
            st.caption("Нет открытых paper-позиций.")
        else:
            open_df["Entry MC"] = open_df["entry_mc"].map(fmt_usd)
            open_df["Current MC"] = open_df["current_mc"].map(fmt_usd)
            open_df["PnL %"] = (open_df["pnl_pct"].fillna(0)*100).round(1)
            open_df["PnL $"] = open_df["pnl_usd"].fillna(0).round(2)
            open_df["Остаток %"] = (open_df["remaining_fraction"]*100).round(0)
            st.dataframe(open_df[["symbol","Entry MC","Current MC","PnL %","PnL $","Остаток %","tp1_done","tp2_done","tp3_done"]],
                         use_container_width=True, hide_index=True)

        st.subheader("Закрытые")
        if not closed_df.empty:
            closed_df["Entry"] = closed_df["entry_mc"].map(fmt_usd)
            closed_df["Exit"] = closed_df["exit_mc"].map(fmt_usd)
            closed_df["PnL %"] = (closed_df["pnl_pct"].fillna(0)*100).round(1)
            closed_df["PnL $"] = closed_df["pnl_usd"].fillna(0).round(2)
            closed_df["Вход"] = closed_df["entry_ts"].map(dt_text)
            st.dataframe(closed_df[["symbol","Вход","Entry","Exit","exit_reason","PnL %","PnL $"]],
                         use_container_width=True, hide_index=True, height=350)
        csv = trades.to_csv(index=False).encode("utf-8-sig")
        st.download_button("Скачать журнал CSV", csv, "paper_trades.csv", "text/csv")

    p = cfg["paper"]
    st.caption(
        f"Текущая paper-модель: ${p['stake_usd']} на ENTRY; stop −{p['stop_loss_pct']*100:.0f}%; "
        f"TP1 +{p['tp1_pct']*100:.0f}%, TP2 +{p['tp2_pct']*100:.0f}%, TP3 +{p['tp3_pct']*100:.0f}%; "
        f"trailing после +{p['trailing_start_pct']*100:.0f}% с откатом {p['trailing_drawdown_pct']*100:.0f}%; "
        f"в симуляции заложено ~{p.get('estimated_entry_cost_pct',0)*100:.1f}% на вход и "
        f"~{p.get('estimated_exit_cost_pct',0)*100:.1f}% на выход как оценка комиссий/slippage."
    )

elif page == "Анализ токена":
    st.title("🔎 Анализ токена")
    token = st.text_input("Solana CA", placeholder="Вставь contract address")
    c1,c2,c3 = st.columns(3)
    if c1.button("Проверить сейчас", type="primary", use_container_width=True, disabled=not token.strip()):
        with st.spinner("Получаю данные…"):
            try:
                p = fetch_one(token.strip())
                if not p:
                    st.error("DEX Screener пока не видит этот токен.")
                else:
                    hist = qdf("SELECT * FROM snapshots WHERE token=? ORDER BY ts", (token.strip(),)).to_dict("records")
                    sec = None
                    if gmgn_ok:
                        try:
                            sec_raw = gmgn.token_security(token.strip(), cfg["gmgn"].get("chain","sol"))
                            sec = gmgn.evaluate_security(sec_raw)
                        except Exception as e:
                            st.warning("GMGN security не удалось получить: "+str(e))
                    a = assess(p.to_dict(), hist, cfg, sec)
                    st.session_state["manual_analysis"] = (p.to_dict(), a)
            except Exception as e:
                st.error(str(e))
    if c2.button("⭐ В watchlist", use_container_width=True, disabled=not token.strip()):
        add_watchlist(token.strip(), "")
        st.toast("Добавлено. Scanner будет держать CA в наблюдении.")
    if c3.button("Убрать из watchlist", use_container_width=True, disabled=not token.strip()):
        remove_watchlist(token.strip()); st.toast("Убрано")

    if "manual_analysis" in st.session_state:
        p,a = st.session_state["manual_analysis"]
        st.subheader(f"{p['symbol']} — {p['name']}")
        cc = st.columns(5)
        cc[0].metric("Score", f"{a['score']:.0f}/100")
        cc[1].metric("MC", fmt_usd(p["market_cap"]))
        cc[2].metric("Liquidity", fmt_usd(p["liquidity"]))
        cc[3].metric("5m volume", fmt_usd(p["volume_m5"]))
        cc[4].metric("5m", f"{p['price_change_m5']:+.1f}%")
        if a["entry"]:
            st.success(f"ENTRY SETUP: {a['entry_type']} — алгоритмическое подтверждение есть.")
        elif a["watch"]:
            st.warning("WATCH — интересно, но подтверждения ENTRY пока нет.")
        else:
            st.info("Сейчас стратегия не видит качественного сетапа.")
        st.json(a, expanded=False)
        if p.get("url"): st.link_button("DEX Screener ↗", p["url"])

elif page == "Кошельки":
    st.title("👛 Кошельки")
    st.caption("Можно сохранить интересные адреса и через GMGN смотреть их stats / PnL / последние сделки.")
    wcol1,wcol2 = st.columns([3,1])
    wallet = wcol1.text_input("Solana wallet")
    label = wcol2.text_input("Метка", placeholder="smart 1")
    if st.button("Добавить кошелёк", disabled=not wallet.strip()):
        add_wallet(wallet.strip(), label); st.toast("Сохранено")

    wallets = qdf("SELECT * FROM wallets ORDER BY added_ts DESC")
    if not wallets.empty:
        st.dataframe(wallets[["label","wallet"]], use_container_width=True, hide_index=True)
        opts = {f"{r.label or 'wallet'} — {r.wallet[:8]}…": r.wallet for r in wallets.itertuples()}
        chosen = opts[st.selectbox("Выбери адрес", list(opts.keys()))]
        a,b,c = st.columns(3)
        if a.button("7d PnL", use_container_width=True):
            if not gmgn_ok: st.error("Сначала настрой GMGN.")
            else:
                with st.spinner("GMGN…"):
                    try: st.session_state["wallet_data"] = gmgn.wallet_profits(chosen, period="7d")
                    except Exception as e: st.error(str(e))
        if b.button("Stats", use_container_width=True):
            if not gmgn_ok: st.error("Сначала настрой GMGN.")
            else:
                with st.spinner("GMGN…"):
                    try: st.session_state["wallet_data"] = gmgn.wallet_stats(chosen)
                    except Exception as e: st.error(str(e))
        if c.button("Последние сделки", use_container_width=True):
            if not gmgn_ok: st.error("Сначала настрой GMGN.")
            else:
                with st.spinner("GMGN…"):
                    try: st.session_state["wallet_data"] = gmgn.wallet_activity(chosen, limit=20)
                    except Exception as e: st.error(str(e))
        if "wallet_data" in st.session_state:
            st.json(st.session_state["wallet_data"], expanded=True)

elif page == "Настройки":
    st.title("⚙️ Настройки")

    with st.expander("1. Стратегия и фильтры", expanded=True):
        f = cfg["filters"]; s = cfg["strategy"]; p = cfg["paper"]
        a,b,c = st.columns(3)
        min_mc = a.number_input("Min MC $", 1_000, 2_000_000, int(f["min_market_cap"]), step=1_000)
        max_mc2 = b.number_input("Max MC $", 10_000, 10_000_000, int(f["max_market_cap"]), step=10_000)
        min_liq = c.number_input("Min liquidity $", 1_000, 1_000_000, int(f["min_liquidity_usd"]), step=1_000)
        a,b,c = st.columns(3)
        min_vol = a.number_input("Min 5m volume $", 0, 1_000_000, int(f["min_volume_5m"]), step=500)
        watch_score = b.slider("WATCH score", 0, 100, int(s["watch_score"]))
        entry_score = c.slider("ENTRY score", 0, 100, int(s["entry_score"]))
        a,b,c = st.columns(3)
        stake = a.number_input("Paper stake $", 1.0, 1000.0, float(p["stake_usd"]), step=1.0)
        stop = b.slider("Stop %", 5, 60, int(p["stop_loss_pct"]*100))
        trail = c.slider("Trailing drawdown %", 5, 50, int(p["trailing_drawdown_pct"]*100))
        a,b = st.columns(2)
        entry_cost = a.number_input("Оценка cost на вход, %", 0.0, 20.0, float(p.get("estimated_entry_cost_pct",0.015))*100, step=0.1)
        exit_cost = b.number_input("Оценка cost на выход, %", 0.0, 20.0, float(p.get("estimated_exit_cost_pct",0.015))*100, step=0.1)
        require_sec = st.toggle("Требовать GMGN Security PASS для ENTRY", value=bool(s["require_gmgn_security_for_entry"]))
        if st.button("Сохранить стратегию", type="primary"):
            cfg["filters"]["min_market_cap"] = min_mc
            cfg["filters"]["max_market_cap"] = max_mc2
            cfg["filters"]["min_liquidity_usd"] = min_liq
            cfg["filters"]["min_volume_5m"] = min_vol
            cfg["strategy"]["watch_score"] = watch_score
            cfg["strategy"]["entry_score"] = entry_score
            cfg["strategy"]["require_gmgn_security_for_entry"] = require_sec
            cfg["paper"]["stake_usd"] = stake
            cfg["paper"]["stop_loss_pct"] = stop/100
            cfg["paper"]["trailing_drawdown_pct"] = trail/100
            cfg["paper"]["estimated_entry_cost_pct"] = entry_cost/100
            cfg["paper"]["estimated_exit_cost_pct"] = exit_cost/100
            save_config(cfg)
            st.success("Сохранено. Engine подхватит настройки на следующем цикле.")

    with st.expander("2. Telegram"):
        st.write("Создай бота у @BotFather, напиши ему `/start`, затем укажи bot token и свой chat_id.")
        tg_token = st.text_input("Bot token", value=env_value("TELEGRAM_BOT_TOKEN"), type="password")
        tg_chat = st.text_input("Chat ID", value=env_value("TELEGRAM_CHAT_ID"))
        a,b = st.columns(2)
        if a.button("Сохранить Telegram", use_container_width=True):
            write_env_values({"TELEGRAM_BOT_TOKEN":tg_token, "TELEGRAM_CHAT_ID":tg_chat})
            st.success("Сохранено локально в .env")
        if b.button("Тестовое сообщение", use_container_width=True):
            write_env_values({"TELEGRAM_BOT_TOKEN":tg_token, "TELEGRAM_CHAT_ID":tg_chat})
            ok,msg = tg_send("✅ Skobin Meme Radar: Telegram настроен.")
            st.success("Отправлено") if ok else st.error(str(msg))

    with st.expander("3. GMGN — рекомендуемый режим", expanded=not gmgn_ok):
        st.write(
            "GMGN заметно улучшает ранний поиск: Trenches/Trending, security, holders и smart money. "
            "Приложение использует только query-функции и не просит private key."
        )
        st.write("Статус:", "🟢 готов" if gmgn_ok else "🟡 "+str(gmgn_msg))
        if not gmgn.installed():
            st.code("npm install -g gmgn-cli", language="bash")
            st.caption("Можно просто запустить файл install_gmgn.bat из папки приложения.")
        api_key = st.text_input("GMGN API Key", type="password", placeholder="Вставь только API key, не private key")
        a,b = st.columns(2)
        if a.button("Применить API key", disabled=not api_key.strip(), use_container_width=True):
            ok,msg = gmgn.apply_api_key(api_key)
            st.success(msg or "GMGN настроен") if ok else st.error(msg)
        if b.button("Проверить GMGN", use_container_width=True):
            ok,msg = gmgn.check_config()
            st.success(msg or "GMGN готов") if ok else st.error(msg)

    with st.expander("4. Диагностика"):
        summary = get_runtime("last_cycle_summary")
        if summary:
            st.json(json_loads(summary["value"], {}))
        logs = qdf("SELECT ts,level,message FROM logs ORDER BY id DESC LIMIT 100")
        if not logs.empty:
            logs["Время"] = logs["ts"].map(dt_text)
            st.dataframe(logs[["Время","level","message"]], use_container_width=True, hide_index=True)

    st.warning(
        "Не подключай seed-фразу или private key к этому приложению. Эта версия специально не совершает реальные сделки. "
        "Сначала собери хотя бы несколько десятков paper-сделок и оцени результат после комиссий/slippage."
    )

    st.divider()
    st.markdown("### Завершение")
    if st.button("⏹ Остановить локальный scanner", use_container_width=True):
        pid_file = ROOT / "data" / "engine.pid"
        try:
            if pid_file.exists():
                pid = pid_file.read_text(encoding="utf-8").strip()
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", pid, "/T", "/F"], capture_output=True)
                else:
                    os.kill(int(pid), 15)
                pid_file.unlink(missing_ok=True)
            st.success("Scanner остановлен.")
        except Exception as e:
            st.error(f"Не удалось остановить scanner: {e}")
