from __future__ import annotations

import base64
import os
import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

from desktop_app_v28 import *
from desktop_app_v28 import MemeRadarApp as BaseMemeRadarApp
from core import gmgn
from core.db import get_runtime
from core.utils import now_ts

ICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAACkUlEQVR42u1bsU7DMBBtrGwwwELXdMnerTsDfwArG8oXdGNFER8QsXWFP2CoWJnIngG6dmJhh8mViRz7bN/ZceOTkCrh2n7P753PbpKdnF38ziYcbDbxSAQkAhIBiYBEwJQj9zFI2dbgtt1y7ZWAjKoQMgEdkgxUAjBA+yYDhQAIcAgA135+ru8On09fnvwQMDRpjBWD9i0C74eOCIY9wW65RpPrUF+YVrNSwBDwELvJx8On9nsqFbBYwFONk7uAN5kQVqLkbbBsALaADXiXSZr0r7IBSRLUTa5sa+cVgvSBYQmQAsSJQMDbTNj2e1WzP3x+fLvHrwNMpI+VICH9iMDF2K42RmMqCXABT1EI8T5V4E3HZxi+pwAv66dsayn4pprPmmqOuw1Ck5hJfnAhYWjVh4CXbQ2aT059eMFOdCrw3XJtPKcc25+2RPE2kGQnet01GIVXMVRSNXsr8OJcIGMzCtCQ06L4Zyt5jHI497XyqrZifX/5fqsEbuNzcgtgbItVs9eCp7itIr8Wh4LXFTZU1WceCjQ0y8v2c0wbePldQLZqMrmLkqe8YfZqARvwPiOIArarzT8SQgAPpoC+zzGruigIEBOa6dn9aCzgcqt0NBZwIcuGoK/dLg4CTMFBCOLgZSSwMYPHyA+v5zdKJbDYwLvmh0VRjD8HQFde166/+n3woyKAg4EcsTkwmaf7bXSRxfKssAqYuLJlW2vbBK8DsBJaP7FdfT+DfB+VAkwlbQJ+9IWQTvY6cFFXglDPL4rCSvpRKMAkmXES+P+h6hhtDpBtcTJQrj/NjVYBfbA68Ed5GlTJGevckMX20hT2U2psyuCjqgSpHsKI8oUJzHvELL04OfFIBCQCEgGJgEnHH/8YcrzWmBZdAAAAAElFTkSuQmCC"

class MemeRadarApp(BaseMemeRadarApp):
    def __init__(self):
        super().__init__()
        self.title(f"Skobin Meme Radar 2.9.1")
        try:
            self._new_icon = tk.PhotoImage(data=ICON_B64)
            self.iconphoto(True, self._new_icon)
        except Exception:
            pass
        self.update_status()

    def ensure_engine(self):
        hb=get_runtime("heartbeat")
        alive=False
        if hb:
            try:
                alive=now_ts()-int(hb["value"])<90
            except Exception:
                pass

        # The updater removes engine.pid when it stops the scanner. Do not trust
        # a stale heartbeat if the process marker is already gone.
        if alive and PID_FILE.exists():
            return

        try:
            PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        cmd=[str(Path(sys.executable)),str(ROOT/"engine.py")]
        kw={"cwd":str(ROOT)}
        if os.name=="nt":
            kw["creationflags"]=0x08000000
        try:
            subprocess.Popen(cmd,**kw)
            if hasattr(self,"engine_status"):
                self.engine_status.config(text="● Scanner запускается…",fg=YELLOW)
        except Exception as e:
            if hasattr(self,"engine_status"):
                self.engine_status.config(text="● Scanner ошибка запуска",fg=RED)
            messagebox.showerror("Scanner",str(e))

    def tick(self):
        try:
            self.ensure_engine()
            self.update_status()
            self.refresh_current()
            while True:
                try:
                    fn,args=self.jobq.get_nowait()
                    fn(*args)
                except queue.Empty:
                    break
        finally:
            self.after(7000,self.tick)

    def _build(self):
        super()._build()
        self.feed_detail = tk.Label(
            self.status_box,
            text="",
            bg="#0d131a",
            fg=MUTED,
            font=("Segoe UI", 8),
            justify="left",
            wraplength=185,
        )
        self.feed_detail.pack(anchor="w", pady=(3, 0))

    def update_status(self):
        super().update_status()
        if not gmgn.installed():
            ok = False
            msg = "gmgn-cli не установлен"
        else:
            ok, raw = gmgn.check_config()
            msg = "New Creation feed активен" if ok else (raw or "API key / config не готов")
        self.gmgn_status.config(
            text="● GMGN " + ("New Creation" if ok else "НЕ ГОТОВ"),
            fg=GREEN if ok else RED,
        )
        if hasattr(self, "feed_detail"):
            self.feed_detail.config(
                text=("Ищем новые токены + holders" if ok else "DEX fallback неполный: Crowd WATCH/ENTRY почти не будет. Настройки → GMGN."),
                fg=GREEN if ok else YELLOW,
            )
        if hasattr(self, "gmgn_info"):
            self.gmgn_info.config(
                text=("🟢 " + msg if ok else "🔴 " + str(msg)[:180]),
                fg=GREEN if ok else RED,
            )

if __name__ == "__main__":
    MemeRadarApp().mainloop()
