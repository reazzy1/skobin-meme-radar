SKOBIN MEME RADAR DESKTOP

Это версия с обычным Windows-окном. Chrome/браузер не используется для интерфейса.

Запуск: Skobin_Meme_Radar_Desktop.exe

На первом запуске EXE создаёт внутреннюю папку в %LOCALAPPDATA%\SkobinMemeRadarDesktop, создаёт Python-окружение и устанавливает requests.
Следующие запуски намного быстрее.

Scanner работает в фоне даже если закрыть окно приложения. Остановить его можно: Настройки -> Остановить scanner.

GMGN опционален, но рекомендуется. Private key приложению не нужен.
\nAXIOM:\n- В Радаре выбери монету и нажми «Открыть в Axiom».\n- Двойной клик по монете в Радаре или Обзоре тоже открывает Axiom.\n- В «Анализ токена» есть отдельная кнопка Axiom.\n

V3 PRE-PUMP:
- Radar prioritizes crowd acceleration, not just raw holder count.
- PRE-PUMP and ENTRY get separate automatic virtual tests.
- Strategy Lab compares fixed-horizon results.
- Full early-token mode requires GMGN New Creation to be ready.
