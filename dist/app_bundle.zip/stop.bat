@echo off
cd /d "%~dp0"
if exist "data\engine.pid" (
  set /p PID=<"data\engine.pid"
  echo Stopping scanner PID %PID%...
  taskkill /PID %PID% /T /F >nul 2>&1
  del /q "data\engine.pid" >nul 2>&1
) else (
  echo Scanner PID file not found.
)
pause
