from __future__ import annotations
import json
import os
import queue
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

from core.config import load_config, save_config, write_env_values, env_value
from core.db import init_db, connect, get_runtime, add_watchlist, remove_watchlist, add_wallet, remove_wallet
from core.utils import fmt_usd, dt_text, json_loads, now_ts, age_minutes
from core import gmgn
from core import updater
from core.dexscreener import fetch_one
from core.strategy import assess
from core.telegram import send as tg_send
from core.paper import portfolio_stats
from core.test_bets import open_test_bet, close_test_bet, stats as test_bet_stats

ROOT = Path(__file__).resolve().parent
APP_VERSION = os.environ.get('MEME_RADAR_PAYLOAD_VERSION', updater.current_version())
LAUNCHER_PATH = os.environ.get('MEME_RADAR_LAUNCHER_PATH', '')
DATA = ROOT / 'data'
DATA.mkdir(parents=True, exist_ok=True)
PID_FILE = DATA / 'engine.pid'

BG = '#0b1016'
PANEL = '#111820'
PANEL2 = '#151e27'
BORDER = '#24313d'
TEXT = '#eaf0f6'
MUTED = '#8e9aa6'
GREEN = '#31df9f'
YELLOW = '#f1c75b'
RED = '#ff667d'
BLUE = '#74a7ff'
PURPLE = '#a78bfa'

def axiom_url(token: str) -> str:
    # Current Axiom direct-token route. Solana contract address is sufficient.
    return f"https://axiom.trade/t/{token}?chain=sol"

class MemeRadarApp(tk.Tk):
    def __init__(self):
        super().__init__()
        init_db()
        self.title(f'Skobin Meme Radar {updater.current_version()}')
        self.geometry('1420x880')
        self.minsize(1100, 720)
        self.configure(bg=BG)
        self.protocol('WM_DELETE_WINDOW', self.on_close)
        self.jobq = queue.Queue()
        self.cfg = load_config()
        self.selected_token = None
        self._style()
        self._build()
        self.ensure_engine()
        self.after(500, self.tick)
        self.after(200, self.refresh_current)
        self.after(1600, self.auto_update_check)

    def _style(self):
        s = ttk.Style(self)
        try: s.theme_use('clam')
        except: pass
        s.configure('.', background=BG, foreground=TEXT, fieldbackground=PANEL2, bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER, font=('Segoe UI', 10))
        s.configure('TFrame', background=BG)
        s.configure('Panel.TFrame', background=PANEL)
        s.configure('TLabel', background=BG, foreground=TEXT)
        s.configure('Muted.TLabel', background=BG, foreground=MUTED)
        s.configure('Title.TLabel', background=BG, foreground=TEXT, font=('Segoe UI Semibold', 22))
        s.configure('Header.TLabel', background=BG, foreground=TEXT, font=('Segoe UI Semibold', 14))
        s.configure('CardTitle.TLabel', background=PANEL, foreground=MUTED, font=('Segoe UI', 9))
        s.configure('CardValue.TLabel', background=PANEL, foreground=TEXT, font=('Segoe UI Semibold', 18))
        s.configure('TButton', background=PANEL2, foreground=TEXT, padding=(10,7), borderwidth=1)
        s.map('TButton', background=[('active','#1d2934')])
        s.configure('Accent.TButton', background=GREEN, foreground='#07120e', font=('Segoe UI Semibold',10))
        s.map('Accent.TButton', background=[('active','#57e7b7')])
        s.configure('Danger.TButton', background='#3b1720', foreground='#ff93a3')
        s.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=30,
                    bordercolor=BORDER, borderwidth=0)
        s.configure('Treeview.Heading', background=PANEL2, foreground=MUTED, relief='flat', font=('Segoe UI Semibold',9))
        s.map('Treeview', background=[('selected','#1d3b36')], foreground=[('selected',TEXT)])
        s.configure('TNotebook', background=BG, borderwidth=0)
        s.configure('TNotebook.Tab', background=PANEL, foreground=MUTED, padding=(14,8))
        s.map('TNotebook.Tab', background=[('selected',PANEL2)], foreground=[('selected',TEXT)])
        s.configure('TEntry', fieldbackground=PANEL2, foreground=TEXT, insertcolor=TEXT, bordercolor=BORDER, padding=6)
        s.configure('TCombobox', fieldbackground=PANEL2, foreground=TEXT, padding=5)
        s.configure('TCheckbutton', background=BG, foreground=TEXT)
        s.configure('Vertical.TScrollbar', background=PANEL2, troughcolor=BG, arrowcolor=MUTED)

    def _build(self):
        self.sidebar = tk.Frame(self, bg='#0d131a', width=220)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg='#0d131a')
        brand.pack(fill='x', padx=18, pady=(18,12))
        tk.Label(brand, text='📡', bg='#0d131a', fg=GREEN, font=('Segoe UI Emoji',22)).pack(side='left')
        tk.Label(brand, text=' Skobin\n Meme Radar', justify='left', bg='#0d131a', fg=TEXT,
                 font=('Segoe UI Semibold',13)).pack(side='left')
        self.nav_buttons = {}
        navs = [('overview','Обзор','⌂'),('radar','Радар','◉'),('signals','Сигналы','🔔'),
                ('paper','Paper Trading','◫'),('bets','Тест-ставки','🧪'),('token','Анализ токена','⌕'),('wallets','Кошельки','◈'),('settings','Настройки','⚙')]
        for key,label,icon in navs:
            b = tk.Button(self.sidebar, text=f'  {icon}  {label}', anchor='w', relief='flat', bd=0,
                          bg='#0d131a', fg=MUTED, activebackground=PANEL2, activeforeground=TEXT,
                          font=('Segoe UI',10), padx=14, pady=10,
                          command=lambda k=key:self.show_page(k))
            b.pack(fill='x', padx=8, pady=2)
            self.nav_buttons[key]=b
        self.status_box = tk.Frame(self.sidebar,bg='#0d131a')
        self.status_box.pack(side='bottom',fill='x',padx=15,pady=15)
        self.engine_status = tk.Label(self.status_box,text='● Scanner…',bg='#0d131a',fg=YELLOW,font=('Segoe UI Semibold',9))
        self.engine_status.pack(anchor='w')
        self.gmgn_status = tk.Label(self.status_box,text='● GMGN…',bg='#0d131a',fg=MUTED,font=('Segoe UI',9))
        self.gmgn_status.pack(anchor='w',pady=(5,0))
        tk.Label(self.status_box,text=f'v{APP_VERSION} · auto-update',bg='#0d131a',fg='#61707d',font=('Segoe UI',8)).pack(anchor='w',pady=(8,0))

        self.main = tk.Frame(self,bg=BG)
        self.main.pack(side='left',fill='both',expand=True)
        self.pages = {}
        for key in ['overview','radar','signals','paper','bets','token','wallets','settings']:
            f=tk.Frame(self.main,bg=BG)
            self.pages[key]=f
        self._build_overview(); self._build_radar(); self._build_signals(); self._build_paper(); self._build_bets(); self._build_token(); self._build_wallets(); self._build_settings()
        self.show_page('overview')

    def show_page(self,key):
        for f in self.pages.values(): f.pack_forget()
        self.pages[key].pack(fill='both',expand=True)
        for k,b in self.nav_buttons.items():
            b.configure(bg=PANEL2 if k==key else '#0d131a', fg=TEXT if k==key else MUTED)
        self.current_page=key
        self.refresh_current()

    def title_block(self,parent,title,subtitle=''):
        box=tk.Frame(parent,bg=BG); box.pack(fill='x',padx=26,pady=(22,12))
        tk.Label(box,text=title,bg=BG,fg=TEXT,font=('Segoe UI Semibold',22)).pack(anchor='w')
        if subtitle: tk.Label(box,text=subtitle,bg=BG,fg=MUTED,font=('Segoe UI',9)).pack(anchor='w',pady=(4,0))
        return box

    def card(self,parent,title):
        f=tk.Frame(parent,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        tk.Label(f,text=title,bg=PANEL,fg=MUTED,font=('Segoe UI',9)).pack(anchor='w',padx=14,pady=(10,2))
        v=tk.Label(f,text='—',bg=PANEL,fg=TEXT,font=('Segoe UI Semibold',18))
        v.pack(anchor='w',padx=14,pady=(0,10))
        return f,v

    def tree(self,parent,cols,widths=None,height=12):
        wrap=tk.Frame(parent,bg=BG)
        tree=ttk.Treeview(wrap,columns=cols,show='headings',height=height)
        for i,c in enumerate(cols):
            tree.heading(c,text=c)
            tree.column(c,width=(widths[i] if widths else 110),anchor='w')
        sb=ttk.Scrollbar(wrap,orient='vertical',command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side='left',fill='both',expand=True); sb.pack(side='right',fill='y')
        return wrap,tree

    def _build_overview(self):
        p=self.pages['overview']; self.title_block(p,'🔥 Crowd Launch Radar','Ищет монеты как на Axiom: созданы секунды назад, низкий MC и быстро набирают много holders/сделок.')
        cards=tk.Frame(p,bg=BG); cards.pack(fill='x',padx=26,pady=(0,14))
        self.ov_cards=[]
        for t in ['Токенов сейчас','ENTRY за 24ч','Paper PnL','Закрытых сделок','Win rate']:
            f,v=self.card(cards,t); f.pack(side='left',fill='x',expand=True,padx=(0,10)); self.ov_cards.append(v)
        tk.Label(p,text='Лучшие кандидаты сейчас',bg=BG,fg=TEXT,font=('Segoe UI Semibold',14)).pack(anchor='w',padx=26,pady=(6,8))
        w,self.ov_tree=self.tree(p,['Token','Возраст','Holders','H/min','Tx/min','Статус','Score','MC','Buy %','Security','Setup'],
                                 [85,65,70,65,65,100,60,85,60,80,115],12)
        w.pack(fill='both',expand=True,padx=26,pady=(0,12))
        self.ov_tree.bind('<Double-1>',self.open_overview_axiom)
        tk.Label(p,text='Последние сигналы',bg=BG,fg=TEXT,font=('Segoe UI Semibold',14)).pack(anchor='w',padx=26,pady=(2,8))
        w,self.ov_sig=self.tree(p,['Время','Token','Тип','MC','Score','Событие'],[120,90,90,100,70,240],6)
        w.pack(fill='x',padx=26,pady=(0,24))

    def _build_radar(self):
        p=self.pages['radar']; self.title_block(p,'◉ Crowd Launches','Только новые токены до 5 минут с растущей толпой. Двойной клик открывает Axiom.')
        filt=tk.Frame(p,bg=BG); filt.pack(fill='x',padx=26,pady=(0,10))
        tk.Label(filt,text='Min score',bg=BG,fg=MUTED).pack(side='left')
        self.radar_min=tk.IntVar(value=45)
        tk.Scale(filt,from_=0,to=100,orient='horizontal',variable=self.radar_min,bg=BG,fg=TEXT,
                 troughcolor=PANEL2,highlightthickness=0,length=180,command=lambda _=None:self.refresh_radar()).pack(side='left',padx=8)
        ttk.Button(filt,text='Обновить',command=self.refresh_radar).pack(side='right')
        w,self.radar_tree=self.tree(p,['Token','Возраст','Holders','H/min','Tx/min','Статус','Score','MC','Buy %','Security','Setup'],
                                    [85,65,70,65,65,100,60,85,60,80,115],15)
        w.pack(fill='both',expand=True,padx=26,pady=(0,10))
        self.radar_tree.bind('<<TreeviewSelect>>',self.on_radar_select)
        self.radar_tree.bind('<Double-1>',lambda e:self.open_selected_axiom())
        bottom=tk.Frame(p,bg=BG); bottom.pack(fill='x',padx=26,pady=(0,22))
        self.radar_detail=tk.Text(bottom,height=8,bg=PANEL,fg=TEXT,insertbackground=TEXT,relief='flat',wrap='word',padx=12,pady=10)
        self.radar_detail.pack(side='left',fill='both',expand=True)
        actions=tk.Frame(bottom,bg=BG); actions.pack(side='right',fill='y',padx=(12,0))
        ttk.Button(actions,text='⭐ В watchlist',command=self.add_selected_watch).pack(fill='x',pady=(0,6))
        tk.Label(actions,text='Тестовая сумма, $',bg=BG,fg=MUTED).pack(anchor='w',pady=(8,2))
        self.quick_bet_amount=tk.StringVar(value=str(self.cfg.get('test_bets',{}).get('default_stake_usd',10)))
        ttk.Entry(actions,textvariable=self.quick_bet_amount,width=13).pack(fill='x',pady=(0,6))
        ttk.Button(actions,text='🧪 Запустить тест',command=self.open_selected_test_bet).pack(fill='x',pady=(0,6))
        ttk.Button(actions,text='↗ Открыть в Axiom',style='Accent.TButton',command=self.open_selected_axiom).pack(fill='x')

    def _build_signals(self):
        p=self.pages['signals']; self.title_block(p,'🔔 Сигналы','История WATCH / ENTRY / TP / STOP / TRAIL.')
        w,self.sig_tree=self.tree(p,['Время','Token','Тип','MC','Score','Событие'],[130,100,90,105,70,340],18)
        w.pack(fill='both',expand=True,padx=26,pady=(0,12))
        self.sig_tree.bind('<<TreeviewSelect>>',self.on_signal_select)
        self.sig_tree.bind('<Double-1>',self.open_signal_axiom)
        self.sig_detail=tk.Text(p,height=9,bg=PANEL,fg=TEXT,relief='flat',wrap='word',padx=12,pady=10)
        self.sig_detail.pack(fill='x',padx=26,pady=(0,24))

    def _build_paper(self):
        p=self.pages['paper']; self.title_block(p,'◫ Paper Trading','Проверка стратегии на виртуальных сделках до реальных денег.')
        cards=tk.Frame(p,bg=BG); cards.pack(fill='x',padx=26,pady=(0,14))
        self.paper_cards=[]
        for t in ['Сделок','Открыто','Win rate','Итоговый PnL']:
            f,v=self.card(cards,t); f.pack(side='left',fill='x',expand=True,padx=(0,10)); self.paper_cards.append(v)
        tk.Label(p,text='Открытые позиции',bg=BG,fg=TEXT,font=('Segoe UI Semibold',14)).pack(anchor='w',padx=26,pady=(4,8))
        w,self.paper_open=self.tree(p,['Token','Entry MC','Current MC','PnL %','PnL $','Остаток','TP1','TP2','TP3'],
                                   [90,105,105,80,80,80,55,55,55],8)
        w.pack(fill='x',padx=26,pady=(0,12))
        tk.Label(p,text='Закрытые',bg=BG,fg=TEXT,font=('Segoe UI Semibold',14)).pack(anchor='w',padx=26,pady=(4,8))
        w,self.paper_closed=self.tree(p,['Token','Вход','Entry','Exit','Причина','PnL %','PnL $'],[90,125,95,95,100,80,80],8)
        w.pack(fill='both',expand=True,padx=26,pady=(0,24))

    def _build_bets(self):
        p=self.pages['bets']; self.title_block(p,'🧪 Тест-ставки','Виртуально ставишь любую сумму на найденную монету и смотришь, во что она превратилась со временем.')
        cards=tk.Frame(p,bg=BG); cards.pack(fill='x',padx=26,pady=(0,14))
        self.bet_cards=[]
        for title in ['Всего тестов','Активно','Поставлено','Сейчас стоит','Общий PnL']:
            f,v=self.card(cards,title); f.pack(side='left',fill='x',expand=True,padx=(0,10)); self.bet_cards.append(v)
        toolbar=tk.Frame(p,bg=BG); toolbar.pack(fill='x',padx=26,pady=(0,8))
        tk.Label(toolbar,text='Двойной клик — открыть монету в Axiom. Выбери строку, чтобы закрыть тест и зафиксировать результат.',bg=BG,fg=MUTED).pack(side='left')
        ttk.Button(toolbar,text='Закрыть выбранный тест',command=self.close_selected_test_bet).pack(side='right')
        w,self.bet_tree=self.tree(p,['Token','Старт','Прошло','Ставка','Было MC','Сейчас MC','Сейчас $','PnL $','PnL %','Макс $','Макс %','Источник'],
                                  [75,115,75,75,90,90,80,75,70,80,70,105],13)
        w.pack(fill='both',expand=True,padx=26,pady=(0,10))
        self.bet_tree.bind('<Double-1>',self.open_test_bet_axiom)
        self.bet_tree.bind('<<TreeviewSelect>>',self.on_test_bet_select)
        self.bet_detail=tk.Text(p,height=8,bg=PANEL,fg=TEXT,relief='flat',wrap='word',padx=12,pady=10)
        self.bet_detail.pack(fill='x',padx=26,pady=(0,24))

    def _build_token(self):
        p=self.pages['token']; self.title_block(p,'⌕ Анализ токена','Вставь Solana CA — получишь текущие метрики, score и safety.')
        row=tk.Frame(p,bg=BG); row.pack(fill='x',padx=26,pady=(0,14))
        self.token_entry=ttk.Entry(row); self.token_entry.pack(side='left',fill='x',expand=True)
        ttk.Button(row,text='Проверить',style='Accent.TButton',command=self.analyze_token).pack(side='left',padx=(8,0))
        ttk.Button(row,text='↗ Axiom',command=self.open_manual_axiom).pack(side='left',padx=(8,0))
        ttk.Button(row,text='⭐ Watch',command=lambda:self.add_manual_watch()).pack(side='left',padx=(8,0))
        self.token_result=tk.Text(p,bg=PANEL,fg=TEXT,relief='flat',wrap='word',padx=14,pady=12)
        self.token_result.pack(fill='both',expand=True,padx=26,pady=(0,24))

    def _build_wallets(self):
        p=self.pages['wallets']; self.title_block(p,'◈ Кошельки','Сохраняй интересные адреса и смотри GMGN stats / PnL / activity.')
        row=tk.Frame(p,bg=BG); row.pack(fill='x',padx=26,pady=(0,10))
        self.wallet_entry=ttk.Entry(row); self.wallet_entry.pack(side='left',fill='x',expand=True)
        self.wallet_label=ttk.Entry(row,width=18); self.wallet_label.pack(side='left',padx=(8,0))
        ttk.Button(row,text='Добавить',command=self.add_wallet_ui).pack(side='left',padx=(8,0))
        w,self.wallet_tree=self.tree(p,['Метка','Wallet'],[160,650],8); w.pack(fill='x',padx=26,pady=(0,10))
        self.wallet_tree.bind('<<TreeviewSelect>>',lambda e:None)
        act=tk.Frame(p,bg=BG); act.pack(fill='x',padx=26,pady=(0,8))
        for text,mode in [('7d PnL','profits'),('Stats','stats'),('Последние сделки','activity')]:
            ttk.Button(act,text=text,command=lambda m=mode:self.wallet_query(m)).pack(side='left',padx=(0,8))
        self.wallet_result=tk.Text(p,bg=PANEL,fg=TEXT,relief='flat',wrap='word',padx=12,pady=10)
        self.wallet_result.pack(fill='both',expand=True,padx=26,pady=(0,24))

    def _build_settings(self):
        p=self.pages['settings']; self.title_block(p,'⚙ Настройки','Стратегия, Telegram и GMGN.')
        canvas=tk.Canvas(p,bg=BG,highlightthickness=0); sb=ttk.Scrollbar(p,orient='vertical',command=canvas.yview)
        inner=tk.Frame(canvas,bg=BG); inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0),window=inner,anchor='nw'); canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side='left',fill='both',expand=True,padx=(26,0),pady=(0,22)); sb.pack(side='right',fill='y',padx=(0,18),pady=(0,22))

        freshbox=tk.LabelFrame(inner,text=' Fresh Launches ',bg=PANEL,fg=TEXT,highlightbackground=BORDER,padx=12,pady=12)
        freshbox.pack(fill='x',pady=(0,12))
        freshcfg=self.cfg.get('fresh_launches',{})
        self.fresh_enabled=tk.BooleanVar(value=bool(freshcfg.get('enabled',True)))
        ttk.Checkbutton(freshbox,text='Искать только что созданные мемкоины',variable=self.fresh_enabled).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,8))
        self.fresh_age=tk.StringVar(value=str(freshcfg.get('max_age_minutes',5)))
        self.fresh_max_mc=tk.StringVar(value=str(int(freshcfg.get('max_market_cap',80000))))
        self.fresh_min_entry_sec=tk.StringVar(value=str(int(freshcfg.get('min_age_seconds_for_entry',30))))
        tk.Label(freshbox,text='Макс. возраст, мин',bg=PANEL,fg=MUTED).grid(row=1,column=0,sticky='w')
        ttk.Entry(freshbox,textvariable=self.fresh_age,width=10).grid(row=1,column=1,sticky='w',padx=(6,20))
        tk.Label(freshbox,text='Макс. MC, $',bg=PANEL,fg=MUTED).grid(row=1,column=2,sticky='w')
        ttk.Entry(freshbox,textvariable=self.fresh_max_mc,width=12).grid(row=1,column=3,sticky='w',padx=6)
        tk.Label(freshbox,text='Не давать ENTRY раньше, сек',bg=PANEL,fg=MUTED).grid(row=2,column=0,sticky='w',pady=(8,0))
        ttk.Entry(freshbox,textvariable=self.fresh_min_entry_sec,width=10).grid(row=2,column=1,sticky='w',padx=(6,20),pady=(8,0))
        tk.Label(freshbox,text='GMGN New Creation + safe preset. WATCH может появиться почти сразу, ENTRY ждёт минимальное подтверждение спроса.',bg=PANEL,fg=YELLOW,wraplength=760,justify='left').grid(row=3,column=0,columnspan=4,sticky='w',pady=(10,0))

        crowdbox=tk.LabelFrame(inner,text=' Crowd Detector — много людей ',bg=PANEL,fg=TEXT,highlightbackground=BORDER,padx=12,pady=12)
        crowdbox.pack(fill='x',pady=(0,12))
        cc=self.cfg.get('crowd_launches',{})
        self.crowd_enabled=tk.BooleanVar(value=bool(cc.get('enabled',True)))
        self.crowd_watch=tk.StringVar(value=str(int(cc.get('min_holders_watch',30))))
        self.crowd_entry=tk.StringVar(value=str(int(cc.get('min_holders_entry',45))))
        self.crowd_hpm=tk.StringVar(value=str(int(cc.get('min_holders_per_min_entry',12))))
        self.crowd_txpm=tk.StringVar(value=str(int(cc.get('min_tx_per_min_entry',20))))
        ttk.Checkbutton(crowdbox,text='Искать только токены, где быстро появляется много разных holders',variable=self.crowd_enabled).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,8))
        for i,(lab,var) in enumerate([('WATCH от holders',self.crowd_watch),('ENTRY от holders',self.crowd_entry),('Мин holders/min',self.crowd_hpm),('Мин tx/min',self.crowd_txpm)]):
            tk.Label(crowdbox,text=lab,bg=PANEL,fg=MUTED).grid(row=1+i//2,column=(i%2)*2,sticky='w',pady=5)
            ttk.Entry(crowdbox,textvariable=var,width=10).grid(row=1+i//2,column=(i%2)*2+1,sticky='w',padx=(6,24),pady=5)
        tk.Label(crowdbox,text='Пример с твоего скрина: ~49 сек, 76 holders, ~190 buys — такой токен должен подняться в верх радара.',bg=PANEL,fg=GREEN,wraplength=760,justify='left').grid(row=3,column=0,columnspan=4,sticky='w',pady=(8,0))

        sec=tk.LabelFrame(inner,text=' Стратегия ',bg=PANEL,fg=TEXT,highlightbackground=BORDER,padx=12,pady=12)
        sec.pack(fill='x',pady=(0,12))
        f=self.cfg['filters']; s=self.cfg['strategy']; pp=self.cfg['paper']
        self.setvars={
            'min_mc':tk.StringVar(value=str(int(f['min_market_cap']))), 'max_mc':tk.StringVar(value=str(int(f['max_market_cap']))),
            'min_liq':tk.StringVar(value=str(int(f['min_liquidity_usd']))), 'min_vol':tk.StringVar(value=str(int(f['min_volume_5m']))),
            'watch_score':tk.StringVar(value=str(int(s['watch_score']))), 'entry_score':tk.StringVar(value=str(int(s['entry_score']))),
            'stake':tk.StringVar(value=str(pp['stake_usd'])), 'stop':tk.StringVar(value=str(int(pp['stop_loss_pct']*100))),
            'trail':tk.StringVar(value=str(int(pp['trailing_drawdown_pct']*100))),
        }
        fields=[('Min MC $','min_mc'),('Max MC $','max_mc'),('Min liquidity $','min_liq'),('Min 5m volume $','min_vol'),
                ('WATCH score','watch_score'),('ENTRY score','entry_score'),('Paper stake $','stake'),('Stop %','stop'),('Trailing %','trail')]
        for i,(lab,key) in enumerate(fields):
            r=i//3; c=(i%3)*2
            tk.Label(sec,text=lab,bg=PANEL,fg=MUTED).grid(row=r,column=c,sticky='w',padx=(0,6),pady=6)
            ttk.Entry(sec,textvariable=self.setvars[key],width=14).grid(row=r,column=c+1,sticky='w',padx=(0,20),pady=6)
        ttk.Button(sec,text='Сохранить стратегию',style='Accent.TButton',command=self.save_strategy).grid(row=4,column=0,columnspan=6,sticky='w',pady=(10,0))

        testbox=tk.LabelFrame(inner,text=' Тест-ставки ',bg=PANEL,fg=TEXT,padx=12,pady=12); testbox.pack(fill='x',pady=(0,12))
        tb=self.cfg.get('test_bets',{})
        self.test_bet_enabled=tk.BooleanVar(value=bool(tb.get('enabled',True)))
        self.test_bet_auto=tk.BooleanVar(value=bool(tb.get('auto_open_on_entry',True)))
        self.test_bet_default=tk.StringVar(value=str(tb.get('default_stake_usd',10)))
        ttk.Checkbutton(testbox,text='Включить виртуальные тест-ставки',variable=self.test_bet_enabled).grid(row=0,column=0,columnspan=3,sticky='w')
        ttk.Checkbutton(testbox,text='Автоматически ставить тестовую сумму на каждый ENTRY',variable=self.test_bet_auto).grid(row=1,column=0,columnspan=3,sticky='w',pady=(6,8))
        tk.Label(testbox,text='Сумма авто-теста, $',bg=PANEL,fg=MUTED).grid(row=2,column=0,sticky='w')
        ttk.Entry(testbox,textvariable=self.test_bet_default,width=12).grid(row=2,column=1,sticky='w',padx=8)
        tk.Label(testbox,text='Реальные деньги не используются.',bg=PANEL,fg=GREEN).grid(row=2,column=2,sticky='w',padx=8)

        tg=tk.LabelFrame(inner,text=' Telegram ',bg=PANEL,fg=TEXT,padx=12,pady=12); tg.pack(fill='x',pady=(0,12))
        self.tg_token=tk.StringVar(value=env_value('TELEGRAM_BOT_TOKEN')); self.tg_chat=tk.StringVar(value=env_value('TELEGRAM_CHAT_ID'))
        tk.Label(tg,text='Bot token',bg=PANEL,fg=MUTED).grid(row=0,column=0,sticky='w'); ttk.Entry(tg,textvariable=self.tg_token,width=48,show='•').grid(row=0,column=1,sticky='ew',padx=8)
        tk.Label(tg,text='Chat ID',bg=PANEL,fg=MUTED).grid(row=1,column=0,sticky='w',pady=8); ttk.Entry(tg,textvariable=self.tg_chat,width=48).grid(row=1,column=1,sticky='ew',padx=8,pady=8)
        ttk.Button(tg,text='Сохранить',command=self.save_telegram).grid(row=2,column=0,sticky='w'); ttk.Button(tg,text='Тест',command=self.test_telegram).grid(row=2,column=1,sticky='w',padx=8)

        gm=tk.LabelFrame(inner,text=' GMGN ',bg=PANEL,fg=TEXT,padx=12,pady=12); gm.pack(fill='x',pady=(0,12))
        self.gmgn_key=tk.StringVar(); self.gmgn_info=tk.Label(gm,text='Проверяю…',bg=PANEL,fg=MUTED); self.gmgn_info.pack(anchor='w')
        r=tk.Frame(gm,bg=PANEL); r.pack(fill='x',pady=(8,0)); ttk.Entry(r,textvariable=self.gmgn_key,show='•').pack(side='left',fill='x',expand=True); ttk.Button(r,text='Применить API key',command=self.apply_gmgn).pack(side='left',padx=(8,0)); ttk.Button(r,text='Проверить',command=self.check_gmgn).pack(side='left',padx=(8,0))
        tk.Label(gm,text='Private key приложению не нужен.',bg=PANEL,fg=YELLOW).pack(anchor='w',pady=(8,0))

        upd=tk.LabelFrame(inner,text=' Обновления ',bg=PANEL,fg=TEXT,padx=12,pady=12); upd.pack(fill='x',pady=(0,12))
        tk.Label(upd,text=f'Текущая версия: {APP_VERSION}',bg=PANEL,fg=TEXT,font=('Segoe UI Semibold',10)).pack(anchor='w')
        tk.Label(upd,text='При каждом запуске Meme Radar сам проверяет новую версию и обновляет внутренние файлы.',bg=PANEL,fg=MUTED).pack(anchor='w',pady=(4,8))
        ttk.Button(upd,text='Проверить обновления сейчас',command=self.check_updates_now).pack(anchor='w')

        diag=tk.LabelFrame(inner,text=' Управление ',bg=PANEL,fg=TEXT,padx=12,pady=12); diag.pack(fill='x')
        ttk.Button(diag,text='Перезапустить scanner',command=self.restart_engine).pack(side='left')
        ttk.Button(diag,text='Остановить scanner',style='Danger.TButton',command=self.stop_engine).pack(side='left',padx=8)
        ttk.Button(diag,text='Открыть папку данных',command=self.open_data_folder).pack(side='left')

    def ensure_engine(self):
        hb=get_runtime('heartbeat')
        alive=False
        if hb:
            try: alive=now_ts()-int(hb['value'])<90
            except: pass
        if alive: return
        pyw=Path(sys.executable)
        cmd=[str(pyw),str(ROOT/'engine.py')]
        kw={'cwd':str(ROOT)}
        if os.name=='nt':
            kw['creationflags']=0x08000000
        try: subprocess.Popen(cmd,**kw)
        except Exception as e: messagebox.showerror('Scanner',str(e))

    def stop_engine(self):
        try:
            if PID_FILE.exists():
                pid=PID_FILE.read_text(encoding='utf-8').strip()
                if os.name=='nt': subprocess.run(['taskkill','/PID',pid,'/T','/F'],capture_output=True,creationflags=0x08000000)
                else: os.kill(int(pid),15)
                PID_FILE.unlink(missing_ok=True)
            self.engine_status.config(text='● Scanner offline',fg=RED)
        except Exception as e: messagebox.showerror('Scanner',str(e))

    def restart_engine(self): self.stop_engine(); self.after(500,self.ensure_engine)
    def open_data_folder(self):
        if os.name=='nt': os.startfile(str(DATA))
        else: webbrowser.open(DATA.as_uri())

    def tick(self):
        try:
            self.update_status(); self.refresh_current()
            while True:
                try: fn,args=self.jobq.get_nowait(); fn(*args)
                except queue.Empty: break
        finally: self.after(7000,self.tick)

    def update_status(self):
        hb=get_runtime('heartbeat'); age=None
        if hb:
            try: age=now_ts()-int(hb['value'])
            except: pass
        if age is not None and age<90: self.engine_status.config(text=f'● Scanner online · {age}s',fg=GREEN)
        else: self.engine_status.config(text='● Scanner offline',fg=RED)
        ok,msg=gmgn.check_config() if gmgn.installed() else (False,'gmgn-cli не установлен')
        self.gmgn_status.config(text='● GMGN '+('готов' if ok else 'fallback'),fg=GREEN if ok else YELLOW)
        if hasattr(self,'gmgn_info'): self.gmgn_info.config(text=('🟢 GMGN готов' if ok else '🟡 '+str(msg)[:120]),fg=GREEN if ok else YELLOW)

    def refresh_current(self):
        if not hasattr(self,'current_page'): return
        {'overview':self.refresh_overview,'radar':self.refresh_radar,'signals':self.refresh_signals,
         'paper':self.refresh_paper,'bets':self.refresh_test_bets,'wallets':self.refresh_wallets}.get(self.current_page,lambda:None)()

    def rows(self,sql,params=()):
        c=connect(); rr=c.execute(sql,params).fetchall(); c.close(); return [dict(x) for x in rr]
    def row(self,sql,params=()):
        r=self.rows(sql,params); return r[0] if r else None
    def fill_tree(self,tree,rows):
        for x in tree.get_children(): tree.delete(x)
        for iid,vals in rows: tree.insert('', 'end', iid=iid, values=vals)

    def age_text(self, created_ms):
        a=age_minutes(created_ms)
        if a < 1:
            return f"{max(0,int(a*60))}s"
        return f"{a:.1f}m"

    def refresh_overview(self):
        ps=portfolio_stats(); cand=(self.row('SELECT COUNT(*) n FROM tokens WHERE last_seen_ts>?',(now_ts()-300,)) or {'n':0})['n']; ent=(self.row("SELECT COUNT(*) n FROM signals WHERE kind='ENTRY' AND ts>?",(now_ts()-86400,)) or {'n':0})['n']
        vals=[str(cand),str(ent),f"${ps['pnl']:+.2f}",str(ps['closed']),f"{ps['win_rate']*100:.0f}%" if ps['closed'] else '—']
        for l,v in zip(self.ov_cards,vals): l.config(text=v)
        rr=self.rows('SELECT * FROM tokens WHERE last_seen_ts>? ORDER BY score DESC LIMIT 15',(now_ts()-300,))
        out=[]
        for r in rr:
            buy=(r['buys_m5'] or 0)/max(1,(r['buys_m5'] or 0)+(r['sells_m5'] or 0))*100
            out.append((r['token'],[r['symbol'],self.age_text(r.get('created_ms')),int(r.get('holder_count') or 0),f"{r.get('holders_per_min') or 0:.0f}",f"{r.get('tx_per_min') or 0:.0f}",r['stage'],f"{r['score'] or 0:.0f}",fmt_usd(r['market_cap']),f'{buy:.0f}%',r['security_status'],r['setup_type'] or '—']))
        self.fill_tree(self.ov_tree,out)
        ss=self.rows('SELECT * FROM signals ORDER BY ts DESC LIMIT 8')
        self.fill_tree(self.ov_sig,[(str(r['id']),[dt_text(r['ts']),r['symbol'],r['kind'],fmt_usd(r['market_cap']),f"{r['score']:.0f}" if r['score'] is not None else '—',r['title']]) for r in ss])

    def open_overview_axiom(self,_=None):
        sel=self.ov_tree.selection()
        if not sel:return
        webbrowser.open(axiom_url(sel[0]))

    def refresh_radar(self):
        if not hasattr(self,'radar_tree'): return
        fresh=self.cfg.get('fresh_launches',{})
        if fresh.get('enabled',True):
            cutoff_ms=int((time.time()-float(fresh.get('max_age_minutes',12))*60)*1000)
            rr=self.rows('SELECT * FROM tokens WHERE last_seen_ts>? AND score>=? AND created_ms>=? ORDER BY score DESC LIMIT 200',(now_ts()-900,self.radar_min.get(),cutoff_ms))
        else:
            rr=self.rows('SELECT * FROM tokens WHERE last_seen_ts>? AND score>=? ORDER BY score DESC LIMIT 200',(now_ts()-900,self.radar_min.get()))
        out=[]
        for r in rr:
            buy=(r['buys_m5'] or 0)/max(1,(r['buys_m5'] or 0)+(r['sells_m5'] or 0))*100
            out.append((r['token'],[r['symbol'],self.age_text(r.get('created_ms')),int(r.get('holder_count') or 0),f"{r.get('holders_per_min') or 0:.0f}",f"{r.get('tx_per_min') or 0:.0f}",r['stage'],f"{r['score'] or 0:.0f}",fmt_usd(r['market_cap']),f'{buy:.0f}%',r['security_status'],r['setup_type'] or '—']))
        self.fill_tree(self.radar_tree,out)

    def on_radar_select(self,_=None):
        sel=self.radar_tree.selection()
        if not sel:return
        tok=sel[0]; self.selected_token=tok
        r=self.row('SELECT * FROM tokens WHERE token=?',(tok,)); a=json_loads((r or {}).get('assessment_json'),{})
        lines=[f"{r['symbol']}  |  {tok}",f"MC {fmt_usd(r['market_cap'])} · Liquidity {fmt_usd(r['liquidity'])} · 5m volume {fmt_usd(r['volume_m5'])}",f"👥 Holders {int(r.get('holder_count') or 0)} · {r.get('holders_per_min') or 0:.0f}/min · tx {r.get('tx_per_min') or 0:.0f}/min",f"Score {r['score']:.0f}/100 · Stage {r['stage']} · Security {r['security_status']}",""]
        m=a.get('market',{})
        if m.get('reasons'):
            lines.append('Почему интересен:'); lines.extend('  • '+x for x in m['reasons'])
        if m.get('hard_reasons'):
            lines.append('\nЧто мешает ENTRY:'); lines.extend('  • '+x for x in m['hard_reasons'])
        crowd=a.get('crowd',{})
        if crowd.get('enabled'):
            lines.append('\nCrowd detector:')
            lines.append(f"  • holders {crowd.get('holder_count',0)} · {crowd.get('holders_per_min',0):.0f}/min · tx {crowd.get('tx_per_min',0):.0f}/min")
            lines.append('  • '+('✅ crowd ENTRY подтверждён' if crowd.get('entry_ready') else '⏳ пока только наблюдение'))
            for x in crowd.get('risks',[]): lines.append('  🛑 '+x)
        sec=a.get('security',{})
        for x in sec.get('warnings',[]): lines.append('  ⚠ '+x)
        for x in sec.get('hard_stops',[]): lines.append('  🛑 '+x)
        self.radar_detail.delete('1.0','end'); self.radar_detail.insert('1.0','\n'.join(lines))

    def add_selected_watch(self):
        if not self.selected_token:return
        r=self.row('SELECT symbol FROM tokens WHERE token=?',(self.selected_token,)); add_watchlist(self.selected_token,(r or {}).get('symbol','')); messagebox.showinfo('Watchlist','Добавлено')
    def open_selected_axiom(self):
        if not self.selected_token:return
        webbrowser.open(axiom_url(self.selected_token))

    def open_selected_test_bet(self):
        if not self.selected_token:
            messagebox.showwarning('Тест-ставка','Сначала выбери монету в радаре.')
            return
        try:
            amount=float(self.quick_bet_amount.get().replace(',','.'))
            if amount <= 0 or amount > 1000000: raise ValueError
        except Exception:
            messagebox.showerror('Тест-ставка','Укажи нормальную сумму в долларах, например 10 или 25.')
            return
        r=self.row('SELECT * FROM tokens WHERE token=?',(self.selected_token,))
        if not r:
            messagebox.showerror('Тест-ставка','Не нашёл данные выбранной монеты.'); return
        try:
            bet_id=open_test_bet(r['token'],r['symbol'],r['market_cap'],r['price_usd'],amount,
                                 source='MANUAL_RADAR',signal_score=r.get('score'),cfg=self.cfg)
            if bet_id is None:
                messagebox.showinfo('Тест-ставка','На эту монету уже есть активная тестовая ставка.')
            else:
                messagebox.showinfo('Тест-ставка',f"Запущен виртуальный тест на ${amount:.2f} по {r['symbol']} при MC {fmt_usd(r['market_cap'])}.\n\nОн будет обновляться в фоне, даже когда монета исчезнет из списка новых.")
                self.show_page('bets')
        except Exception as e:
            messagebox.showerror('Тест-ставка',str(e))

    def _elapsed_text(self,ts):
        sec=max(0,now_ts()-int(ts or now_ts()))
        if sec<60:return f'{sec}s'
        if sec<3600:return f'{sec//60}m'
        if sec<86400:return f'{sec/3600:.1f}h'
        return f'{sec/86400:.1f}d'

    def refresh_test_bets(self):
        if not hasattr(self,'bet_tree'): return
        s=test_bet_stats()
        vals=[str(s['count']),str(s['active']),f"${s['stake']:.2f}",f"${s['value']:.2f}",f"${s['pnl']:+.2f}"]
        for lab,val in zip(self.bet_cards,vals): lab.config(text=val)
        self.bet_cache={str(r['id']):r for r in s['rows']}
        rows=[]
        for r in s['rows']:
            value=float((r['current_value_usd'] if r['status']=='OPEN' else r['final_value_usd']) or 0)
            pnl=float((r['pnl_usd'] if r['status']=='OPEN' else r['final_pnl_usd']) or 0)
            pct=float((r['pnl_pct'] if r['status']=='OPEN' else r['final_pnl_pct']) or 0)
            rows.append((str(r['id']),[r['symbol'],dt_text(r['entry_ts']),self._elapsed_text(r['entry_ts']),f"${r['stake_usd']:.2f}",fmt_usd(r['entry_mc']),fmt_usd(r['current_mc']),f"${value:.2f}",f"${pnl:+.2f}",f"{pct*100:+.1f}%",f"${float(r['peak_value_usd'] or 0):.2f}",f"{float(r['peak_pnl_pct'] or 0)*100:+.1f}%",r['source']]))
        self.fill_tree(self.bet_tree,rows)

    def on_test_bet_select(self,_=None):
        s=self.bet_tree.selection()
        if not s:return
        r=getattr(self,'bet_cache',{}).get(s[0])
        if not r:return
        value=float((r['current_value_usd'] if r['status']=='OPEN' else r['final_value_usd']) or 0)
        pnl=float((r['pnl_usd'] if r['status']=='OPEN' else r['final_pnl_usd']) or 0)
        pct=float((r['pnl_pct'] if r['status']=='OPEN' else r['final_pnl_pct']) or 0)
        lines=[f"{r['symbol']} · тест #{r['id']} · {r['status']}",f"Виртуально поставлено: ${r['stake_usd']:.2f}",f"Вход: {dt_text(r['entry_ts'])} · MC {fmt_usd(r['entry_mc'])}",f"Сейчас: MC {fmt_usd(r['current_mc'])} · стоимость ${value:.2f}",f"Результат сейчас: ${pnl:+.2f} ({pct*100:+.1f}%)",f"Лучший момент: ${float(r['peak_value_usd'] or 0):.2f} ({float(r['peak_pnl_pct'] or 0)*100:+.1f}%)",f"Худший момент: ${float(r['low_value_usd'] or 0):.2f} ({float(r['low_pnl_pct'] or 0)*100:+.1f}%)",f"Источник: {r['source']}",f"CA: {r['token']}"]
        self.bet_detail.delete('1.0','end'); self.bet_detail.insert('1.0','\n'.join(lines))

    def close_selected_test_bet(self):
        s=self.bet_tree.selection()
        if not s:return
        r=getattr(self,'bet_cache',{}).get(s[0])
        if not r or r.get('status')!='OPEN':
            messagebox.showinfo('Тест-ставка','Эта тестовая ставка уже закрыта.'); return
        if close_test_bet(int(s[0])):
            self.refresh_test_bets(); messagebox.showinfo('Тест-ставка','Результат зафиксирован.')

    def open_test_bet_axiom(self,_=None):
        s=self.bet_tree.selection()
        if not s:return
        r=getattr(self,'bet_cache',{}).get(s[0])
        if r:webbrowser.open(axiom_url(r['token']))

    def refresh_signals(self):
        ss=self.rows('SELECT * FROM signals ORDER BY ts DESC LIMIT 300')
        self.signal_cache={str(r['id']):r for r in ss}
        self.fill_tree(self.sig_tree,[(str(r['id']),[dt_text(r['ts']),r['symbol'],r['kind'],fmt_usd(r['market_cap']),f"{r['score']:.0f}" if r['score'] is not None else '—',r['title']]) for r in ss])
    def open_signal_axiom(self,_=None):
        s=self.sig_tree.selection()
        if not s:return
        r=getattr(self,'signal_cache',{}).get(s[0],{})
        tok=r.get('token')
        if tok:webbrowser.open(axiom_url(tok))

    def on_signal_select(self,_=None):
        s=self.sig_tree.selection();
        if not s:return
        r=self.signal_cache.get(s[0],{}); self.sig_detail.delete('1.0','end'); self.sig_detail.insert('1.0',r.get('message',''))

    def refresh_paper(self):
        ps=portfolio_stats(); vals=[str(ps['trades']),str(ps['open']),f"{ps['win_rate']*100:.1f}%" if ps['closed'] else '—',f"${ps['pnl']:+.2f}"]
        for l,v in zip(self.paper_cards,vals): l.config(text=v)
        op=[]; cl=[]
        for r in ps['rows']:
            if r['status']=='OPEN': op.append((str(r['id']),[r['symbol'],fmt_usd(r['entry_mc']),fmt_usd(r['current_mc']),f"{(r['pnl_pct'] or 0)*100:+.1f}%",f"${r['pnl_usd'] or 0:+.2f}",f"{r['remaining_fraction']*100:.0f}%",r['tp1_done'],r['tp2_done'],r['tp3_done']]))
            else: cl.append((str(r['id']),[r['symbol'],dt_text(r['entry_ts']),fmt_usd(r['entry_mc']),fmt_usd(r['exit_mc']),r['exit_reason'],f"{(r['pnl_pct'] or 0)*100:+.1f}%",f"${r['pnl_usd'] or 0:+.2f}"]))
        self.fill_tree(self.paper_open,op); self.fill_tree(self.paper_closed,cl)

    def analyze_token(self):
        tok=self.token_entry.get().strip()
        if not tok:return
        self.token_result.delete('1.0','end'); self.token_result.insert('1.0','Проверяю…')
        def work():
            try:
                p=fetch_one(tok)
                if not p: raise RuntimeError('DEX Screener пока не видит этот токен')
                hist=self.rows('SELECT * FROM snapshots WHERE token=? ORDER BY ts',(tok,))
                sec=None
                ok,_=gmgn.check_config() if gmgn.installed() else (False,'')
                if ok:
                    try: sec=gmgn.evaluate_security(gmgn.token_security(tok,self.cfg['gmgn'].get('chain','sol')))
                    except: pass
                a=assess(p.to_dict(),hist,self.cfg,sec)
                lines=[f"{p.symbol} — {p.name}",f"CA: {tok}","",f"Score: {a['score']:.0f}/100",f"Market Cap: {fmt_usd(p.market_cap)}",f"Liquidity: {fmt_usd(p.liquidity)}",f"5m volume: {fmt_usd(p.volume_m5)}",f"Buys / sells: {p.buys_m5} / {p.sells_m5}",f"5m move: {p.price_change_m5:+.1f}%",f"Security: {(a.get('security') or {}).get('status','UNKNOWN')}","",'Результат: '+(('ENTRY '+str(a['entry_type'])) if a['entry'] else ('WATCH' if a['watch'] else 'сетапа нет'))]
                self.jobq.put((self.show_token_result,('\n'.join(lines),)))
            except Exception as e: self.jobq.put((self.show_token_result,('Ошибка: '+str(e),)))
        threading.Thread(target=work,daemon=True).start()
    def show_token_result(self,text): self.token_result.delete('1.0','end'); self.token_result.insert('1.0',text)
    def open_manual_axiom(self):
        tok=self.token_entry.get().strip()
        if tok:webbrowser.open(axiom_url(tok))

    def add_manual_watch(self):
        tok=self.token_entry.get().strip();
        if tok:add_watchlist(tok,'manual'); messagebox.showinfo('Watchlist','Добавлено')

    def refresh_wallets(self):
        rr=self.rows('SELECT * FROM wallets ORDER BY added_ts DESC')
        self.fill_tree(self.wallet_tree,[(r['wallet'],[r['label'],r['wallet']]) for r in rr])
    def add_wallet_ui(self):
        w=self.wallet_entry.get().strip();
        if w:add_wallet(w,self.wallet_label.get().strip()); self.refresh_wallets()
    def wallet_query(self,mode):
        s=self.wallet_tree.selection();
        if not s:return
        w=s[0]; self.wallet_result.delete('1.0','end'); self.wallet_result.insert('1.0','GMGN…')
        def work():
            try:
                ok,msg=gmgn.check_config() if gmgn.installed() else (False,'gmgn-cli не установлен')
                if not ok: raise RuntimeError(msg)
                if mode=='profits': data=gmgn.wallet_profits(w,period='7d')
                elif mode=='stats': data=gmgn.wallet_stats(w)
                else:data=gmgn.wallet_activity(w,limit=20)
                txt=json.dumps(data,ensure_ascii=False,indent=2)
            except Exception as e: txt='Ошибка: '+str(e)
            self.jobq.put((self.show_wallet_result,(txt,)))
        threading.Thread(target=work,daemon=True).start()
    def show_wallet_result(self,text): self.wallet_result.delete('1.0','end'); self.wallet_result.insert('1.0',text)

    def save_strategy(self):
        try:
            v=self.setvars; c=self.cfg
            c['filters']['min_market_cap']=float(v['min_mc'].get()); c['filters']['max_market_cap']=float(v['max_mc'].get()); c['filters']['min_liquidity_usd']=float(v['min_liq'].get()); c['filters']['min_volume_5m']=float(v['min_vol'].get()); c['strategy']['watch_score']=float(v['watch_score'].get()); c['strategy']['entry_score']=float(v['entry_score'].get()); c['paper']['stake_usd']=float(v['stake'].get()); c['paper']['stop_loss_pct']=float(v['stop'].get())/100; c['paper']['trailing_drawdown_pct']=float(v['trail'].get())/100
            c.setdefault('fresh_launches',{})['enabled']=bool(self.fresh_enabled.get())
            c['fresh_launches']['max_age_minutes']=float(self.fresh_age.get())
            c['fresh_launches']['max_market_cap']=float(self.fresh_max_mc.get())
            c['fresh_launches']['min_age_seconds_for_entry']=float(self.fresh_min_entry_sec.get())
            c.setdefault('crowd_launches',{})['enabled']=bool(self.crowd_enabled.get())
            c['crowd_launches']['max_age_minutes']=float(self.fresh_age.get())
            c['crowd_launches']['min_holders_watch']=int(float(self.crowd_watch.get()))
            c['crowd_launches']['min_holders_entry']=int(float(self.crowd_entry.get()))
            c['crowd_launches']['min_holders_per_min_entry']=float(self.crowd_hpm.get())
            c['crowd_launches']['min_tx_per_min_entry']=float(self.crowd_txpm.get())
            c.setdefault('test_bets',{})['enabled']=bool(self.test_bet_enabled.get())
            c['test_bets']['auto_open_on_entry']=bool(self.test_bet_auto.get())
            c['test_bets']['default_stake_usd']=float(self.test_bet_default.get())
            if hasattr(self,'quick_bet_amount'):
                self.quick_bet_amount.set(str(c['test_bets']['default_stake_usd']))
            if c['fresh_launches']['enabled']:
                c['filters']['max_age_minutes']=c['fresh_launches']['max_age_minutes']
                c['filters']['max_market_cap']=c['fresh_launches']['max_market_cap']
            save_config(c); self.cfg=load_config(); messagebox.showinfo('Настройки','Сохранено. Перезапусти scanner, чтобы режим discovery применился сразу.')
        except Exception as e: messagebox.showerror('Настройки',str(e))
    def save_telegram(self): write_env_values({'TELEGRAM_BOT_TOKEN':self.tg_token.get().strip(),'TELEGRAM_CHAT_ID':self.tg_chat.get().strip()}); messagebox.showinfo('Telegram','Сохранено')
    def test_telegram(self): self.save_telegram(); ok,msg=tg_send('✅ Skobin Meme Radar: Telegram настроен.'); messagebox.showinfo('Telegram','Сообщение отправлено' if ok else str(msg))
    def apply_gmgn(self):
        k=self.gmgn_key.get().strip(); ok,msg=gmgn.apply_api_key(k); messagebox.showinfo('GMGN',str(msg)) if ok else messagebox.showerror('GMGN',str(msg)); self.update_status()
    def check_gmgn(self):
        ok,msg=gmgn.check_config() if gmgn.installed() else (False,'gmgn-cli не установлен. Для установки нужен Node.js и: npm install -g gmgn-cli')
        messagebox.showinfo('GMGN',str(msg)) if ok else messagebox.showwarning('GMGN',str(msg))

    def check_updates_now(self):
        if not LAUNCHER_PATH or not Path(LAUNCHER_PATH).exists():
            messagebox.showwarning('Обновления','Не удалось определить путь к Meme Radar.exe. Закрой приложение и открой EXE снова — проверка обновлений выполняется при каждом запуске.')
            return
        try:
            self.stop_engine()
            kw={}
            if os.name=='nt': kw['creationflags']=0x08000000
            subprocess.Popen([LAUNCHER_PATH],cwd=str(Path(LAUNCHER_PATH).parent),**kw)
            self.after(250,self.destroy)
        except Exception as e:
            messagebox.showerror('Обновления',str(e))

    def save_update_settings(self):
        self.cfg.setdefault('updates',{})['auto_update']=bool(self.auto_update_var.get())
        self.cfg['updates']['check_on_startup']=True
        save_config(self.cfg)

    def auto_update_check(self):
        if not self.cfg.get('updates',{}).get('check_on_startup',True):
            return
        def work():
            try:
                m=updater.check(timeout=7)
                if m.get('update_available'):
                    self.jobq.put((self._handle_found_update,(m,True)))
            except Exception:
                # Startup checks are silent when offline/GitHub is unavailable.
                pass
        threading.Thread(target=work,daemon=True).start()

    def manual_update_check(self):
        if hasattr(self,'update_hint'):
            self.update_hint.config(text='Проверяю…',fg=YELLOW)
        def work():
            try:
                m=updater.check(timeout=10)
                self.jobq.put((self._manual_update_result,(m,None)))
            except Exception as e:
                self.jobq.put((self._manual_update_result,(None,str(e))))
        threading.Thread(target=work,daemon=True).start()

    def _manual_update_result(self,manifest,error):
        if error:
            if hasattr(self,'update_hint'): self.update_hint.config(text='Ошибка проверки',fg=RED)
            messagebox.showerror('Обновления',error)
            return
        if not manifest.get('update_available'):
            if hasattr(self,'update_hint'): self.update_hint.config(text='Установлена последняя версия',fg=GREEN)
            messagebox.showinfo('Обновления',f"У тебя уже последняя версия {manifest.get('current_version')}")
            return
        self._handle_found_update(manifest,False)

    def _handle_found_update(self,manifest,automatic=False):
        remote=manifest.get('version','?')
        notes=manifest.get('notes','')
        if automatic and self.cfg.get('updates',{}).get('auto_update',True):
            self.begin_update(manifest)
            return
        msg=f"Доступна версия {remote}.\n\n{notes}\n\nУстановить сейчас?"
        if messagebox.askyesno('Доступно обновление',msg):
            self.begin_update(manifest)
        else:
            if hasattr(self,'update_hint'): self.update_hint.config(text=f'Доступна {remote}',fg=YELLOW)

    def begin_update(self,manifest):
        win=tk.Toplevel(self)
        win.title('Обновление Skobin Meme Radar')
        win.geometry('460x180')
        win.resizable(False,False)
        win.configure(bg=BG)
        win.transient(self); win.grab_set()
        tk.Label(win,text=f"Устанавливаю версию {manifest.get('version')}",bg=BG,fg=TEXT,font=('Segoe UI Semibold',14)).pack(anchor='w',padx=22,pady=(22,8))
        status=tk.Label(win,text='Скачиваю и проверяю обновление…',bg=BG,fg=MUTED)
        status.pack(anchor='w',padx=22)
        bar=ttk.Progressbar(win,mode='determinate',maximum=100)
        bar.pack(fill='x',padx=22,pady=18)
        ttk.Button(win,text='Не закрывать приложение во время обновления',state='disabled').pack(padx=22)
        win.protocol('WM_DELETE_WINDOW',lambda:None)

        def set_progress(value,text=None):
            try:
                bar['value']=max(0,min(100,int(value*100)))
                if text: status.config(text=text)
            except Exception: pass

        def worker():
            try:
                bundle=updater.download_bundle(manifest,progress=lambda x:self.jobq.put((set_progress,(x*0.45,'Скачиваю и проверяю SHA-256…'))))
                updater.stop_scanner()
                self.jobq.put((set_progress,(48/100,'Устанавливаю новые файлы…')))
                updater.install_bundle(bundle,manifest,progress=lambda x:self.jobq.put((set_progress,(0.48+x*0.50,'Устанавливаю новые файлы…'))))
                self.jobq.put((self._update_finished,(win,manifest)))
            except Exception as e:
                self.jobq.put((self._update_failed,(win,str(e))))
        threading.Thread(target=worker,daemon=True).start()

    def _update_failed(self,win,error):
        try: win.destroy()
        except: pass
        messagebox.showerror('Ошибка обновления',error)

    def _update_finished(self,win,manifest):
        try: win.destroy()
        except: pass
        # Relaunch updated local payload; no new EXE download is needed from now on.
        updater.restart_app()
        self.destroy()

    def on_close(self):
        # Scanner intentionally stays alive so signals continue while the UI is closed.
        self.destroy()

if __name__=='__main__':
    app=MemeRadarApp()
    app.mainloop()
