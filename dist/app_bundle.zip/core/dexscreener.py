
from __future__ import annotations
import time
import requests
from dataclasses import dataclass, asdict
from .utils import safe_float, safe_int

API = "https://api.dexscreener.com"
_session = requests.Session()
_session.headers.update({"User-Agent": "Skobin-Meme-Radar/2.0"})

@dataclass
class PairData:
    token: str
    symbol: str
    name: str
    pair_address: str
    dex: str
    url: str
    image_url: str
    created_ms: int
    market_cap: float
    liquidity: float
    volume_m5: float
    buys_m5: int
    sells_m5: int
    price_change_m5: float
    price_usd: float
    socials_count: int
    boosts_active: int
    source: str = "dex"
    holder_count: int = 0
    swaps_1m: int = 0
    swaps_1h: int = 0
    smart_degen_count: int = 0
    renowned_count: int = 0
    top_holder_rate: float = 0.0
    dev_rate: float = 0.0
    sniper_rate: float = 0.0
    bundler_rate: float = 0.0
    insider_rate: float = 0.0
    rug_ratio: float = 0.0
    progress: float = 0.0
    holders_per_min: float = 0.0
    tx_per_min: float = 0.0
    holder_growth_per_min: float = 0.0
    net_buy_usd: float = 0.0
    is_wash_trading: bool = False
    sniper_count: int = 0
    bot_degen_rate: float = 0.0
    fresh_wallet_rate: float = 0.0

    def to_dict(self):
        return asdict(self)

def _get(path, timeout=15):
    r = _session.get(API + path, timeout=timeout)
    r.raise_for_status()
    return r.json()

def _as_list(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    return []

def discover_addresses():
    """Public discovery fallback. DEX Screener's profile feeds are not a complete new-token firehose."""
    addresses = {}
    endpoints = [
        ("/token-profiles/latest/v1", "dex_profile"),
        ("/token-boosts/latest/v1", "dex_boost"),
        ("/token-boosts/top/v1", "dex_boost_top"),
        ("/community-takeovers/latest/v1", "dex_cto"),
    ]
    errors = []
    for path, source in endpoints:
        try:
            data = _get(path)
            for item in _as_list(data):
                if item.get("chainId") == "solana" and item.get("tokenAddress"):
                    addresses[item["tokenAddress"]] = source
        except Exception as e:
            errors.append(f"{source}: {e}")
    return addresses, errors

def fetch_tokens(addresses, source_map=None):
    """Fetch up to many tokens using DEX Screener's 30-address batch route."""
    source_map = source_map or {}
    addresses = list(dict.fromkeys([a for a in addresses if a]))
    pairs = []
    for i in range(0, len(addresses), 30):
        chunk = addresses[i:i+30]
        try:
            data = _get("/tokens/v1/solana/" + ",".join(chunk))
        except Exception:
            continue
        grouped = {}
        for p in _as_list(data):
            base = (p.get("baseToken") or {}).get("address")
            if not base:
                continue
            liq = safe_float((p.get("liquidity") or {}).get("usd"))
            if base not in grouped or liq > safe_float((grouped[base].get("liquidity") or {}).get("usd")):
                grouped[base] = p
        for token, p in grouped.items():
            mc = safe_float(p.get("marketCap") or p.get("fdv"))
            liq = safe_float((p.get("liquidity") or {}).get("usd"))
            created = safe_int(p.get("pairCreatedAt"))
            tx5 = ((p.get("txns") or {}).get("m5") or {})
            info = p.get("info") or {}
            socials = info.get("socials") or []
            boosts = p.get("boosts") or {}
            if not mc or not created:
                continue
            pairs.append(PairData(
                token=token,
                symbol=(p.get("baseToken") or {}).get("symbol") or "?",
                name=(p.get("baseToken") or {}).get("name") or "?",
                pair_address=p.get("pairAddress") or "",
                dex=p.get("dexId") or "?",
                url=p.get("url") or f"https://dexscreener.com/solana/{p.get('pairAddress','')}",
                image_url=info.get("imageUrl") or "",
                created_ms=created,
                market_cap=mc,
                liquidity=liq,
                volume_m5=safe_float((p.get("volume") or {}).get("m5")),
                buys_m5=safe_int(tx5.get("buys")),
                sells_m5=safe_int(tx5.get("sells")),
                price_change_m5=safe_float((p.get("priceChange") or {}).get("m5")),
                price_usd=safe_float(p.get("priceUsd")),
                socials_count=len(socials),
                boosts_active=safe_int(boosts.get("active")),
                source=source_map.get(token, "dex"),
            ))
        time.sleep(0.08)
    return pairs

def fetch_one(token: str):
    if not token:
        return None
    rows = fetch_tokens([token], {token: "manual"})
    return rows[0] if rows else None
