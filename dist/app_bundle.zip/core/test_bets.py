from __future__ import annotations
from .db import connect
from .utils import now_ts


def _ratio(entry_price, current_price, entry_mc, current_mc):
    if entry_price and current_price and float(entry_price) > 0 and float(current_price) > 0:
        return float(current_price) / float(entry_price)
    return float(current_mc or 0) / max(float(entry_mc or 0), 1e-12)


def open_test_bet(token, symbol, entry_mc, entry_price_usd, stake_usd, source='MANUAL', signal_score=None, cfg=None):
    stake = float(stake_usd)
    if stake <= 0:
        raise ValueError('Сумма тестовой ставки должна быть больше $0')
    if float(entry_mc or 0) <= 0:
        raise ValueError('Не удалось определить market cap для тестовой ставки')
    cfg = cfg or {}
    tb = cfg.get('test_bets', {}) if isinstance(cfg, dict) else {}
    if not tb.get('allow_multiple_per_token', True):
        con = connect()
        row = con.execute("SELECT id FROM test_bets WHERE token=? AND status='OPEN' LIMIT 1", (token,)).fetchone()
        con.close()
        if row:
            return None
    entry_cost = float(tb.get('estimated_entry_cost_pct', 0) or 0)
    initial_value = stake * max(0.0, 1-entry_cost)
    ts = now_ts()
    con = connect()
    cur = con.execute("""
        INSERT INTO test_bets(token,symbol,created_ts,entry_ts,entry_price_usd,entry_mc,stake_usd,source,signal_score,
          current_price_usd,current_mc,current_value_usd,pnl_usd,pnl_pct,peak_value_usd,peak_pnl_pct,low_value_usd,low_pnl_pct,
          peak_mc,low_mc,last_update_ts,status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'OPEN')
    """, (token, symbol, ts, ts, float(entry_price_usd or 0), float(entry_mc), stake, source, signal_score,
          float(entry_price_usd or 0), float(entry_mc), initial_value, initial_value-stake, (initial_value/stake)-1,
          initial_value, (initial_value/stake)-1, initial_value, (initial_value/stake)-1, float(entry_mc), float(entry_mc), ts))
    bet_id = cur.lastrowid
    con.execute("INSERT OR REPLACE INTO test_bet_snapshots(bet_id,ts,market_cap,price_usd,value_usd,pnl_pct) VALUES(?,?,?,?,?,?)",
                (bet_id, ts, float(entry_mc), float(entry_price_usd or 0), initial_value, (initial_value/stake)-1))
    con.commit(); con.close()
    return bet_id


def update_open_test_bets(token, current_mc, current_price_usd, cfg):
    con = connect()
    rows = con.execute("SELECT * FROM test_bets WHERE token=? AND status='OPEN'", (token,)).fetchall()
    if not rows:
        con.close(); return 0
    tb = cfg.get('test_bets', {})
    entry_cost = float(tb.get('estimated_entry_cost_pct', 0) or 0)
    exit_cost = float(tb.get('estimated_exit_cost_pct', 0) or 0)
    snap_interval = max(5, int(tb.get('snapshot_interval_seconds', 20) or 20))
    ts = now_ts(); updated = 0
    for rr in rows:
        r = dict(rr); stake = float(r['stake_usd'])
        ratio = _ratio(r['entry_price_usd'], current_price_usd, r['entry_mc'], current_mc)
        value = stake * max(0.0, 1-entry_cost) * ratio * max(0.0, 1-exit_cost)
        pnl = value-stake; pct = (pnl/stake) if stake else 0
        peak = max(float(r['peak_value_usd'] or value), value)
        low = min(float(r['low_value_usd'] or value), value)
        peak_pct = max(float(r['peak_pnl_pct'] or pct), pct)
        low_pct = min(float(r['low_pnl_pct'] or pct), pct)
        peak_mc = max(float(r['peak_mc'] or current_mc or 0), float(current_mc or 0))
        low_mc = min(float(r['low_mc'] or current_mc or 0), float(current_mc or 0))
        con.execute("""UPDATE test_bets SET current_price_usd=?,current_mc=?,current_value_usd=?,pnl_usd=?,pnl_pct=?,
          peak_value_usd=?,peak_pnl_pct=?,low_value_usd=?,low_pnl_pct=?,peak_mc=?,low_mc=?,last_update_ts=? WHERE id=?""",
          (float(current_price_usd or 0), float(current_mc or 0), value, pnl, pct, peak, peak_pct, low, low_pct, peak_mc, low_mc, ts, r['id']))
        last = con.execute("SELECT MAX(ts) x FROM test_bet_snapshots WHERE bet_id=?", (r['id'],)).fetchone()['x']
        if not last or ts-int(last) >= snap_interval:
            con.execute("INSERT OR REPLACE INTO test_bet_snapshots(bet_id,ts,market_cap,price_usd,value_usd,pnl_pct) VALUES(?,?,?,?,?,?)",
                        (r['id'], ts, float(current_mc or 0), float(current_price_usd or 0), value, pct))
        updated += 1
    con.commit(); con.close(); return updated


def close_test_bet(bet_id):
    con = connect()
    r = con.execute("SELECT * FROM test_bets WHERE id=? AND status='OPEN'", (int(bet_id),)).fetchone()
    if not r:
        con.close(); return False
    r = dict(r); ts = now_ts()
    con.execute("""UPDATE test_bets SET status='CLOSED',exit_ts=?,exit_price_usd=?,exit_mc=?,final_value_usd=?,final_pnl_usd=?,final_pnl_pct=? WHERE id=?""",
                (ts, r['current_price_usd'], r['current_mc'], r['current_value_usd'], r['pnl_usd'], r['pnl_pct'], int(bet_id)))
    con.commit(); con.close(); return True


def stats():
    con = connect()
    rows = [dict(r) for r in con.execute("SELECT * FROM test_bets ORDER BY id DESC").fetchall()]
    con.close()
    open_rows = [r for r in rows if r['status']=='OPEN']
    closed = [r for r in rows if r['status']=='CLOSED']
    total_stake = sum(float(r['stake_usd'] or 0) for r in rows)
    value = sum(float((r['current_value_usd'] if r['status']=='OPEN' else r['final_value_usd']) or 0) for r in rows)
    pnl = value-total_stake
    best = max(rows, key=lambda r: float((r['pnl_pct'] if r['status']=='OPEN' else r['final_pnl_pct']) or -999), default=None)
    return {'rows': rows, 'open': open_rows, 'closed': closed, 'count': len(rows), 'active': len(open_rows), 'stake': total_stake, 'value': value, 'pnl': pnl, 'best': best}
