
from __future__ import annotations
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from .utils import deep_collect_addresses, deep_find, safe_float, safe_int

def _windows_candidates(names):
    if os.name != "nt":
        return []
    appdata = os.environ.get("APPDATA", "")
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    local = os.environ.get("LOCALAPPDATA", "")
    out = []
    for name in names:
        out.extend([
            Path(pf) / "nodejs" / name,
            Path(appdata) / "npm" / name if appdata else Path("__missing__"),
            Path(local) / "Programs" / "nodejs" / name if local else Path("__missing__"),
        ])
    return [str(p) for p in out if str(p) != "__missing__" and p.exists()]

def executable():
    found = shutil.which("gmgn-cli") or shutil.which("gmgn-cli.cmd")
    if found:
        return found
    cands = _windows_candidates(["gmgn-cli.cmd", "gmgn-cli.exe", "gmgn-cli"])
    return cands[0] if cands else None

def installed() -> bool:
    return executable() is not None

def npm_executable():
    found = shutil.which("npm.cmd") or shutil.which("npm")
    if found:
        return found
    cands = _windows_candidates(["npm.cmd", "npm.exe", "npm"])
    return cands[0] if cands else None

def _refresh_windows_path():
    if os.name != "nt":
        return
    parts = os.environ.get("PATH", "").split(os.pathsep)
    candidates = [
        str(Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "nodejs"),
        str(Path(os.environ.get("APPDATA", "")) / "npm") if os.environ.get("APPDATA") else "",
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "nodejs") if os.environ.get("LOCALAPPDATA") else "",
    ]
    for p in candidates:
        if p and Path(p).exists() and p not in parts:
            parts.insert(0, p)
    os.environ["PATH"] = os.pathsep.join(parts)

def _install_node_windows():
    if os.name != "nt":
        return False, "Автоустановка Node.js сейчас поддерживается только в Windows."
    winget = shutil.which("winget.exe") or shutil.which("winget")
    if not winget:
        return False, "Не найден winget. Установи Node.js LTS вручную с nodejs.org, затем нажми кнопку ещё раз."
    flags = 0x08000000
    cmd = [
        winget, "install", "--id", "OpenJS.NodeJS.LTS", "-e",
        "--accept-package-agreements", "--accept-source-agreements",
        "--silent", "--disable-interactivity"
    ]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=600,
                           encoding="utf-8", errors="replace", creationflags=flags)
        _refresh_windows_path()
        npm = npm_executable()
        if npm:
            return True, "Node.js LTS установлен."
        msg = (p.stdout or p.stderr or "").strip()
        return False, (msg[-1800:] if msg else "Node.js установился, но npm пока не найден. Перезапусти приложение и повтори.")
    except Exception as e:
        return False, str(e)

def install_cli():
    _refresh_windows_path()
    npm = npm_executable()

    if not npm:
        ok, msg = _install_node_windows()
        if not ok:
            return False, msg
        _refresh_windows_path()
        npm = npm_executable()
        if not npm:
            return False, "Node.js установлен, но npm ещё не появился в PATH. Перезапусти Meme Radar и нажми установку GMGN ещё раз."

    try:
        flags = 0x08000000 if os.name == "nt" else 0
        p = subprocess.run([npm, "install", "-g", "gmgn-cli"], capture_output=True, text=True,
                           timeout=300, encoding="utf-8", errors="replace", creationflags=flags)
        msg = (p.stdout or p.stderr or "").strip()
        _refresh_windows_path()
        if p.returncode != 0:
            return False, msg[-1800:] or "npm install завершился с ошибкой"
        if not installed():
            return True, "GMGN CLI установлен. Перезапусти Meme Radar один раз, затем открой Настройки → GMGN."
        return True, "GMGN CLI установлен. Теперь вставь GMGN API key и нажми «Применить API key»."
    except Exception as e:
        return False, str(e)

def readiness():
    """Human-friendly readiness status for the desktop UI."""
    if not installed():
        if npm_executable():
            return False, "gmgn-cli не установлен — нажми «Установить GMGN CLI»"
        return False, "не найден Node.js/npm — сначала установи Node.js"
    ok, msg = check_config()
    if ok:
        return True, "GMGN New Creation подключён"
    low = (msg or "").lower()
    if "api" in low and ("key" in low or "auth" in low or "config" in low):
        return False, "GMGN API key не настроен — вставь ключ ниже"
    return False, (msg or "GMGN config не готов")[:240]

def run(args, timeout=25):
    exe = executable()
    if not exe:
        raise RuntimeError("gmgn-cli не установлен")
    cmd = [exe] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        msg = (p.stderr or p.stdout or "GMGN command failed").strip()
        raise RuntimeError(msg[:1200])
    text = p.stdout.strip()
    # gmgn-cli --raw should be JSON, but tolerate extra lines.
    try:
        return json.loads(text)
    except Exception:
        start = min([x for x in [text.find("{"), text.find("[")] if x >= 0], default=-1)
        if start >= 0:
            return json.loads(text[start:])
        raise RuntimeError("GMGN вернул не-JSON ответ")

def check_config():
    if not installed():
        return False, "gmgn-cli не установлен"
    try:
        p = subprocess.run([executable(), "config", "--check"], capture_output=True, text=True, timeout=15,
                           encoding="utf-8", errors="replace")
        return p.returncode == 0, (p.stdout or p.stderr).strip()
    except Exception as e:
        return False, str(e)

def apply_api_key(api_key: str):
    if not installed():
        return False, "Сначала установи gmgn-cli"
    if not api_key.strip():
        return False, "API key пустой"
    try:
        p = subprocess.run([executable(), "config", "--apply", api_key.strip()], capture_output=True, text=True,
                           timeout=20, encoding="utf-8", errors="replace")
        return p.returncode == 0, (p.stdout or p.stderr).strip()
    except Exception as e:
        return False, str(e)

def _token_addresses(data):
    out, seen = [], set()
    token_keys = {"token_address","tokenaddress","contract_address","contractaddress"}
    context_keys = {"symbol","name","market_cap","marketcap","liquidity","price","price_usd",
                    "holder_count","creation_timestamp","open_timestamp"}
    def walk(x):
        if isinstance(x, dict):
            lower = {str(k).lower(): v for k,v in x.items()}
            direct = None
            for k in token_keys:
                if isinstance(lower.get(k), str):
                    direct = lower[k]; break
            if direct is None and isinstance(lower.get("address"), str) and any(k in lower for k in context_keys):
                direct = lower["address"]
            if direct and 30 <= len(direct) <= 60 and direct not in seen:
                seen.add(direct); out.append(direct)
            for v in x.values(): walk(v)
        elif isinstance(x, list):
            for i in x: walk(i)
    walk(data)
    return out

def _first_dict_list(data):
    if isinstance(data, dict):
        # Prefer the documented trenches new_creation group.
        d = data.get("data", data)
        if isinstance(d, dict):
            for key in ("new_creation", "pump", "completed"):
                if isinstance(d.get(key), list):
                    return d.get(key)
        for v in data.values():
            got = _first_dict_list(v)
            if got:
                return got
    elif isinstance(data, list) and data and all(isinstance(x, dict) for x in data):
        return data
    return []

def trenches_meta(data):
    """Normalize documented GMGN Trenches fields by token address."""
    out = {}
    rows = _first_dict_list(data)
    for r in rows:
        address = r.get("address") or r.get("token_address") or r.get("contract_address")
        if not isinstance(address, str):
            continue
        created = r.get("created_timestamp") or r.get("creation_timestamp") or r.get("created_at")
        try:
            created_ms = int(float(created) * (1000 if float(created) < 10_000_000_000 else 1)) if created else 0
        except Exception:
            created_ms = 0
        out[address] = {
            "address": address,
            "symbol": r.get("symbol") or "?",
            "name": r.get("name") or r.get("symbol") or "?",
            "market_cap": safe_float(r.get("usd_market_cap") or r.get("market_cap") or r.get("mcp")),
            "liquidity": safe_float(r.get("liquidity")),
            "created_ms": created_ms,
            "holder_count": safe_int(r.get("holder_count")),
            "swaps_1m": safe_int(r.get("swaps_1m")),
            "swaps_1h": safe_int(r.get("swaps_1h")),
            # Trenches documents buy/sell counts for 24h. For a <5m token this is
            # effectively lifetime activity and is a useful fallback when DEX data is late.
            "buys": safe_int(r.get("buys_24h")),
            "sells": safe_int(r.get("sells_24h")),
            "volume": safe_float(r.get("volume_1h") or r.get("volume_24h")),
            "net_buy_usd": safe_float(r.get("net_buy_24h")),
            "smart_degen_count": safe_int(r.get("smart_degen_count")),
            "renowned_count": safe_int(r.get("renowned_count")),
            "top_holder_rate": safe_float(r.get("top_10_holder_rate") or r.get("top10_holder_rate") or r.get("top_holder_rate")),
            "dev_rate": safe_float(r.get("creator_balance_rate") or r.get("dev_team_hold_rate")),
            "sniper_rate": safe_float(r.get("top70_sniper_hold_rate") or r.get("sniper_hold_rate")),
            "sniper_count": safe_int(r.get("sniper_count")),
            "bundler_rate": safe_float(r.get("bundler_rate") or r.get("bundler_trader_amount_rate")),
            "insider_rate": safe_float(r.get("suspected_insider_hold_rate") or r.get("rat_trader_amount_rate") or r.get("insider_ratio") or r.get("insider_rate")),
            "bot_degen_rate": safe_float(r.get("bot_degen_rate")),
            "fresh_wallet_rate": safe_float(r.get("fresh_wallet_rate")),
            "is_wash_trading": bool(r.get("is_wash_trading") is True or str(r.get("is_wash_trading") or '').lower() in {"1","true","yes"}),
            "rug_ratio": safe_float(r.get("rug_ratio")),
            "progress": safe_float(r.get("progress")),
            "launchpad_platform": r.get("launchpad_platform") or "",
        }
    return out


def _client_filter_trenches(data, crowd):
    """Defensive client-side filter so a CLI flag change cannot kill discovery."""
    meta = trenches_meta(data)
    if not crowd.get("enabled"):
        return list(meta)
    now_ms = time.time() * 1000
    out = []
    for address, m in meta.items():
        created = float(m.get("created_ms") or 0)
        age_min = ((now_ms-created)/60000.0) if created else 0
        holders = int(m.get("holder_count") or 0)
        mc = float(m.get("market_cap") or 0)
        if created and age_min > float(crowd.get("max_age_minutes", 5)):
            continue
        if holders and holders < int(crowd.get("min_holders_discovery", 12)):
            continue
        if mc and mc > float(crowd.get("max_market_cap_entry", 60000))*1.5:
            continue
        checks = [
            (m.get("top_holder_rate"), crowd.get("max_top10_rate", .35)),
            (m.get("dev_rate"), crowd.get("max_dev_rate", .05)),
            (m.get("sniper_rate"), crowd.get("max_sniper_rate", .10)),
            (m.get("bundler_rate"), crowd.get("max_bundler_rate", .20)),
            (m.get("insider_rate"), crowd.get("max_insider_rate", .20)),
        ]
        if any(float(v or 0) > float(lim) for v, lim in checks if v is not None and float(v or 0) > 0):
            continue
        if m.get("is_wash_trading"):
            continue
        out.append(address)
    return out


def discover_trenches(chain="sol", fresh_only=False, safe=True, crowd=None):
    base = ["market", "trenches", "--chain", chain]
    if fresh_only:
        base += ["--type", "new_creation"]
    else:
        base += ["--type", "new_creation", "--type", "near_completion", "--type", "completed"]
    if safe:
        base += ["--filter-preset", "safe"]
    crowd = crowd or {}

    rich = list(base)
    if crowd.get("enabled") and fresh_only:
        rich += [
            "--max-created", f"{float(crowd.get('max_age_minutes',5)):g}m",
            "--min-holder-count", str(int(crowd.get("min_holders_discovery",12))),
            "--max-marketcap", str(float(crowd.get("max_market_cap_entry",60000))*1.5),
            "--max-top-holder-rate", str(float(crowd.get("max_top10_rate",0.35))),
            "--max-creator-balance-rate", str(float(crowd.get("max_dev_rate",0.05))),
            "--max-top70-sniper-hold-rate", str(float(crowd.get("max_sniper_rate",0.10))),
            "--max-bundler-rate", str(float(crowd.get("max_bundler_rate",0.20))),
            "--max-insider-ratio", str(float(crowd.get("max_insider_rate",0.20))),
            "--sort-by", "holder_count", "--direction", "desc",
        ]
    else:
        rich += ["--sort-by", "created_timestamp", "--direction", "desc"]
    rich += ["--limit", "80", "--raw"]

    try:
        data = run(rich, timeout=30)
    except Exception:
        # Minimal documented command as a fail-safe. Filtering still happens below.
        fallback = list(base) + ["--sort-by", "created_timestamp", "--direction", "desc", "--limit", "80", "--raw"]
        data = run(fallback, timeout=30)

    addresses = _client_filter_trenches(data, crowd) if (crowd.get("enabled") and fresh_only) else _token_addresses(data)
    return addresses, data

def discover_trending(chain="sol"):
    data = run([
        "market", "trending", "--chain", chain, "--interval", "5m",
        "--limit", "100", "--max-created", "3h",
        "--min-marketcap", "12000", "--max-marketcap", "500000",
        "--min-liquidity", "5000", "--raw"
    ], timeout=30)
    return _token_addresses(data), data


def discover_smart_signals(chain="sol", mc_max=500000):
    # Signal type 12 = Smart Money buy, 20 = KOL buy.
    data = run([
        "market", "signal", "--chain", chain,
        "--signal-type", "12", "--signal-type", "20",
        "--mc-max", str(int(mc_max)), "--raw"
    ], timeout=25)
    return _token_addresses(data), data

def token_security(address: str, chain="sol"):
    return run(["token", "security", "--chain", chain, "--address", address, "--raw"], timeout=20)

def smart_holders(address: str, chain="sol", limit=10):
    return run([
        "token", "holders", "--chain", chain, "--address", address,
        "--tag", "smart_degen", "--order-by", "buy_volume_cur",
        "--direction", "desc", "--limit", str(limit), "--raw"
    ], timeout=25)

def wallet_stats(wallet: str, chain="sol"):
    return run(["portfolio", "stats", "--chain", chain, "--wallet", wallet, "--raw"], timeout=25)

def wallet_profits(wallet: str, chain="sol", period="7d"):
    return run(["portfolio", "profits", "--chain", chain, "--wallet", wallet, "--period", period, "--raw"], timeout=25)

def wallet_activity(wallet: str, chain="sol", limit=20):
    return run(["portfolio", "activity", "--chain", chain, "--wallet", wallet, "--limit", str(limit), "--raw"], timeout=25)

def _bool_value(data, names):
    v = deep_find(data, names)
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"true","1","yes","y"}: return True
    if s in {"false","0","no","n"}: return False
    return None

def normalize_security(raw):
    """Normalize the useful safety fields while preserving raw JSON."""
    top10 = safe_float(deep_find(raw, ["top_10_holder_rate", "top10_holder_rate", "top10_rate"]), None)
    rug = safe_float(deep_find(raw, ["rug_ratio", "rug_rate"]), None)
    sell_tax = safe_float(deep_find(raw, ["sell_tax"]), None)
    buy_tax = safe_float(deep_find(raw, ["buy_tax"]), None)
    sniper_count = safe_int(deep_find(raw, ["sniper_count"]), None)
    dev_rate = safe_float(deep_find(raw, ["dev_team_hold_rate", "dev_hold_rate", "creator_hold_rate"]), None)
    insider_rate = safe_float(deep_find(raw, ["insider_rate"]), None)
    bundler_rate = safe_float(deep_find(raw, ["bundler_rate"]), None)
    renounced_mint = _bool_value(raw, ["renounced_mint"])
    renounced_freeze = _bool_value(raw, ["renounced_freeze_account", "renounced_freeze"])
    honeypot = deep_find(raw, ["is_honeypot"])
    creator_status = deep_find(raw, ["creator_token_status"])
    return {
        "top10_rate": top10,
        "rug_ratio": rug,
        "sell_tax": sell_tax,
        "buy_tax": buy_tax,
        "sniper_count": sniper_count,
        "dev_rate": dev_rate,
        "insider_rate": insider_rate,
        "bundler_rate": bundler_rate,
        "renounced_mint": renounced_mint,
        "renounced_freeze": renounced_freeze,
        "is_honeypot": honeypot,
        "creator_status": creator_status,
    }

def evaluate_security(raw):
    s = normalize_security(raw)
    hard = []
    warnings = []
    bonus = 0.0

    if s["renounced_mint"] is False:
        hard.append("mint authority не отключена")
    if s["renounced_freeze"] is False:
        hard.append("freeze authority не отключена")
    if s["rug_ratio"] is not None:
        if s["rug_ratio"] > 0.30: hard.append(f"rug ratio {s['rug_ratio']:.0%}")
        elif s["rug_ratio"] > 0.10: warnings.append(f"rug ratio {s['rug_ratio']:.0%}")
        else: bonus += 3
    if s["sell_tax"] is not None:
        if s["sell_tax"] > 0.10: hard.append(f"sell tax {s['sell_tax']:.0%}")
        elif s["sell_tax"] > 0.05: warnings.append(f"sell tax {s['sell_tax']:.0%}")
    if s["top10_rate"] is not None:
        if s["top10_rate"] > 0.60: hard.append(f"Top10 {s['top10_rate']:.0%}")
        elif s["top10_rate"] > 0.40: warnings.append(f"Top10 {s['top10_rate']:.0%}")
        elif s["top10_rate"] < 0.20: bonus += 7
        else: bonus += 3
    if s["sniper_count"] is not None:
        if s["sniper_count"] > 20: warnings.append(f"snipers {s['sniper_count']}")
        elif s["sniper_count"] < 5: bonus += 3
    if s["dev_rate"] is not None:
        if s["dev_rate"] > 0.15: warnings.append(f"dev hold {s['dev_rate']:.0%}")
        elif s["dev_rate"] < 0.05: bonus += 3
    if s["insider_rate"] is not None and s["insider_rate"] > 0.15:
        warnings.append(f"insiders {s['insider_rate']:.0%}")
    if s["bundler_rate"] is not None and s["bundler_rate"] > 0.20:
        warnings.append(f"bundlers {s['bundler_rate']:.0%}")
    hp = str(s["is_honeypot"]).lower() if s["is_honeypot"] is not None else ""
    if hp in {"yes","true","1"}:
        hard.append("honeypot")

    if hard:
        status = "FAIL"
        bonus = -30
    elif warnings:
        status = "WARN"
        bonus += max(-8, -2 * len(warnings))
    else:
        status = "PASS"
        bonus += 2

    return {
        "status": status,
        "score_delta": bonus,
        "hard_stops": hard,
        "warnings": warnings,
        "metrics": s
    }

def count_smart_holders(raw):
    # Best effort: locate likely list and count its entries.
    candidates = []
    def walk(x):
        if isinstance(x, list):
            if x and all(isinstance(i, dict) for i in x):
                candidates.append(x)
            for i in x: walk(i)
        elif isinstance(x, dict):
            for v in x.values(): walk(v)
    walk(raw)
    return max((len(x) for x in candidates), default=0)
