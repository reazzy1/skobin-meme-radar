
from __future__ import annotations
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
import requests

REPO = "reazzy1/skobin-meme-radar"
MANIFEST_URL = f"https://raw.githubusercontent.com/{REPO}/main/update.json"

ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "VERSION"

PRESERVE_TOP_LEVEL = {
    ".env",
    "config.json",
    ".venv",
    "data",
}

def current_version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return "0.0.0"

def _parts(v: str):
    out = []
    for p in str(v).strip().lstrip("v").split("."):
        n = "".join(ch for ch in p if ch.isdigit())
        out.append(int(n or 0))
    while len(out) < 4:
        out.append(0)
    return tuple(out[:4])

def newer(remote: str, local: str | None = None) -> bool:
    return _parts(remote) > _parts(local or current_version())

def fetch_manifest(timeout=8) -> dict:
    r = requests.get(MANIFEST_URL, timeout=timeout, headers={"Cache-Control":"no-cache"})
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, dict):
        raise RuntimeError("Некорректный update.json")
    for key in ("version", "bundle_url", "sha256"):
        if not data.get(key):
            raise RuntimeError(f"В update.json нет поля {key}")
    return data

def check(timeout=8) -> dict:
    manifest = fetch_manifest(timeout=timeout)
    manifest["current_version"] = current_version()
    manifest["update_available"] = newer(manifest["version"], manifest["current_version"])
    return manifest

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()

def download_bundle(manifest: dict, progress=None) -> Path:
    tmpdir = Path(tempfile.mkdtemp(prefix="skobin_radar_update_"))
    target = tmpdir / "app_bundle.zip"
    with requests.get(manifest["bundle_url"], stream=True, timeout=45) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length") or 0)
        done = 0
        with target.open("wb") as f:
            for chunk in r.iter_content(1024 * 256):
                if not chunk:
                    continue
                f.write(chunk)
                done += len(chunk)
                if progress and total:
                    progress(min(0.95, done / total))
    actual = _sha256(target)
    expected = str(manifest["sha256"]).strip().lower()
    if actual != expected:
        raise RuntimeError(
            "SHA-256 обновления не совпал. Установка отменена.\n"
            f"Ожидался: {expected}\nПолучен: {actual}"
        )
    if progress:
        progress(1.0)
    return target

def _safe_member(name: str) -> bool:
    p = Path(name)
    return not p.is_absolute() and ".." not in p.parts

def install_bundle(bundle: Path, manifest: dict, progress=None):
    staging = bundle.parent / "staging"
    if staging.exists():
        shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)

    with zipfile.ZipFile(bundle, "r") as z:
        names = z.namelist()
        for i, member in enumerate(names):
            if not _safe_member(member):
                raise RuntimeError("Небезопасный путь в обновлении")
            z.extract(member, staging)
            if progress:
                progress((i + 1) / max(1, len(names)) * 0.45)

    # Bundle root contains app files directly. Copy everything except persistent user state.
    items = list(staging.iterdir())
    for i, src in enumerate(items):
        if src.name in PRESERVE_TOP_LEVEL:
            continue
        dst = ROOT / src.name
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst, ignore_errors=True)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
        if progress:
            progress(0.45 + (i + 1) / max(1, len(items)) * 0.45)

    # VERSION must be remote version even if an old/malformed bundle forgot to include it.
    VERSION_FILE.write_text(str(manifest["version"]).strip() + "\n", encoding="utf-8")

    # Requirements may change in future releases.
    req = ROOT / "requirements.txt"
    if req.exists():
        flags = 0x08000000 if os.name == "nt" else 0
        cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r", str(req)]
        p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, creationflags=flags)
        if p.returncode != 0:
            raise RuntimeError("Не удалось обновить зависимости:\n" + (p.stderr or p.stdout)[-1500:])
    if progress:
        progress(1.0)

def stop_scanner():
    pid_file = ROOT / "data" / "engine.pid"
    if not pid_file.exists():
        return
    try:
        pid = pid_file.read_text(encoding="utf-8").strip()
        if pid:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", pid, "/T", "/F"],
                    capture_output=True,
                    creationflags=0x08000000,
                )
            else:
                os.kill(int(pid), 15)
    except Exception:
        pass
    try:
        pid_file.unlink(missing_ok=True)
    except Exception:
        pass

def restart_app():
    flags = 0x08000000 if os.name == "nt" else 0
    subprocess.Popen(
        [sys.executable, str(ROOT / "desktop_app.py")],
        cwd=str(ROOT),
        creationflags=flags,
    )
