
from __future__ import annotations
import json
import math
import time
from datetime import datetime, timezone

def now_ts() -> int:
    return int(time.time())

def age_minutes(created_ms: int | float | None) -> float:
    if not created_ms:
        return 10**9
    return max(0.0, (time.time() * 1000 - float(created_ms)) / 60000.0)

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def safe_float(v, default=0.0):
    try:
        if v is None or v == "":
            return default
        return float(v)
    except (TypeError, ValueError):
        return default

def safe_int(v, default=0):
    try:
        if v is None or v == "":
            return default
        return int(float(v))
    except (TypeError, ValueError):
        return default

def fmt_usd(v) -> str:
    v = safe_float(v)
    av = abs(v)
    if av >= 1_000_000_000:
        return f"${v/1_000_000_000:.2f}B"
    if av >= 1_000_000:
        return f"${v/1_000_000:.2f}M"
    if av >= 1_000:
        return f"${v/1_000:.1f}K"
    return f"${v:.2f}"

def fmt_pct(v, digits=1) -> str:
    return f"{safe_float(v) * 100:.{digits}f}%"

def dt_text(ts: int | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts).strftime("%d.%m %H:%M:%S")

def json_dumps(data) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))

def json_loads(s, default=None):
    try:
        return json.loads(s) if s else default
    except Exception:
        return default

def deep_find(data, key_names):
    """Find first scalar value whose key matches one of key_names, recursively."""
    wanted = {str(k).lower() for k in key_names}
    if isinstance(data, dict):
        for k, v in data.items():
            if str(k).lower() in wanted and not isinstance(v, (dict, list)):
                return v
        for v in data.values():
            found = deep_find(v, wanted)
            if found is not None:
                return found
    elif isinstance(data, list):
        for item in data:
            found = deep_find(item, wanted)
            if found is not None:
                return found
    return None

def deep_collect_addresses(data):
    """Best-effort address extraction from GMGN JSON."""
    out = []
    seen = set()
    keys = {"address", "token_address", "tokenaddress", "contract_address", "contractaddress"}
    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                lk = str(k).lower()
                if lk in keys and isinstance(v, str) and 30 <= len(v) <= 60 and v not in seen:
                    seen.add(v); out.append(v)
                else:
                    walk(v)
        elif isinstance(x, list):
            for item in x:
                walk(item)
    walk(data)
    return out
