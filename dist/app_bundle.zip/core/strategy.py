from __future__ import annotations
from statistics import mean
from .utils import age_minutes, clamp


def _avg(values, default=0.0):
    vals = [float(v) for v in values if v is not None]
    return mean(vals) if vals else float(default)


def market_score(p: dict, cfg: dict):
    f = cfg["filters"]
    age = age_minutes(p.get("created_ms"))
    mc = float(p.get("market_cap") or 0)
    liq = float(p.get("liquidity") or 0)
    vol = float(p.get("volume_m5") or 0)
    buys = int(p.get("buys_m5") or 0)
    sells = int(p.get("sells_m5") or 0)
    change = float(p.get("price_change_m5") or 0)
    txns = buys + sells
    buy_frac = buys / max(1, txns)
    liq_mc = liq / max(1, mc)
    vol_mc = vol / max(1, mc)
    holders = int(p.get("holder_count") or 0)
    holders_per_min = float(p.get("holders_per_min") or (holders / max(age, 0.25) if holders else 0))
    tx_per_min = float(p.get("tx_per_min") or (txns / max(age, 0.25) if txns else 0))
    net_buy = float(p.get("net_buy_usd") or 0)

    hard = []
    if not (float(f["min_age_minutes"]) <= age <= float(f["max_age_minutes"])):
        hard.append("возраст вне диапазона")
    if not (float(f["min_market_cap"]) <= mc <= float(f["max_market_cap"])):
        hard.append("market cap вне диапазона")
    if liq < float(f["min_liquidity_usd"]):
        hard.append("мало ликвидности")
    if liq_mc < float(f["min_liquidity_mc_ratio"]):
        hard.append("слишком мало liquidity/MC")
    if vol < float(f["min_volume_5m"]):
        hard.append("слабый объём")
    if txns < int(f["min_txns_5m"]):
        hard.append("мало сделок")
    if buy_frac < float(f["min_buy_fraction"]):
        hard.append("слабый перевес покупателей")
    if bool(p.get("is_wash_trading")):
        hard.append("GMGN: wash trading")
    # A new token can legitimately be +100% very quickly. Only reject truly late vertical moves here;
    # the PRE-PUMP detector has a much more useful short-window chase check.
    if change > float(f.get("max_chase_change_5m_pct", 300)):
        hard.append("памп уже слишком далеко ушёл")

    score = 0.0
    reasons = []

    # Fresh-launch timing: best window is tens of seconds to a few minutes.
    if 0.35 <= age <= 1.5:
        score += 15; reasons.append("идеальное раннее окно +15")
    elif 1.5 < age <= 3:
        score += 12; reasons.append("очень ранний возраст +12")
    elif 3 < age <= 5:
        score += 7; reasons.append("ещё свежий +7")
    elif age < 0.35:
        score += 4; reasons.append("слишком первые секунды +4")
    else:
        score += 2

    if 7_000 <= mc <= 25_000:
        score += 15; reasons.append("MC 7–25K +15")
    elif 25_000 < mc <= 50_000:
        score += 12; reasons.append("MC 25–50K +12")
    elif 50_000 < mc <= 80_000:
        score += 6; reasons.append("MC до 80K +6")
    else:
        score += 2

    if 0.08 <= liq_mc <= 0.40:
        score += 11; reasons.append("здоровая liquidity/MC +11")
    elif 0.04 <= liq_mc < 0.08:
        score += 6; reasons.append("приемлемая liquidity/MC +6")
    elif liq_mc > 0.40:
        score += 6
    else:
        score -= 7; reasons.append("тонкая ликвидность -7")

    if vol_mc >= 0.70:
        score += 14; reasons.append("очень сильный volume/MC +14")
    elif vol_mc >= 0.30:
        score += 11; reasons.append("сильный volume/MC +11")
    elif vol_mc >= 0.10:
        score += 6; reasons.append("нормальный volume/MC +6")

    if buy_frac >= 0.68:
        score += 12; reasons.append("сильный buy pressure +12")
    elif buy_frac >= 0.60:
        score += 9; reasons.append("buy pressure +9")
    elif buy_frac >= 0.54:
        score += 5; reasons.append("перевес покупок +5")
    elif buy_frac < 0.48:
        score -= 8; reasons.append("продавцы сильнее -8")

    if tx_per_min >= 120:
        score += 12; reasons.append("120+ tx/min +12")
    elif tx_per_min >= 60:
        score += 9; reasons.append("60+ tx/min +9")
    elif tx_per_min >= 25:
        score += 5; reasons.append("25+ tx/min +5")

    if holders >= 100:
        score += 13; reasons.append("100+ holders очень рано +13")
    elif holders >= 60:
        score += 10; reasons.append("60+ holders очень рано +10")
    elif holders >= 25:
        score += 6; reasons.append("25+ holders +6")

    if holders_per_min >= 60:
        score += 13; reasons.append("60+ holders/min +13")
    elif holders_per_min >= 30:
        score += 9; reasons.append("30+ holders/min +9")
    elif holders_per_min >= 15:
        score += 5; reasons.append("15+ holders/min +5")

    if net_buy >= 2500:
        score += 7; reasons.append("сильный GMGN net buy +7")
    elif net_buy >= 700:
        score += 4; reasons.append("положительный GMGN net buy +4")
    elif net_buy < -1000:
        score -= 8; reasons.append("отрицательный GMGN net buy -8")

    if 2 <= change <= 80:
        score += 5; reasons.append("цена уже подтверждает спрос +5")
    elif 80 < change <= 180:
        score += 1
    elif change > 250:
        score -= 10; reasons.append("риск погони за уже разогнанной ценой -10")
    elif change < -20:
        score -= 7; reasons.append("сильный слив -7")

    if int(p.get("socials_count") or 0) > 0:
        score += 2
    if int(p.get("smart_degen_count") or 0) > 0:
        score += 4; reasons.append("есть smart money +4")
    if int(p.get("renowned_count") or 0) > 0:
        score += 3; reasons.append("есть KOL wallets +3")

    source = str(p.get("source") or "")
    if "smart_signal" in source:
        score += 5
    elif "trenches" in source or "new_creation" in source:
        score += 4; reasons.append("GMGN New Creation +4")

    if holders <= 0 and cfg.get("crowd_launches", {}).get("enabled"):
        hard.append("нет данных о holders")

    return {
        "base_score": clamp(score, 0, 100),
        "eligible": len(hard) == 0,
        "hard_reasons": hard,
        "reasons": reasons,
        "age_minutes": age,
        "buy_fraction": buy_frac,
        "liq_mc_ratio": liq_mc,
        "vol_mc_ratio": vol_mc,
        "txns_5m": txns,
        "holder_count": holders,
        "holders_per_min": holders_per_min,
        "tx_per_min": tx_per_min,
        "net_buy_usd": net_buy,
    }


def _risk_list(p: dict, cfg: dict, security_eval=None):
    cc = cfg.get("crowd_launches", {})
    sec = (security_eval or {}).get("metrics", {})
    top10 = sec.get("top10_rate")
    dev = sec.get("dev_rate")
    top10 = top10 if top10 is not None else (float(p.get("top_holder_rate") or 0) or None)
    dev = dev if dev is not None else (float(p.get("dev_rate") or 0) or None)
    bundler = float(p.get("bundler_rate") or 0) or None
    insider = float(p.get("insider_rate") or 0) or None
    sniper_rate = float(p.get("sniper_rate") or 0) or None
    sniper_count = int(p.get("sniper_count") or 0)
    rug = float(p.get("rug_ratio") or 0)
    risks = []
    if bool(p.get("is_wash_trading")): risks.append("wash trading")
    if rug > 0.30: risks.append(f"rug {rug:.0%}")
    if top10 is not None and top10 > float(cc.get("max_top10_rate", .35)): risks.append(f"Top10 {top10:.0%}")
    if dev is not None and dev > float(cc.get("max_dev_rate", .05)): risks.append(f"dev {dev:.0%}")
    if sniper_rate is not None and sniper_rate > float(cc.get("max_sniper_rate", .10)): risks.append(f"snipers {sniper_rate:.0%}")
    if sniper_count > int(cc.get("max_sniper_count", 25)): risks.append(f"snipers {sniper_count}")
    if bundler is not None and bundler > float(cc.get("max_bundler_rate", .20)): risks.append(f"bundlers {bundler:.0%}")
    if insider is not None and insider > float(cc.get("max_insider_rate", .20)): risks.append(f"insiders {insider:.0%}")
    return risks


def crowd_analysis(history_rows, p: dict, market: dict, cfg: dict, security_eval=None):
    cc = cfg.get("crowd_launches", {})
    if not cc.get("enabled"):
        return {"enabled": False, "watch_ready": True, "entry_ready": True, "score_bonus": 0, "risks": []}
    age = market["age_minutes"]
    holders = int(p.get("holder_count") or 0)
    hpm = float(market.get("holders_per_min") or 0)
    txpm = float(market.get("tx_per_min") or 0)
    buy_frac = float(market.get("buy_fraction") or 0)
    mc = float(p.get("market_cap") or 0)
    growth = float(p.get("holder_growth_per_min") or 0)
    risks = _risk_list(p, cfg, security_eval)

    watch_ready = (
        age <= float(cc.get("max_age_minutes", 5))
        and holders >= int(cc.get("min_holders_watch", 25))
        and buy_frac >= float(cc.get("min_buy_fraction_watch", .52))
        and not risks
    )
    entry_ready = (
        watch_ready
        and holders >= int(cc.get("min_holders_entry", 50))
        and hpm >= float(cc.get("min_holders_per_min_entry", 15))
        and txpm >= float(cc.get("min_tx_per_min_entry", 25))
        and buy_frac >= float(cc.get("min_buy_fraction_entry", .56))
        and mc <= float(cc.get("max_market_cap_entry", 65000))
    )
    bonus = 0
    if growth >= 45: bonus += 8
    elif growth >= 20: bonus += 5
    if risks: bonus -= 30
    return {
        "enabled": True, "watch_ready": watch_ready, "entry_ready": entry_ready,
        "holder_count": holders, "holders_per_min": hpm, "holder_growth_per_min": growth,
        "tx_per_min": txpm, "buy_fraction": buy_frac, "risks": risks,
        "score_bonus": bonus
    }


def acceleration_analysis(history_rows, p: dict, market: dict, cfg: dict, security_eval=None, crowd=None):
    pc = cfg.get("pre_pump", {})
    if not pc.get("enabled", True):
        return {"enabled": False, "ready": False, "confirmed": False, "score": 0, "score_bonus": 0}

    age = float(market.get("age_minutes") or 999)
    rows = [dict(r) for r in history_rows if r.get("ts")]
    rows.sort(key=lambda r: int(r["ts"]))
    window = int(pc.get("history_seconds", 120))
    if rows:
        cutoff = int(rows[-1]["ts"]) - window
        rows = [r for r in rows if int(r["ts"]) >= cutoff]

    intervals = []
    for a, b in zip(rows, rows[1:]):
        dt = (int(b["ts"]) - int(a["ts"])) / 60.0
        if dt <= 0 or dt > 1.5:
            continue
        ah, bh = int(a.get("holder_count") or 0), int(b.get("holder_count") or 0)
        at = int(a.get("buys_m5") or 0) + int(a.get("sells_m5") or 0)
        bt = int(b.get("buys_m5") or 0) + int(b.get("sells_m5") or 0)
        ab, bb = int(a.get("buys_m5") or 0), int(b.get("buys_m5") or 0)
        ass, bs = int(a.get("sells_m5") or 0), int(b.get("sells_m5") or 0)
        av, bv = float(a.get("volume_m5") or 0), float(b.get("volume_m5") or 0)
        # For tokens younger than five minutes DEX m5 / GMGN lifetime-like counters are cumulative.
        # Ignore negative deltas caused by a rolling window reset.
        intervals.append({
            "hpm": max(0.0, (bh-ah)/dt) if bh and ah else 0.0,
            "txpm": max(0.0, (bt-at)/dt) if bt >= at else 0.0,
            "buys": max(0, bb-ab) if bb >= ab else 0,
            "sells": max(0, bs-ass) if bs >= ass else 0,
            "vpm": max(0.0, (bv-av)/dt) if bv >= av else 0.0,
        })

    recent = intervals[-2:] if intervals else []
    previous = intervals[-4:-2] if len(intervals) >= 3 else intervals[:-1]
    recent_hpm = _avg([x["hpm"] for x in recent], market.get("holders_per_min", 0))
    prev_hpm = _avg([x["hpm"] for x in previous], max(1.0, recent_hpm * .75))
    recent_txpm = _avg([x["txpm"] for x in recent], market.get("tx_per_min", 0))
    prev_txpm = _avg([x["txpm"] for x in previous], max(1.0, recent_txpm * .8))
    volume_vpm = _avg([x["vpm"] for x in recent], 0)
    prev_vpm = _avg([x["vpm"] for x in previous], max(1.0, volume_vpm * .8))
    holder_ratio = recent_hpm / max(prev_hpm, 1.0)
    tx_ratio = recent_txpm / max(prev_txpm, 1.0)
    volume_ratio = volume_vpm / max(prev_vpm, 1.0)

    dbuys = sum(x["buys"] for x in recent)
    dsells = sum(x["sells"] for x in recent)
    recent_buy_fraction = dbuys / max(1, dbuys + dsells) if (dbuys + dsells) else float(market.get("buy_fraction") or 0)

    mc_growth_60s = 0.0
    if rows:
        last_ts = int(rows[-1]["ts"])
        anchors = [r for r in rows if int(r["ts"]) <= last_ts - 45 and float(r.get("market_cap") or 0) > 0]
        anchor = anchors[-1] if anchors else (rows[0] if len(rows) >= 2 else None)
        if anchor and float(anchor.get("market_cap") or 0) > 0:
            mc_growth_60s = float(p.get("market_cap") or 0) / float(anchor["market_cap"]) - 1

    net_buy = float(p.get("net_buy_usd") or 0)
    risks = list((crowd or {}).get("risks") or _risk_list(p, cfg, security_eval))
    holders = int(p.get("holder_count") or 0)
    mc = float(p.get("market_cap") or 0)
    point_count = len(rows)

    score = 0.0
    reasons = []
    if recent_hpm >= 60: score += 22; reasons.append("толпа 60+ H/min")
    elif recent_hpm >= 30: score += 18; reasons.append("толпа 30+ H/min")
    elif recent_hpm >= 15: score += 12; reasons.append("толпа 15+ H/min")
    if holder_ratio >= 1.8: score += 16; reasons.append("holders резко ускоряются")
    elif holder_ratio >= 1.3: score += 12; reasons.append("holders ускоряются")
    elif holder_ratio >= 1.12: score += 6

    if recent_txpm >= 120: score += 18; reasons.append("120+ новых tx/min")
    elif recent_txpm >= 60: score += 14; reasons.append("60+ новых tx/min")
    elif recent_txpm >= 25: score += 9; reasons.append("25+ новых tx/min")
    if tx_ratio >= 1.7: score += 12; reasons.append("сделки резко ускоряются")
    elif tx_ratio >= 1.25: score += 8; reasons.append("сделки ускоряются")

    if recent_buy_fraction >= .68: score += 12; reasons.append("свежий buy pressure 68%+")
    elif recent_buy_fraction >= .58: score += 8; reasons.append("свежий buy pressure 58%+")
    if volume_vpm >= 2500: score += 10; reasons.append("объём +$2.5K/min")
    elif volume_vpm >= 700: score += 7; reasons.append("объём быстро растёт")
    elif volume_vpm >= 250: score += 3
    if volume_ratio >= 1.4 and volume_vpm > 0: score += 4

    if net_buy >= 2500: score += 8; reasons.append("net buy +$2.5K+")
    elif net_buy >= 700: score += 5; reasons.append("net buy положительный")
    elif net_buy < -1000: score -= 12; reasons.append("net buy отрицательный")

    if .03 <= mc_growth_60s <= .65: score += 8; reasons.append("MC растёт, но ещё не вертикально")
    elif .65 < mc_growth_60s <= 1.10: score += 2
    elif mc_growth_60s > float(pc.get("max_mc_growth_60s", 2.00)): score -= 15; reasons.append("MC уже слишком вертикальный")
    elif mc_growth_60s < -.12: score -= 10; reasons.append("MC падает")

    if int(p.get("smart_degen_count") or 0) > 0: score += 5
    if int(p.get("renowned_count") or 0) > 0: score += 3
    if risks: score -= 35
    score = clamp(score, 0, 100)

    enough_history = point_count >= int(pc.get("min_history_points", 3))
    explosive = (
        age <= 1.5 and holders >= int(pc.get("explosive_holders", 65))
        and float(market.get("holders_per_min") or 0) >= float(pc.get("explosive_hpm", 45))
        and float(market.get("tx_per_min") or 0) >= float(pc.get("explosive_txpm", 80))
        and recent_buy_fraction >= float(pc.get("min_recent_buy_fraction", .58))
    )
    acceleration_ok = (
        holder_ratio >= float(pc.get("min_holder_accel_ratio", 1.18))
        or tx_ratio >= float(pc.get("min_tx_accel_ratio", 1.18))
        or explosive
    )
    ready = (
        age * 60 >= float(pc.get("min_age_seconds", 35))
        and age <= float(pc.get("max_age_minutes", 4))
        and holders >= int(pc.get("min_holders", 35))
        and recent_hpm >= float(pc.get("min_recent_holders_per_min", 15))
        and recent_txpm >= float(pc.get("min_recent_tx_per_min", 25))
        and recent_buy_fraction >= float(pc.get("min_recent_buy_fraction", .58))
        and mc <= float(pc.get("max_market_cap", 50000))
        and mc_growth_60s <= float(pc.get("max_mc_growth_60s", 2.00))
        and acceleration_ok
        and (enough_history or explosive)
        and not risks
    )
    confirmed = ready and score >= float(pc.get("min_acceleration_score", 65))
    entry_confirmed = confirmed and score >= float(pc.get("entry_acceleration_score", 75)) and (enough_history or point_count >= 2)

    if score >= 85: level = "VERY HIGH"
    elif score >= 70: level = "HIGH"
    elif score >= 55: level = "RISING"
    else: level = "LOW"

    return {
        "enabled": True, "ready": ready, "confirmed": confirmed, "entry_confirmed": entry_confirmed,
        "score": round(score, 1), "level": level, "points": point_count,
        "recent_holders_per_min": recent_hpm, "previous_holders_per_min": prev_hpm,
        "holder_accel_ratio": holder_ratio, "recent_tx_per_min": recent_txpm,
        "previous_tx_per_min": prev_txpm, "tx_accel_ratio": tx_ratio,
        "recent_buy_fraction": recent_buy_fraction, "volume_velocity_usd_min": volume_vpm,
        "volume_accel_ratio": volume_ratio, "mc_growth_60s": mc_growth_60s,
        "net_buy_usd": net_buy, "explosive_override": explosive, "risks": risks,
        "reasons": reasons, "score_bonus": min(18, score * .18) if confirmed else min(8, score * .08)
    }


def pattern_analysis(history_rows, p: dict, cfg: dict):
    st = cfg["strategy"]
    if len(history_rows) < st["min_history_points"]:
        return {"reclaim": False, "reason": "нужно больше локальной истории", "points": len(history_rows), "pattern_bonus": 0}
    mcs = [float(r["market_cap"]) for r in history_rows if r.get("market_cap")]
    if len(mcs) < st["min_history_points"]:
        return {"reclaim": False, "reason": "мало MC-точек", "points": len(mcs), "pattern_bonus": 0}
    first = mcs[0]; peak = max(mcs); peak_i = mcs.index(peak)
    if peak_i >= len(mcs)-1:
        return {"reclaim": False, "reason": "локальный максимум прямо сейчас", "first": first, "peak": peak, "pattern_bonus": 0}
    low_after = min(mcs[peak_i:]); current = float(p.get("market_cap") or mcs[-1])
    pump = peak / max(first, 1) - 1; pullback = 1 - low_after / max(peak, 1)
    rebound = current / max(low_after, 1) - 1; distance = current / max(peak, 1)
    reclaim = (pump >= st["min_pump_pct"] and st["min_pullback_pct"] <= pullback <= st["max_pullback_pct"]
               and rebound >= st["min_rebound_pct"] and distance <= st["max_reclaim_distance_from_peak"] and current > low_after)
    return {"reclaim": reclaim, "reason": "pump → pullback → rebound" if reclaim else "reclaim ещё не подтверждён",
            "first": first, "peak": peak, "low_after": low_after, "current": current,
            "pump_pct": pump, "pullback_pct": pullback, "rebound_pct": rebound,
            "distance_from_peak": distance, "pattern_bonus": 18 if reclaim else 0}


def early_momentum(market: dict, p: dict, cfg: dict):
    st = cfg["strategy"]
    if not st.get("early_momentum_enabled", True): return False
    change = float(p.get("price_change_m5") or 0); fresh = cfg.get("fresh_launches", {})
    if fresh.get("enabled"):
        age_sec = market["age_minutes"] * 60
        if age_sec < float(fresh.get("min_age_seconds_for_entry", 30)): return False
        if market["age_minutes"] > float(fresh.get("max_age_minutes", 5)): return False
        if change > float(fresh.get("max_entry_change_5m_pct", 200)): return False
    return (market["eligible"] and market["age_minutes"] <= st["momentum_max_age_minutes"]
            and st["momentum_min_change_5m_pct"] <= change <= st["momentum_max_change_5m_pct"]
            and market["buy_fraction"] >= st["momentum_min_buy_fraction"]
            and market["vol_mc_ratio"] >= st["momentum_min_volume_mc_ratio"])


def assess(p: dict, history_rows, cfg: dict, security_eval=None):
    market = market_score(p, cfg)
    pattern = pattern_analysis(history_rows, p, cfg)
    crowd = crowd_analysis(history_rows, p, market, cfg, security_eval)
    accel = acceleration_analysis(history_rows, p, market, cfg, security_eval, crowd)
    sec_delta = float((security_eval or {}).get("score_delta") or 0)
    sec_status = (security_eval or {}).get("status", "UNKNOWN")
    hard_security = bool((security_eval or {}).get("hard_stops"))
    score = clamp(market["base_score"] + pattern.get("pattern_bonus", 0) + crowd.get("score_bonus", 0)
                  + accel.get("score_bonus", 0) + sec_delta, 0, 100)
    momentum = early_momentum(market, p, cfg)

    pre_pump = bool(market["eligible"] and not hard_security and accel.get("confirmed")
                    and score >= float(cfg.get("pre_pump", {}).get("min_total_score", 65)))
    entry_type = None
    crowd_mode = bool(cfg.get("crowd_launches", {}).get("enabled"))
    if market["eligible"] and not hard_security:
        if crowd_mode:
            if crowd.get("entry_ready") and accel.get("entry_confirmed") and score >= cfg["strategy"]["entry_score"]:
                entry_type = "ACCELERATION_ENTRY"
        else:
            if pattern.get("reclaim") and score >= cfg["strategy"]["entry_score"]: entry_type = "RECLAIM"
            elif momentum and score >= cfg["strategy"]["entry_score"] + 3: entry_type = "EARLY_MOMENTUM"

    if cfg["strategy"].get("require_gmgn_security_for_entry") and sec_status != "PASS":
        entry_type = None
        pre_pump = False

    watch = market["eligible"] and score >= cfg["strategy"]["watch_score"]
    if crowd_mode: watch = watch and bool(crowd.get("watch_ready"))
    return {
        "score": round(score, 1), "watch": watch, "pre_pump": pre_pump,
        "entry": bool(entry_type), "entry_type": entry_type,
        "market": market, "crowd": crowd, "acceleration": accel, "pattern": pattern,
        "security": security_eval or {"status": "UNKNOWN", "score_delta": 0},
    }
