
from __future__ import annotations
from .utils import age_minutes, clamp

def market_score(p: dict, cfg: dict):
    f = cfg["filters"]
    age = age_minutes(p.get("created_ms"))
    mc = float(p.get("market_cap") or 0)
    liq = float(p.get("liquidity") or 0)
    vol = float(p.get("volume_m5") or 0)
    buys = int(p.get("buys_m5") or 0)
    sells = int(p.get("sells_m5") or 0)
    change = float(p.get("price_change_m5") or 0)
    txns = buys + sells
    buy_frac = buys / max(1, txns)
    liq_mc = liq / max(1, mc)
    vol_mc = vol / max(1, mc)

    hard = []
    if not (f["min_age_minutes"] <= age <= f["max_age_minutes"]):
        hard.append("возраст вне диапазона")
    if not (f["min_market_cap"] <= mc <= f["max_market_cap"]):
        hard.append("market cap вне диапазона")
    if liq < f["min_liquidity_usd"]:
        hard.append("мало ликвидности")
    if liq_mc < f["min_liquidity_mc_ratio"]:
        hard.append("слишком мало liquidity/MC")
    if vol < f["min_volume_5m"]:
        hard.append("слабый 5m volume")
    if txns < f["min_txns_5m"]:
        hard.append("мало сделок")
    if buy_frac < f["min_buy_fraction"]:
        hard.append("слабый перевес покупателей")
    if change > f["max_chase_change_5m_pct"]:
        hard.append("уже слишком вертикальный памп")

    score = 0.0
    reasons = []

    # Age: early, but not first seconds.
    if 3 <= age <= 25:
        score += 13; reasons.append("ранний возраст +13")
    elif 1 <= age < 3:
        score += 5; reasons.append("совсем новый +5")
    elif 25 < age <= 75:
        score += 8; reasons.append("ещё молодой +8")
    else:
        score += 3

    # Market-cap sweet spot.
    if 20_000 <= mc <= 80_000:
        score += 15; reasons.append("низкий MC +15")
    elif 80_000 < mc <= 180_000:
        score += 12; reasons.append("MC до 180K +12")
    elif 180_000 < mc <= 350_000:
        score += 7; reasons.append("MC до 350K +7")
    else:
        score += 3

    # Liquidity quality.
    if 0.08 <= liq_mc <= 0.40:
        score += 12; reasons.append("здоровая liquidity/MC +12")
    elif 0.05 <= liq_mc < 0.08:
        score += 6; reasons.append("приемлемая liquidity/MC +6")
    elif liq_mc > 0.40:
        score += 7
    else:
        score -= 8; reasons.append("тонкая ликвидность -8")

    # Activity relative to cap.
    if vol_mc >= 0.50:
        score += 14; reasons.append("очень сильный volume/MC +14")
    elif vol_mc >= 0.20:
        score += 11; reasons.append("сильный volume/MC +11")
    elif vol_mc >= 0.08:
        score += 6; reasons.append("нормальный volume/MC +6")
    else:
        score += 1

    if buy_frac >= 0.66:
        score += 12; reasons.append("сильный buy pressure +12")
    elif buy_frac >= 0.60:
        score += 9; reasons.append("buy pressure +9")
    elif buy_frac >= 0.54:
        score += 5; reasons.append("небольшой перевес покупок +5")
    elif buy_frac < 0.48:
        score -= 8; reasons.append("продавцы сильнее -8")

    if txns >= 150:
        score += 10; reasons.append("много транзакций +10")
    elif txns >= 60:
        score += 7; reasons.append("активные транзакции +7")
    elif txns >= 16:
        score += 4

    if 5 <= change <= 35:
        score += 8; reasons.append("контролируемый 5m импульс +8")
    elif 35 < change <= 65:
        score += 3; reasons.append("сильный 5m импульс +3")
    elif change > 90:
        score -= 12; reasons.append("риск погони за пампом -12")
    elif -15 <= change < 0:
        score += 1
    elif change < -25:
        score -= 6; reasons.append("сильный слив -6")

    if int(p.get("socials_count") or 0) > 0:
        score += 3; reasons.append("есть socials +3")
    if int(p.get("boosts_active") or 0) > 0:
        score += 1

    source = str(p.get("source") or "")
    if "smart_signal" in source:
        score += 8; reasons.append("GMGN Smart Money/KOL signal +8")
    elif "trenches" in source:
        score += 4; reasons.append("GMGN New Creation +4")

    fresh = cfg.get("fresh_launches", {})
    if fresh.get("enabled"):
        if age <= 2:
            score += 10; reasons.append("токен создан только что +10")
        elif age <= 5:
            score += 7; reasons.append("очень свежий токен +7")
        elif age <= fresh.get("max_age_minutes", 12):
            score += 3
        if mc <= 40000:
            score += 5; reasons.append("очень низкий ранний MC +5")

    return {
        "base_score": clamp(score, 0, 100),
        "eligible": len(hard) == 0,
        "hard_reasons": hard,
        "reasons": reasons,
        "age_minutes": age,
        "buy_fraction": buy_frac,
        "liq_mc_ratio": liq_mc,
        "vol_mc_ratio": vol_mc,
        "txns_5m": txns,
    }

def pattern_analysis(history_rows, p: dict, cfg: dict):
    st = cfg["strategy"]
    if len(history_rows) < st["min_history_points"]:
        return {
            "reclaim": False, "reason": "нужно больше локальной истории",
            "points": len(history_rows), "pattern_bonus": 0
        }
    mcs = [float(r["market_cap"]) for r in history_rows if r["market_cap"]]
    if len(mcs) < st["min_history_points"]:
        return {"reclaim": False, "reason": "мало MC-точек", "points": len(mcs), "pattern_bonus": 0}
    first = mcs[0]
    peak = max(mcs)
    peak_i = mcs.index(peak)
    if peak_i >= len(mcs)-1:
        return {
            "reclaim": False, "reason": "локальный максимум прямо сейчас",
            "first": first, "peak": peak, "pattern_bonus": 0
        }
    low_after = min(mcs[peak_i:])
    current = float(p.get("market_cap") or mcs[-1])
    pump = peak / max(first, 1) - 1
    pullback = 1 - low_after / max(peak, 1)
    rebound = current / max(low_after, 1) - 1
    distance = current / max(peak, 1)

    reclaim = (
        pump >= st["min_pump_pct"]
        and st["min_pullback_pct"] <= pullback <= st["max_pullback_pct"]
        and rebound >= st["min_rebound_pct"]
        and distance <= st["max_reclaim_distance_from_peak"]
        and current > low_after
    )
    bonus = 18 if reclaim else 0
    return {
        "reclaim": reclaim,
        "reason": "pump → pullback → rebound" if reclaim else "reclaim ещё не подтверждён",
        "first": first, "peak": peak, "low_after": low_after, "current": current,
        "pump_pct": pump, "pullback_pct": pullback, "rebound_pct": rebound,
        "distance_from_peak": distance, "pattern_bonus": bonus
    }

def early_momentum(market: dict, p: dict, cfg: dict):
    st = cfg["strategy"]
    if not st.get("early_momentum_enabled", True):
        return False
    change = float(p.get("price_change_m5") or 0)
    fresh = cfg.get("fresh_launches", {})
    if fresh.get("enabled"):
        age_sec = market["age_minutes"] * 60
        if age_sec < float(fresh.get("min_age_seconds_for_entry", 45)):
            return False
        if market["age_minutes"] > float(fresh.get("max_age_minutes", 12)):
            return False
        if change > float(fresh.get("max_entry_change_5m_pct", 45)):
            return False
    return (
        market["eligible"]
        and market["age_minutes"] <= st["momentum_max_age_minutes"]
        and st["momentum_min_change_5m_pct"] <= change <= st["momentum_max_change_5m_pct"]
        and market["buy_fraction"] >= st["momentum_min_buy_fraction"]
        and market["vol_mc_ratio"] >= st["momentum_min_volume_mc_ratio"]
    )

def assess(p: dict, history_rows, cfg: dict, security_eval=None):
    market = market_score(p, cfg)
    pattern = pattern_analysis(history_rows, p, cfg)
    sec_delta = float((security_eval or {}).get("score_delta") or 0)
    sec_status = (security_eval or {}).get("status", "UNKNOWN")
    hard_security = bool((security_eval or {}).get("hard_stops"))
    score = clamp(market["base_score"] + pattern.get("pattern_bonus", 0) + sec_delta, 0, 100)
    momentum = early_momentum(market, p, cfg)

    entry_type = None
    if market["eligible"] and not hard_security:
        if pattern.get("reclaim") and score >= cfg["strategy"]["entry_score"]:
            entry_type = "RECLAIM"
        elif momentum and score >= cfg["strategy"]["entry_score"] + 3:
            entry_type = "EARLY_MOMENTUM"

    if cfg["strategy"].get("require_gmgn_security_for_entry") and sec_status != "PASS":
        entry_type = None

    watch = market["eligible"] and score >= cfg["strategy"]["watch_score"]
    return {
        "score": round(score, 1),
        "watch": watch,
        "entry": bool(entry_type),
        "entry_type": entry_type,
        "market": market,
        "pattern": pattern,
        "security": security_eval or {"status": "UNKNOWN", "score_delta": 0},
    }
