
from __future__ import annotations
from .db import connect
from .utils import now_ts

def get_open_trade(token: str):
    con = connect()
    row = con.execute("SELECT * FROM paper_trades WHERE token=? AND status='OPEN' ORDER BY id DESC LIMIT 1", (token,)).fetchone()
    con.close()
    return dict(row) if row else None

def open_trade(token, symbol, entry_mc, cfg):
    if not cfg["paper"].get("enabled") or not cfg["paper"].get("auto_open_on_entry"):
        return None
    if get_open_trade(token):
        return None
    stake = float(cfg["paper"]["stake_usd"])
    con = connect()
    cur = con.execute("""
        INSERT INTO paper_trades(token,symbol,entry_ts,entry_mc,stake_usd,remaining_fraction,realized_value,current_mc,peak_mc,status)
        VALUES(?,?,?,?,?,1.0,0.0,?,?,'OPEN')
    """, (token, symbol, now_ts(), entry_mc, stake, entry_mc, entry_mc))
    trade_id = cur.lastrowid
    con.commit(); con.close()
    return trade_id

def _event(kind, trade, current_mc, text, pnl_pct=None):
    return {
        "kind": kind, "token": trade["token"], "symbol": trade["symbol"],
        "market_cap": current_mc, "text": text, "pnl_pct": pnl_pct
    }

def update_trade(token, current_mc, cfg):
    trade = get_open_trade(token)
    if not trade:
        return []
    p = cfg["paper"]
    entry = float(trade["entry_mc"])
    stake = float(trade["stake_usd"])
    remain = float(trade["remaining_fraction"])
    realized = float(trade["realized_value"])
    peak = max(float(trade["peak_mc"] or entry), float(current_mc))
    ratio = float(current_mc) / max(entry, 1e-9)
    pnl = ratio - 1
    entry_cost = float(p.get("estimated_entry_cost_pct", 0))
    exit_cost = float(p.get("estimated_exit_cost_pct", 0))
    net_entry_capital = stake * (1-entry_cost)
    events = []

    def sell_fraction(frac, label):
        nonlocal remain, realized
        actual = min(frac, remain)
        if actual <= 0:
            return
        realized += net_entry_capital * actual * ratio * (1-exit_cost)
        remain -= actual
        events.append(_event(label, trade, current_mc,
                             f"{label}: виртуально фиксируем {actual*100:.0f}% позиции при {pnl*100:+.1f}%", pnl))

    tp1_done, tp2_done, tp3_done = trade["tp1_done"], trade["tp2_done"], trade["tp3_done"]
    closed = False
    exit_reason = None

    if pnl <= -float(p["stop_loss_pct"]):
        sell_fraction(remain, "STOP")
        closed = True
        exit_reason = "STOP"
    else:
        if pnl >= float(p["tp1_pct"]) and not tp1_done:
            sell_fraction(float(p["tp1_sell_fraction"]), "TP1")
            tp1_done = 1
        if pnl >= float(p["tp2_pct"]) and not tp2_done:
            sell_fraction(float(p["tp2_sell_fraction"]), "TP2")
            tp2_done = 1
        if pnl >= float(p["tp3_pct"]) and not tp3_done:
            sell_fraction(float(p["tp3_sell_fraction"]), "TP3")
            tp3_done = 1

        if pnl >= float(p["trailing_start_pct"]) and remain > 0:
            drawdown = 1 - float(current_mc) / max(peak, 1)
            if drawdown >= float(p["trailing_drawdown_pct"]):
                sell_fraction(remain, "TRAIL")
                closed = True
                exit_reason = "TRAIL"

        held_min = (now_ts() - int(trade["entry_ts"])) / 60
        if (not closed and remain > 0 and held_min >= float(p["max_hold_minutes"])
                and pnl <= float(p["time_exit_max_pnl_pct"])):
            sell_fraction(remain, "TIME_EXIT")
            closed = True
            exit_reason = "TIME_EXIT"

    # Mark remaining position at an estimated net-exit value so paper PnL is conservative.
    final_value = realized + (net_entry_capital * remain * ratio * (1-exit_cost))
    pnl_usd = final_value - stake
    pnl_pct_total = pnl_usd / stake if stake else 0

    con = connect()
    if closed or remain <= 1e-9:
        if not exit_reason:
            exit_reason = "CLOSED"
        con.execute("""
            UPDATE paper_trades SET remaining_fraction=?,realized_value=?,current_mc=?,peak_mc=?,
                status='CLOSED',tp1_done=?,tp2_done=?,tp3_done=?,exit_ts=?,exit_mc=?,exit_reason=?,
                final_value=?,pnl_usd=?,pnl_pct=?
            WHERE id=?
        """, (remain, realized, current_mc, peak, tp1_done, tp2_done, tp3_done, now_ts(), current_mc,
              exit_reason, final_value, pnl_usd, pnl_pct_total, trade["id"]))
    else:
        con.execute("""
            UPDATE paper_trades SET remaining_fraction=?,realized_value=?,current_mc=?,peak_mc=?,
                tp1_done=?,tp2_done=?,tp3_done=?,final_value=?,pnl_usd=?,pnl_pct=?
            WHERE id=?
        """, (remain, realized, current_mc, peak, tp1_done, tp2_done, tp3_done,
              final_value, pnl_usd, pnl_pct_total, trade["id"]))
    con.commit(); con.close()

    if closed:
        events.append(_event("CLOSED", trade, current_mc,
                             f"Paper-сделка закрыта: {pnl_pct_total*100:+.1f}% (${pnl_usd:+.2f})",
                             pnl_pct_total))
    return events

def portfolio_stats():
    con = connect()
    rows = con.execute("SELECT * FROM paper_trades ORDER BY id").fetchall()
    con.close()
    rows = [dict(r) for r in rows]
    invested = sum(float(r["stake_usd"]) for r in rows)
    value = sum(float(r["final_value"] or r["stake_usd"]) for r in rows)
    pnl = value - invested
    closed = [r for r in rows if r["status"] == "CLOSED"]
    wins = [r for r in closed if float(r["pnl_usd"] or 0) > 0]
    return {
        "trades": len(rows), "open": sum(r["status"] == "OPEN" for r in rows),
        "closed": len(closed), "wins": len(wins),
        "win_rate": len(wins)/len(closed) if closed else 0,
        "invested": invested, "value": value, "pnl": pnl,
        "rows": rows
    }
