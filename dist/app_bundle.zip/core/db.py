
from __future__ import annotations
import sqlite3
from pathlib import Path
from contextlib import contextmanager
from .utils import now_ts, json_dumps

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "radar.db"

def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def connect():
    _ensure_data_dir()
    con = sqlite3.connect(str(DB_PATH), timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    return con

def init_db():
    con = connect()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS tokens(
        token TEXT PRIMARY KEY,
        symbol TEXT,
        name TEXT,
        pair_address TEXT,
        dex TEXT,
        url TEXT,
        image_url TEXT,
        source TEXT,
        created_ms INTEGER,
        last_seen_ts INTEGER,
        market_cap REAL,
        liquidity REAL,
        volume_m5 REAL,
        buys_m5 INTEGER,
        sells_m5 INTEGER,
        price_change_m5 REAL,
        price_usd REAL,
        score REAL DEFAULT 0,
        stage TEXT DEFAULT 'DISCOVERED',
        security_status TEXT DEFAULT 'UNKNOWN',
        setup_type TEXT,
        holder_count INTEGER DEFAULT 0,
        holders_per_min REAL DEFAULT 0,
        tx_per_min REAL DEFAULT 0,
        holder_growth_per_min REAL DEFAULT 0,
        smart_degen_count INTEGER DEFAULT 0,
        renowned_count INTEGER DEFAULT 0,
        crowd_score REAL DEFAULT 0,
        assessment_json TEXT
    );

    CREATE TABLE IF NOT EXISTS snapshots(
        token TEXT NOT NULL,
        ts INTEGER NOT NULL,
        market_cap REAL,
        liquidity REAL,
        volume_m5 REAL,
        buys_m5 INTEGER,
        sells_m5 INTEGER,
        price_change_m5 REAL,
        price_usd REAL,
        holder_count INTEGER DEFAULT 0,
        PRIMARY KEY(token, ts)
    );
    CREATE INDEX IF NOT EXISTS idx_snapshots_token_ts ON snapshots(token, ts);

    CREATE TABLE IF NOT EXISTS signals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL,
        token TEXT NOT NULL,
        symbol TEXT,
        kind TEXT NOT NULL,
        market_cap REAL,
        score REAL,
        title TEXT,
        message TEXT,
        details_json TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts DESC);

    CREATE TABLE IF NOT EXISTS token_state(
        token TEXT PRIMARY KEY,
        stage TEXT DEFAULT 'DISCOVERED',
        watch_ts INTEGER,
        entry_ts INTEGER,
        exit_ts INTEGER,
        entry_mc REAL,
        peak_mc REAL,
        last_signal_ts INTEGER DEFAULT 0,
        cooldown_until INTEGER DEFAULT 0,
        setup_type TEXT
    );

    CREATE TABLE IF NOT EXISTS paper_trades(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT NOT NULL,
        symbol TEXT,
        entry_ts INTEGER NOT NULL,
        entry_mc REAL NOT NULL,
        stake_usd REAL NOT NULL,
        remaining_fraction REAL NOT NULL DEFAULT 1.0,
        realized_value REAL NOT NULL DEFAULT 0.0,
        current_mc REAL,
        peak_mc REAL,
        status TEXT NOT NULL DEFAULT 'OPEN',
        tp1_done INTEGER DEFAULT 0,
        tp2_done INTEGER DEFAULT 0,
        tp3_done INTEGER DEFAULT 0,
        exit_ts INTEGER,
        exit_mc REAL,
        exit_reason TEXT,
        final_value REAL,
        pnl_usd REAL,
        pnl_pct REAL
    );
    CREATE INDEX IF NOT EXISTS idx_paper_status ON paper_trades(status);

    CREATE TABLE IF NOT EXISTS watchlist(
        token TEXT PRIMARY KEY,
        label TEXT,
        added_ts INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallets(
        wallet TEXT PRIMARY KEY,
        label TEXT,
        added_ts INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS security_cache(
        token TEXT PRIMARY KEY,
        checked_ts INTEGER NOT NULL,
        status TEXT,
        score_delta REAL DEFAULT 0,
        raw_json TEXT,
        summary_json TEXT
    );

    CREATE TABLE IF NOT EXISTS runtime(
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_ts INTEGER
    );

    CREATE TABLE IF NOT EXISTS logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL,
        level TEXT,
        message TEXT
    );
    """)
    # Lightweight schema migration for existing local databases.
    def add_col(table, name, definition):
        cols = {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
        if name not in cols:
            con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")
    for name, definition in [
        ("holder_count","INTEGER DEFAULT 0"),
        ("holders_per_min","REAL DEFAULT 0"),
        ("tx_per_min","REAL DEFAULT 0"),
        ("holder_growth_per_min","REAL DEFAULT 0"),
        ("smart_degen_count","INTEGER DEFAULT 0"),
        ("renowned_count","INTEGER DEFAULT 0"),
        ("crowd_score","REAL DEFAULT 0"),
    ]:
        add_col("tokens", name, definition)
    add_col("snapshots", "holder_count", "INTEGER DEFAULT 0")
    con.commit()
    con.close()

def log(level: str, message: str):
    con = connect()
    con.execute("INSERT INTO logs(ts,level,message) VALUES(?,?,?)", (now_ts(), level, str(message)[:4000]))
    con.commit(); con.close()

def set_runtime(key: str, value: str):
    con = connect()
    con.execute("""
    INSERT INTO runtime(key,value,updated_ts) VALUES(?,?,?)
    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_ts=excluded.updated_ts
    """, (key, value, now_ts()))
    con.commit(); con.close()

def get_runtime(key: str):
    con = connect()
    row = con.execute("SELECT value,updated_ts FROM runtime WHERE key=?", (key,)).fetchone()
    con.close()
    return dict(row) if row else None

def add_signal(token, symbol, kind, market_cap, score, title, message, details=None):
    con = connect()
    con.execute("""
    INSERT INTO signals(ts,token,symbol,kind,market_cap,score,title,message,details_json)
    VALUES(?,?,?,?,?,?,?,?,?)
    """, (now_ts(), token, symbol, kind, market_cap, score, title, message, json_dumps(details or {})))
    con.commit(); con.close()

def add_watchlist(token: str, label: str = ""):
    con = connect()
    con.execute("""
    INSERT INTO watchlist(token,label,added_ts) VALUES(?,?,?)
    ON CONFLICT(token) DO UPDATE SET label=excluded.label
    """, (token.strip(), label.strip(), now_ts()))
    con.commit(); con.close()

def remove_watchlist(token: str):
    con = connect()
    con.execute("DELETE FROM watchlist WHERE token=?", (token,))
    con.commit(); con.close()

def add_wallet(wallet: str, label: str = ""):
    con = connect()
    con.execute("""
    INSERT INTO wallets(wallet,label,added_ts) VALUES(?,?,?)
    ON CONFLICT(wallet) DO UPDATE SET label=excluded.label
    """, (wallet.strip(), label.strip(), now_ts()))
    con.commit(); con.close()

def remove_wallet(wallet: str):
    con = connect()
    con.execute("DELETE FROM wallets WHERE wallet=?", (wallet,))
    con.commit(); con.close()
