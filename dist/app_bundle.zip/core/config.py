
from __future__ import annotations
import json
import os
from pathlib import Path
from copy import deepcopy

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.json"
ENV_PATH = ROOT / ".env"

def load_config() -> dict:
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    changed = False

    # One-time migration for users updating from v2.5:
    # enable the new Fresh Launches mode without deleting their secrets/database.
    if "fresh_launches" not in cfg:
        cfg["fresh_launches"] = {
            "enabled": True,
            "max_age_minutes": 12,
            "min_age_seconds_for_entry": 45,
            "min_market_cap": 5000,
            "max_market_cap": 120000,
            "min_liquidity_usd": 2000,
            "min_volume_5m": 500,
            "min_txns_5m": 8,
            "min_buy_fraction": 0.56,
            "max_entry_change_5m_pct": 45,
            "gmgn_safe_preset": True
        }
        cfg.setdefault("filters", {}).update({
            "min_age_minutes": 0.0,
            "max_age_minutes": 12,
            "min_market_cap": 5000,
            "max_market_cap": 120000,
            "min_liquidity_usd": 2000,
            "min_liquidity_mc_ratio": 0.03,
            "min_volume_5m": 500,
            "min_txns_5m": 8,
            "min_buy_fraction": 0.53,
            "max_chase_change_5m_pct": 55
        })
        cfg.setdefault("strategy", {}).update({
            "watch_score": 45,
            "entry_score": 68,
            "momentum_max_age_minutes": 12,
            "momentum_min_change_5m_pct": 3,
            "momentum_max_change_5m_pct": 45,
            "momentum_min_buy_fraction": 0.58,
            "momentum_min_volume_mc_ratio": 0.04,
            "security_check_score": 45
        })
        cfg.setdefault("telegram", {})["notify_watch"] = True
        changed = True

    if "crowd_launches" not in cfg:
        cfg["crowd_launches"] = {
            "enabled": True,
            "max_age_minutes": 5,
            "min_holders_discovery": 20,
            "min_holders_watch": 30,
            "min_holders_entry": 45,
            "min_holders_per_min_entry": 12,
            "min_tx_per_min_entry": 20,
            "min_buy_fraction_entry": 0.55,
            "max_market_cap_entry": 60000,
            "max_top10_rate": 0.35,
            "max_dev_rate": 0.05,
            "max_sniper_rate": 0.10,
            "max_bundler_rate": 0.20,
            "max_insider_rate": 0.20
        }
        # Migration from Fresh Launches to Crowd Launches.
        cfg.setdefault("fresh_launches", {})["enabled"] = True
        cfg["fresh_launches"]["max_age_minutes"] = 5
        cfg["fresh_launches"]["min_age_seconds_for_entry"] = 30
        cfg["fresh_launches"]["max_market_cap"] = 80000
        cfg.setdefault("filters", {}).update({
            "max_age_minutes": 5, "max_market_cap": 80000,
            "min_liquidity_usd": 500, "min_liquidity_mc_ratio": 0.0,
            "min_volume_5m": 250, "min_txns_5m": 5, "min_buy_fraction": 0.50
        })
        cfg.setdefault("strategy", {}).update({
            "watch_score": 42, "entry_score": 66, "security_check_score": 40,
            "momentum_max_age_minutes": 5, "momentum_min_change_5m_pct": 0,
            "momentum_max_change_5m_pct": 50, "momentum_min_buy_fraction": 0.55,
            "momentum_min_volume_mc_ratio": 0.02
        })
        changed = True

    if "pre_pump" not in cfg:
        cfg["pre_pump"] = {
            "enabled": True, "history_seconds": 120, "min_history_points": 3,
            "min_age_seconds": 35, "max_age_minutes": 4,
            "min_holders": 35, "min_recent_holders_per_min": 15,
            "min_recent_tx_per_min": 25, "min_recent_buy_fraction": 0.58,
            "min_holder_accel_ratio": 1.18, "min_tx_accel_ratio": 1.18,
            "min_acceleration_score": 65, "entry_acceleration_score": 75,
            "min_total_score": 65, "max_market_cap": 50000,
            "max_mc_growth_60s": 2.00, "explosive_holders": 65,
            "explosive_hpm": 45, "explosive_txpm": 80
        }
        cfg.setdefault("app", {}).update({"scan_interval_seconds": 10, "max_scan_tokens": 160})
        cfg.setdefault("filters", {}).update({
            "max_age_minutes": 5, "max_market_cap": 90000, "min_liquidity_usd": 400,
            "min_volume_5m": 150, "min_txns_5m": 4, "min_buy_fraction": 0.50,
            "max_chase_change_5m_pct": 300
        })
        cfg.setdefault("fresh_launches", {}).update({
            "max_age_minutes": 5, "min_age_seconds_for_entry": 35,
            "max_market_cap": 90000, "min_liquidity_usd": 400,
            "min_volume_5m": 150, "min_txns_5m": 4,
            "min_buy_fraction": 0.52, "max_entry_change_5m_pct": 200
        })
        cfg.setdefault("crowd_launches", {}).update({
            "min_holders_discovery": 12, "min_holders_watch": 25,
            "min_holders_entry": 50, "min_holders_per_min_entry": 15,
            "min_tx_per_min_entry": 25, "min_buy_fraction_watch": 0.52,
            "min_buy_fraction_entry": 0.56, "max_market_cap_entry": 65000,
            "max_sniper_count": 25
        })
        cfg.setdefault("strategy", {}).update({
            "watch_score": 45, "entry_score": 78, "security_check_score": 42,
            "momentum_max_age_minutes": 5, "momentum_max_change_5m_pct": 200,
            "momentum_min_buy_fraction": 0.55, "momentum_min_volume_mc_ratio": 0.015
        })
        cfg.setdefault("test_bets", {})["auto_open_on_prepump"] = True
        cfg.setdefault("telegram", {})["notify_prepump"] = True
        changed = True

    if "test_bets" not in cfg:
        cfg["test_bets"] = {
            "enabled": True,
            "default_stake_usd": 10.0,
            "auto_open_on_entry": True,
            "allow_multiple_per_token": True,
            "estimated_entry_cost_pct": 0.0,
            "estimated_exit_cost_pct": 0.0,
            "snapshot_interval_seconds": 20
        }
        changed = True

    if "auto_open_on_prepump" not in cfg.setdefault("test_bets", {}):
        cfg["test_bets"]["auto_open_on_prepump"] = True
        changed = True
    if "auto_close_minutes" not in cfg.setdefault("test_bets", {}):
        cfg["test_bets"]["auto_close_minutes"] = 60
        changed = True
    if "notify_prepump" not in cfg.setdefault("telegram", {}):
        cfg["telegram"]["notify_prepump"] = True
        changed = True

    if "updates" not in cfg:
        cfg["updates"] = {"auto_update": True, "check_on_startup": True}
        changed = True

    if changed:
        save_config(cfg)

    return cfg

def save_config(cfg: dict) -> None:
    tmp = CONFIG_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CONFIG_PATH)

def read_env_file() -> dict:
    out = {}
    if not ENV_PATH.exists():
        return out
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out

def write_env_values(values: dict) -> None:
    current = read_env_file()
    for k, v in values.items():
        if v is None:
            continue
        current[k] = str(v).strip()
    lines = [
        "# Local secrets for Skobin Meme Radar. Never share this file.",
        *[f"{k}={v}" for k, v in current.items()]
    ]
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")

def env_value(key: str, default: str = "") -> str:
    if key in os.environ:
        return os.environ.get(key, default)
    return read_env_file().get(key, default)
