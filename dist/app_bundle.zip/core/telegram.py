
from __future__ import annotations
import requests
from .config import env_value

def configured():
    return bool(env_value("TELEGRAM_BOT_TOKEN") and env_value("TELEGRAM_CHAT_ID"))

def send(text: str):
    token = env_value("TELEGRAM_BOT_TOKEN")
    chat_id = env_value("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return False, "Telegram не настроен"
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text[:4096], "disable_web_page_preview": True},
            timeout=15
        )
        data = r.json()
        if not r.ok or not data.get("ok"):
            return False, data.get("description", r.text[:300])
        return True, "OK"
    except Exception as e:
        return False, str(e)

def get_me():
    token = env_value("TELEGRAM_BOT_TOKEN")
    if not token:
        return False, "Token не задан"
    try:
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=15)
        data = r.json()
        return bool(data.get("ok")), data
    except Exception as e:
        return False, str(e)
