
from __future__ import annotations
import requests
from .config import env_value

def configured():
    return bool(env_value("TELEGRAM_BOT_TOKEN") and env_value("TELEGRAM_CHAT_ID"))

def send(text: str):
    token = env_value("TELEGRAM_BOT_TOKEN")
    chat_id = env_value("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return False, "Telegram не настроен"
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text[:4096], "disable_web_page_preview": True},
            timeout=15
        )
        data = r.json()
        if not r.ok or not data.get("ok"):
            return False, data.get("description", r.text[:300])
        return True, "OK"
    except Exception as e:
        return False, str(e)

def get_me():
    token = env_value("TELEGRAM_BOT_TOKEN")
    if not token:
        return False, "Token не задан"
    try:
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=15)
        data = r.json()
        return bool(data.get("ok")), data
    except Exception as e:
        return False, str(e)


def detect_chat_id():
    """Find the most recent private chat that messaged the bot."""
    token = env_value("TELEGRAM_BOT_TOKEN")
    if not token:
        return False, "Сначала вставь Bot token и нажми «Сохранить»."
    try:
        r = requests.get(
            f"https://api.telegram.org/bot{token}/getUpdates",
            params={"limit": 100, "timeout": 0, "allowed_updates": '["message"]'},
            timeout=15,
        )
        data = r.json()
        if not r.ok or not data.get("ok"):
            return False, data.get("description", r.text[:300])
        updates = data.get("result") or []
        for upd in reversed(updates):
            msg = upd.get("message") or {}
            chat = msg.get("chat") or {}
            cid = chat.get("id")
            if cid is not None:
                who = chat.get("username") or chat.get("first_name") or str(cid)
                return True, {"chat_id": str(cid), "name": who}
        return False, "Сообщений от тебя ещё нет. Открой своего бота в Telegram, нажми Start или отправь /start, затем нажми «Найти Chat ID» ещё раз."
    except Exception as e:
        return False, str(e)
