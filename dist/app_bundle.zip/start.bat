@echo off
setlocal
cd /d "%~dp0"
title Skobin Meme Radar Setup

echo.
echo ==========================================
echo        SKOBIN MEME RADAR
echo ==========================================
echo.

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating Python environment...
  py -3 -m venv .venv 2>nul
  if errorlevel 1 python -m venv .venv
  if errorlevel 1 (
    echo Python 3 not found. Install Python 3.11+ and enable "Add Python to PATH".
    pause
    exit /b 1
  )
)

echo [2/3] Installing/updating dependencies...
".venv\Scripts\python.exe" -m pip install -q --upgrade pip
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed.
  pause
  exit /b 1
)

echo [3/3] Starting scanner and dashboard...
if not exist "data" mkdir "data"
if exist "data\engine.pid" (
  set /p OLD_PID=<"data\engine.pid"
  tasklist /FI "PID eq %OLD_PID%" 2>nul | find "%OLD_PID%" >nul
  if errorlevel 1 del /q "data\engine.pid" >nul 2>&1
)

if not exist "data\engine.pid" (
  start "Skobin Meme Radar Engine" /min ".venv\Scripts\python.exe" engine.py
  timeout /t 2 /nobreak >nul
)

echo Dashboard: http://127.0.0.1:8501
echo Close this window to stop the dashboard. Use stop.bat to stop the scanner.
".venv\Scripts\python.exe" -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --browser.gatherUsageStats false
endlocal
