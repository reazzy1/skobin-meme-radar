from __future__ import annotations

import copy
import time
from core.config import load_config
from core.strategy import assess

CFG = load_config()
NOW = int(time.time())

def snap(seconds_ago, mc, holders, buys, sells, vol):
    return {
        "ts": NOW-seconds_ago, "market_cap": mc, "liquidity": 1200,
        "volume_m5": vol, "buys_m5": buys, "sells_m5": sells,
        "price_change_m5": 0, "holder_count": holders, "net_buy_usd": 1200,
    }

security = {"status":"PASS","score_delta":3,"hard_stops":[],"warnings":[],"metrics":{
    "top10_rate":.20,"dev_rate":.01
}}

history = [
    snap(40,8500,20,18,7,600),
    snap(30,9200,24,24,8,850),
    snap(20,10500,31,36,10,1400),
    snap(10,12800,42,53,14,2250),
]
p = {
    "created_ms": (NOW-55)*1000, "market_cap":15500, "liquidity":1500,
    "volume_m5":3600, "buys_m5":78, "sells_m5":22, "price_change_m5":55,
    "holder_count":58, "holders_per_min":63, "holder_growth_per_min":55,
    "tx_per_min":100, "swaps_1m":100, "net_buy_usd":1800,
    "top_holder_rate":.20,"dev_rate":.01,"sniper_rate":.01,"sniper_count":2,
    "bundler_rate":.02,"insider_rate":.01,"rug_ratio":.05,"is_wash_trading":False,
    "source":"gmgn_new_creation","smart_degen_count":1,"renowned_count":0,"socials_count":1,
}
a = assess(p, history, CFG, security)
assert a["pre_pump"], a
assert a["acceleration"]["score"] >= CFG["pre_pump"]["min_acceleration_score"], a

# LENNY-like first sight: surface immediately via explosive override, wait for follow-up before ENTRY.
p2 = copy.deepcopy(p)
p2.update({
    "created_ms":(NOW-49)*1000,"market_cap":8270,"liquidity":1110,"volume_m5":18600,
    "buys_m5":190,"sells_m5":107,"holder_count":76,"holders_per_min":93,
    "holder_growth_per_min":0,"tx_per_min":297,"swaps_1m":297,"net_buy_usd":2400,
    "top_holder_rate":.215,"dev_rate":0,"sniper_rate":0,"sniper_count":0,
    "bundler_rate":0,"insider_rate":0,"rug_ratio":.03,
})
a2 = assess(p2, [], CFG, security)
assert a2["pre_pump"], a2
assert a2["acceleration"]["explosive_override"], a2
assert not a2["entry"], a2

# Weak/flat crowd must not trigger.
history3=[snap(40,9000,22,15,10,500),snap(30,9100,24,17,11,550),snap(20,9000,25,19,13,600),snap(10,9050,26,21,15,640)]
p3=copy.deepcopy(p)
p3.update({"created_ms":(NOW-70)*1000,"market_cap":9100,"liquidity":1000,"volume_m5":660,"buys_m5":22,"sells_m5":17,"holder_count":27,"holders_per_min":23,"tx_per_min":33,"swaps_1m":33,"net_buy_usd":80,"smart_degen_count":0})
a3=assess(p3,history3,CFG,security)
assert not a3["pre_pump"], a3
assert not a3["entry"], a3

print("v3 strategy regression tests: OK")
