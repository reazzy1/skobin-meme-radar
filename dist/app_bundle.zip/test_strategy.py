
from core.strategy import market_score, assess
from core.config import load_config
import time

cfg = load_config()
p = {
    "created_ms": int((time.time()-8*60)*1000),
    "market_cap": 42000,
    "liquidity": 12000,
    "volume_m5": 11000,
    "buys_m5": 80,
    "sells_m5": 42,
    "price_change_m5": 16,
    "socials_count": 1,
    "boosts_active": 0,
    "source": "gmgn_smart_signal",
}
m = market_score(p, cfg)
assert m["eligible"], m
assert m["base_score"] >= 60, m
history = [
    {"market_cap":30000},
    {"market_cap":42000},
    {"market_cap":34000},
    {"market_cap":38000},
]
a = assess(p, history, cfg, {"status":"PASS","score_delta":5,"hard_stops":[]})
assert a["score"] >= m["base_score"]
print("OK", a["score"], a["entry_type"])
