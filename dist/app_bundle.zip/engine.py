
from __future__ import annotations
import json
import os
import signal
import sys
import time
import traceback
from pathlib import Path

from core.config import load_config
from core.db import init_db, connect, log, set_runtime, add_signal
from core.dexscreener import discover_addresses as dex_discover, fetch_tokens, PairData
from core import gmgn
from core.strategy import market_score, assess
from core.paper import open_trade, update_trade, get_open_trade
from core.test_bets import open_test_bet, update_open_test_bets
from core.telegram import send as tg_send
from core.utils import now_ts, json_dumps, json_loads, fmt_usd

ROOT = Path(__file__).resolve().parent
PID_FILE = ROOT / "data" / "engine.pid"

GMGN_DISCOVERY_CACHE = {}
GMGN_META_CACHE = {}
GMGN_TRENCH_TS = 0
GMGN_TREND_TS = 0
GMGN_SIGNAL_TS = 0
GMGN_READY_CACHE = (0, False, "")
SECURITY_CHECKS_THIS_CYCLE = 0

def write_pid():
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")

def cleanup(*_):
    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass
    set_runtime("engine_status", "stopped")
    sys.exit(0)

def _live_rates(p):
    age = max((time.time()*1000 - float(p.created_ms or 0))/60000.0, 0.15) if p.created_ms else 999
    p.holders_per_min = float(p.holder_count or 0) / max(age, 0.25)
    p.tx_per_min = float(p.swaps_1m or 0) if int(p.swaps_1m or 0) > 0 else float((p.buys_m5 or 0) + (p.sells_m5 or 0)) / max(min(age,5), 0.25)
    # Holder acceleration from the most recent previous snapshot.
    con = connect()
    prev = con.execute(
        "SELECT ts,holder_count FROM snapshots WHERE token=? AND holder_count>0 ORDER BY ts DESC LIMIT 1",
        (p.token,)
    ).fetchone()
    con.close()
    if prev and int(prev["holder_count"] or 0) > 0:
        mins = max((now_ts()-int(prev["ts"]))/60.0, 0.05)
        p.holder_growth_per_min = (int(p.holder_count or 0)-int(prev["holder_count"] or 0))/mins
    return p

def upsert_pair(p, source):
    p = _live_rates(p)
    d = p.to_dict()
    con = connect()
    con.execute("""
    INSERT INTO tokens(token,symbol,name,pair_address,dex,url,image_url,source,created_ms,last_seen_ts,
        market_cap,liquidity,volume_m5,buys_m5,sells_m5,price_change_m5,price_usd,
        holder_count,holders_per_min,tx_per_min,holder_growth_per_min,smart_degen_count,renowned_count,
        net_buy_usd,is_wash_trading)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(token) DO UPDATE SET
        symbol=excluded.symbol,name=excluded.name,pair_address=excluded.pair_address,dex=excluded.dex,
        url=excluded.url,image_url=excluded.image_url,source=excluded.source,created_ms=excluded.created_ms,
        last_seen_ts=excluded.last_seen_ts,market_cap=excluded.market_cap,liquidity=excluded.liquidity,
        volume_m5=excluded.volume_m5,buys_m5=excluded.buys_m5,sells_m5=excluded.sells_m5,
        price_change_m5=excluded.price_change_m5,price_usd=excluded.price_usd,
        holder_count=excluded.holder_count,holders_per_min=excluded.holders_per_min,
        tx_per_min=excluded.tx_per_min,holder_growth_per_min=excluded.holder_growth_per_min,
        smart_degen_count=excluded.smart_degen_count,renowned_count=excluded.renowned_count,
        net_buy_usd=excluded.net_buy_usd,is_wash_trading=excluded.is_wash_trading
    """, (
        d["token"],d["symbol"],d["name"],d["pair_address"],d["dex"],d["url"],d["image_url"],
        source,d["created_ms"],now_ts(),d["market_cap"],d["liquidity"],d["volume_m5"],
        d["buys_m5"],d["sells_m5"],d["price_change_m5"],d["price_usd"],
        d["holder_count"],d["holders_per_min"],d["tx_per_min"],d["holder_growth_per_min"],
        d["smart_degen_count"],d["renowned_count"],d.get("net_buy_usd",0),int(bool(d.get("is_wash_trading")))
    ))
    con.execute("""
    INSERT OR REPLACE INTO snapshots(token,ts,market_cap,liquidity,volume_m5,buys_m5,sells_m5,price_change_m5,price_usd,holder_count,net_buy_usd)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)
    """, (d["token"],now_ts(),d["market_cap"],d["liquidity"],d["volume_m5"],d["buys_m5"],
          d["sells_m5"],d["price_change_m5"],d["price_usd"],d["holder_count"],d.get("net_buy_usd",0)))
    con.commit(); con.close()

def enrich_pairs(pairs, addresses, source_map):
    by = {p.token:p for p in pairs}
    for token in addresses:
        meta = GMGN_META_CACHE.get(token) or {}
        p = by.get(token)
        if p is None and meta and meta.get("market_cap") and meta.get("created_ms"):
            p = PairData(
                token=token, symbol=meta.get("symbol") or "?", name=meta.get("name") or "?",
                pair_address="", dex=meta.get("launchpad_platform") or "launchpad",
                url=f"https://axiom.trade/t/{token}?chain=sol", image_url="",
                created_ms=int(meta.get("created_ms") or 0), market_cap=float(meta.get("market_cap") or 0),
                liquidity=float(meta.get("liquidity") or 0), volume_m5=float(meta.get("volume") or 0),
                buys_m5=int(meta.get("buys") or 0), sells_m5=int(meta.get("sells") or 0),
                price_change_m5=0.0, price_usd=0.0, socials_count=0, boosts_active=0,
                source=source_map.get(token,"gmgn_new_creation")
            )
            by[token]=p
        if p is None:
            continue
        p.source = source_map.get(token,p.source)
        if meta:
            # GMGN is the authority for crowd/on-chain fields; DEX Screener remains primary for live price/txns.
            p.holder_count = int(meta.get("holder_count") or p.holder_count or 0)
            p.swaps_1m = int(meta.get("swaps_1m") or 0)
            p.swaps_1h = int(meta.get("swaps_1h") or 0)
            p.smart_degen_count = int(meta.get("smart_degen_count") or 0)
            p.renowned_count = int(meta.get("renowned_count") or 0)
            p.top_holder_rate = float(meta.get("top_holder_rate") or 0)
            p.dev_rate = float(meta.get("dev_rate") or 0)
            p.sniper_rate = float(meta.get("sniper_rate") or 0)
            p.bundler_rate = float(meta.get("bundler_rate") or 0)
            p.insider_rate = float(meta.get("insider_rate") or 0)
            p.rug_ratio = float(meta.get("rug_ratio") or 0)
            p.progress = float(meta.get("progress") or 0)
            p.net_buy_usd = float(meta.get("net_buy_usd") or 0)
            p.is_wash_trading = bool(meta.get("is_wash_trading"))
            p.sniper_count = int(meta.get("sniper_count") or 0)
            p.bot_degen_rate = float(meta.get("bot_degen_rate") or 0)
            p.fresh_wallet_rate = float(meta.get("fresh_wallet_rate") or 0)
            if not p.created_ms: p.created_ms=int(meta.get("created_ms") or 0)
            if not p.market_cap: p.market_cap=float(meta.get("market_cap") or 0)
            if not p.liquidity: p.liquidity=float(meta.get("liquidity") or 0)
            if not p.volume_m5: p.volume_m5=float(meta.get("volume") or 0)
            if not (p.buys_m5+p.sells_m5):
                p.buys_m5=int(meta.get("buys") or 0); p.sells_m5=int(meta.get("sells") or 0)
    return list(by.values())

def get_history(token, cfg):
    cutoff = now_ts() - int(cfg["strategy"]["lookback_minutes"] * 60)
    con = connect()
    rows = con.execute("""
        SELECT ts,market_cap,liquidity,volume_m5,buys_m5,sells_m5,price_change_m5,holder_count,net_buy_usd
        FROM snapshots WHERE token=? AND ts>=? ORDER BY ts
    """, (token, cutoff)).fetchall()
    con.close()
    return [dict(r) for r in rows]

def prune(cfg):
    cutoff = now_ts() - int(cfg["app"]["snapshot_retention_hours"] * 3600)
    con = connect()
    con.execute("DELETE FROM snapshots WHERE ts < ?", (cutoff,))
    con.execute("DELETE FROM logs WHERE ts < ?", (now_ts()-7*86400,))
    con.commit(); con.close()

def gmgn_ready(force=False):
    global GMGN_READY_CACHE
    ts, ready, msg = GMGN_READY_CACHE
    if not force and now_ts() - ts < 120:
        return ready, msg
    if not gmgn.installed():
        GMGN_READY_CACHE = (now_ts(), False, "gmgn-cli не установлен")
        return False, GMGN_READY_CACHE[2]
    ok, msg = gmgn.check_config()
    GMGN_READY_CACHE = (now_ts(), ok, msg)
    return ok, msg

def discover(cfg):
    global GMGN_TRENCH_TS, GMGN_TREND_TS, GMGN_SIGNAL_TS, GMGN_DISCOVERY_CACHE, GMGN_META_CACHE
    source_map = {}
    errors = []
    fresh = cfg.get("fresh_launches", {})
    fresh_only = bool(fresh.get("enabled", False))

    # Keep manually watched/open paper positions regardless of age so exits continue working.
    con = connect()
    for row in con.execute("SELECT token FROM watchlist").fetchall():
        source_map[row["token"]] = "manual_watch"
    for row in con.execute("SELECT token FROM paper_trades WHERE status='OPEN'").fetchall():
        source_map[row["token"]] = "paper_open"
    for row in con.execute("SELECT DISTINCT token FROM test_bets WHERE status='OPEN'").fetchall():
        source_map[row["token"]] = "test_bet_open"
    con.close()

    ready = False
    if cfg["discovery"].get("gmgn_enabled", True):
        ready, msg = gmgn_ready()
        if ready:
            chain = cfg["gmgn"].get("chain", "sol")
            # Fresh mode intentionally uses ONLY new_creation.
            if cfg["discovery"].get("gmgn_trenches_enabled", True) and now_ts()-GMGN_TRENCH_TS >= 15:
                try:
                    addrs, raw = gmgn.discover_trenches(
                        chain,
                        fresh_only=fresh_only,
                        safe=bool(fresh.get("gmgn_safe_preset", True)),
                        crowd=cfg.get("crowd_launches", {})
                    )
                    GMGN_DISCOVERY_CACHE["trenches"] = addrs
                    GMGN_META_CACHE.update(gmgn.trenches_meta(raw))
                    GMGN_TRENCH_TS = now_ts()
                except Exception as e:
                    errors.append("GMGN trenches: " + str(e)[:300])

            if not fresh_only:
                if cfg["discovery"].get("gmgn_trending_enabled", True) and now_ts()-GMGN_TREND_TS >= 60:
                    try:
                        addrs, raw = gmgn.discover_trending(chain)
                        GMGN_DISCOVERY_CACHE["trending"] = addrs
                        GMGN_TREND_TS = now_ts()
                    except Exception as e:
                        errors.append("GMGN trending: " + str(e)[:300])
                if cfg["discovery"].get("gmgn_signals_enabled", True) and now_ts()-GMGN_SIGNAL_TS >= 30:
                    try:
                        addrs, raw = gmgn.discover_smart_signals(chain, cfg["filters"]["max_market_cap"])
                        GMGN_DISCOVERY_CACHE["smart_signal"] = addrs
                        GMGN_SIGNAL_TS = now_ts()
                    except Exception as e:
                        errors.append("GMGN smart signals: " + str(e)[:300])

            for a in GMGN_DISCOVERY_CACHE.get("trenches", []):
                source_map.setdefault(a, "gmgn_new_creation" if fresh_only else "gmgn_trenches")
            if not fresh_only:
                for a in GMGN_DISCOVERY_CACHE.get("trending", []):
                    source_map.setdefault(a, "gmgn_trending")
                for a in GMGN_DISCOVERY_CACHE.get("smart_signal", []):
                    source_map[a] = "gmgn_smart_signal"
        else:
            set_runtime("gmgn_status", "not_ready: " + msg[:200])

    # DEX Screener latest-profile fallback if GMGN is not ready.
    # This is useful, but it is NOT a complete new-token firehose.
    if (not ready) and cfg["discovery"].get("dexscreener_enabled", True):
        dex, errs = dex_discover()
        for a, s in dex.items():
            source_map.setdefault(a, "dex_fresh_fallback" if fresh_only else s)
        errors.extend(errs)

    return source_map, errors

def get_security_cached(token, cfg, allow_fetch=True):
    global SECURITY_CHECKS_THIS_CYCLE
    cache_sec = int(cfg["gmgn"]["security_cache_seconds"])
    con = connect()
    row = con.execute("SELECT * FROM security_cache WHERE token=?", (token,)).fetchone()
    con.close()
    if row and now_ts() - int(row["checked_ts"]) <= cache_sec:
        return json_loads(row["summary_json"], {"status":"UNKNOWN","score_delta":0})

    if not allow_fetch:
        return json_loads(row["summary_json"], {"status":"UNKNOWN","score_delta":0}) if row else None
    if SECURITY_CHECKS_THIS_CYCLE >= int(cfg["gmgn"]["max_security_checks_per_cycle"]):
        return json_loads(row["summary_json"], {"status":"UNKNOWN","score_delta":0}) if row else None
    ready, _ = gmgn_ready()
    if not ready:
        return None

    try:
        SECURITY_CHECKS_THIS_CYCLE += 1
        raw = gmgn.token_security(token, cfg["gmgn"].get("chain","sol"))
        ev = gmgn.evaluate_security(raw)
        con = connect()
        con.execute("""
        INSERT INTO security_cache(token,checked_ts,status,score_delta,raw_json,summary_json)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(token) DO UPDATE SET checked_ts=excluded.checked_ts,status=excluded.status,
            score_delta=excluded.score_delta,raw_json=excluded.raw_json,summary_json=excluded.summary_json
        """, (token, now_ts(), ev["status"], ev["score_delta"], json_dumps(raw), json_dumps(ev)))
        con.commit(); con.close()
        return ev
    except Exception as e:
        log("WARN", f"GMGN security {token}: {e}")
        return None

def ensure_state(token):
    con = connect()
    con.execute("INSERT OR IGNORE INTO token_state(token,stage) VALUES(?,'DISCOVERED')", (token,))
    con.commit()
    row = con.execute("SELECT * FROM token_state WHERE token=?", (token,)).fetchone()
    con.close()
    return dict(row)

def update_state(token, **fields):
    if not fields:
        return
    con = connect()
    sets = ",".join(f"{k}=?" for k in fields)
    con.execute(f"UPDATE token_state SET {sets} WHERE token=?", list(fields.values()) + [token])
    con.commit(); con.close()

def update_token_assessment(token, assessment, stage=None, setup_type=None):
    sec = assessment.get("security") or {}
    acc = assessment.get("acceleration") or {}
    con = connect()
    con.execute("""
        UPDATE tokens SET score=?, security_status=?, crowd_score=?, acceleration_score=?,
            holder_accel_ratio=?,tx_accel_ratio=?,recent_buy_fraction=?,volume_velocity=?,mc_growth_60s=?,
            pre_pump_ready=?,assessment_json=?,stage=COALESCE(?,stage),setup_type=COALESCE(?,setup_type)
        WHERE token=?
    """, (assessment["score"], sec.get("status","UNKNOWN"),
          float((assessment.get("crowd") or {}).get("score_bonus") or 0), float(acc.get("score") or 0),
          float(acc.get("holder_accel_ratio") or 0), float(acc.get("tx_accel_ratio") or 0),
          float(acc.get("recent_buy_fraction") or 0), float(acc.get("volume_velocity_usd_min") or 0),
          float(acc.get("mc_growth_60s") or 0), int(bool(assessment.get("pre_pump"))), json_dumps(assessment),
          stage, setup_type, token))
    con.commit(); con.close()

def notify(cfg, kind, text):
    t = cfg["telegram"]
    should = ((kind == "WATCH" and t.get("notify_watch")) or
              (kind == "PRE_PUMP" and t.get("notify_prepump", True)) or
              (kind == "ENTRY" and t.get("notify_entry")) or
              (kind not in {"WATCH","PRE_PUMP","ENTRY"} and t.get("notify_exits")))
    if should:
        ok, msg = tg_send(text)
        if not ok:
            log("WARN", "Telegram: " + str(msg))

def emit_watch(p, assessment, cfg):
    m = assessment["market"]
    text = (
        f"🟡 WATCH — {p.symbol}\n"
        f"Score {assessment['score']:.0f}/100 | MC {fmt_usd(p.market_cap)} | Liq {fmt_usd(p.liquidity)}\n"
        f"5m vol {fmt_usd(p.volume_m5)} | buy share {m['buy_fraction']*100:.0f}% | 5m {p.price_change_m5:+.1f}%\n"
        f"👥 Holders {p.holder_count} | {p.holders_per_min:.0f}/min | tx {p.tx_per_min:.0f}/min\n"
        f"Возраст {m['age_minutes']:.1f} мин. Пока наблюдаем, это НЕ сигнал купить.\n"
        f"Axiom: https://axiom.trade/t/{p.token}?chain=sol\n"
        f"{p.url}"
    )
    add_signal(p.token,p.symbol,"WATCH",p.market_cap,assessment["score"],"Ранний кандидат",text,assessment)
    notify(cfg,"WATCH",text)

def emit_prepump(p, assessment, cfg):
    m = assessment["market"]; a = assessment.get("acceleration") or {}
    net = float(a.get("net_buy_usd") or 0)
    text = (
        f"🚀 PRE-PUMP — {p.symbol}\n"
        f"Acceleration {a.get('score',0):.0f}/100 ({a.get('level','—')}) | Total score {assessment['score']:.0f}/100\n"
        f"Age {m['age_minutes']*60:.0f}s | MC {fmt_usd(p.market_cap)} | Liq {fmt_usd(p.liquidity)}\n"
        f"👥 {p.holder_count} holders | recent {a.get('recent_holders_per_min',0):.0f} H/min | accel x{a.get('holder_accel_ratio',0):.2f}\n"
        f"⚡ {a.get('recent_tx_per_min',0):.0f} tx/min | accel x{a.get('tx_accel_ratio',0):.2f} | fresh buys {a.get('recent_buy_fraction',0)*100:.0f}%\n"
        f"Volume speed {fmt_usd(a.get('volume_velocity_usd_min',0))}/min | 60s MC {a.get('mc_growth_60s',0)*100:+.0f}%"
        + (f" | Net buy {fmt_usd(net)}" if net else "") + "\n"
        f"Это ранний алгоритмический сигнал ускорения, а не гарантия роста.\n"
        f"Axiom: https://axiom.trade/t/{p.token}?chain=sol\nCA: {p.token}"
    )
    add_signal(p.token,p.symbol,"PRE_PUMP",p.market_cap,assessment["score"],"Ускорение толпы",text,assessment)
    notify(cfg,"PRE_PUMP",text)
    tb = cfg.get("test_bets", {})
    if tb.get("enabled", True) and tb.get("auto_open_on_prepump", True):
        try:
            open_test_bet(p.token,p.symbol,p.market_cap,p.price_usd,tb.get("default_stake_usd",10),
                          source="AUTO_PRE_PUMP",signal_score=assessment.get("score"),cfg=cfg)
        except Exception as e:
            log("WARN", f"auto PRE_PUMP test bet {p.token}: {e}")

def smart_money_count(token, cfg):
    if not cfg["gmgn"].get("smart_money_check_on_entry", True):
        return None
    ready, _ = gmgn_ready()
    if not ready:
        return None
    try:
        raw = gmgn.smart_holders(token, cfg["gmgn"].get("chain","sol"), 10)
        return gmgn.count_smart_holders(raw)
    except Exception as e:
        log("WARN", f"smart holders {token}: {e}")
        return None

def emit_entry(p, assessment, cfg):
    paper = cfg["paper"]
    stop_mc = p.market_cap*(1-paper["stop_loss_pct"])
    tp1 = p.market_cap*(1+paper["tp1_pct"])
    tp2 = p.market_cap*(1+paper["tp2_pct"])
    tp3 = p.market_cap*(1+paper["tp3_pct"])
    sm = smart_money_count(p.token, cfg)
    sec = assessment.get("security") or {}
    security_text = sec.get("status","UNKNOWN")
    sm_text = f"{sm}" if sm is not None else "не проверено"
    text = (
        f"🟢 ENTRY SETUP — {p.symbol} [{assessment['entry_type']}]\n"
        f"Score {assessment['score']:.0f}/100 | MC {fmt_usd(p.market_cap)} | Liq {fmt_usd(p.liquidity)}\n"
        f"5m vol {fmt_usd(p.volume_m5)} | buys/sells {p.buys_m5}/{p.sells_m5} | 5m {p.price_change_m5:+.1f}%\n"
        f"👥 Holders {p.holder_count} | {p.holders_per_min:.0f}/min | tx {p.tx_per_min:.0f}/min\n"
        f"🚀 Acceleration {(assessment.get('acceleration') or {}).get('score',0):.0f}/100 | H x{(assessment.get('acceleration') or {}).get('holder_accel_ratio',0):.2f} | tx x{(assessment.get('acceleration') or {}).get('tx_accel_ratio',0):.2f}\n"
        f"GMGN security: {security_text} | smart-money holders: {sm_text}\n\n"
        f"Paper levels from this signal:\n"
        f"🛑 invalidation ~ {fmt_usd(stop_mc)} (-{paper['stop_loss_pct']*100:.0f}%)\n"
        f"💰 TP1 ~ {fmt_usd(tp1)} (+{paper['tp1_pct']*100:.0f}%)\n"
        f"💰 TP2 ~ {fmt_usd(tp2)} (+{paper['tp2_pct']*100:.0f}%)\n"
        f"🚀 TP3 ~ {fmt_usd(tp3)} (+{paper['tp3_pct']*100:.0f}%)\n"
        f"После +{paper['trailing_start_pct']*100:.0f}% используется trailing drawdown {paper['trailing_drawdown_pct']*100:.0f}%.\n\n"
        f"Это алгоритмический сигнал, не гарантия роста. Проверь токен перед реальной сделкой.\n"
        f"{p.url}\nCA: {p.token}"
    )
    add_signal(p.token,p.symbol,"ENTRY",p.market_cap,assessment["score"],"Сигнал входа",text,assessment)
    notify(cfg,"ENTRY",text)
    open_trade(p.token,p.symbol,p.market_cap,cfg)
    tb = cfg.get("test_bets", {})
    if tb.get("enabled", True) and tb.get("auto_open_on_entry", True):
        try:
            open_test_bet(p.token,p.symbol,p.market_cap,p.price_usd,tb.get("default_stake_usd",10),
                          source="AUTO_ENTRY",signal_score=assessment.get("score"),cfg=cfg)
        except Exception as e:
            log("WARN", f"auto test bet {p.token}: {e}")

def handle_paper_events(p, cfg):
    events = update_trade(p.token, p.market_cap, cfg)
    for e in events:
        kind = e["kind"]
        if kind == "CLOSED":
            continue
        text = (
            f"{'🔴' if kind in ['STOP','TIME_EXIT'] else '🟠' if kind=='TRAIL' else '💰'} {kind} — {p.symbol}\n"
            f"{e['text']}\nMC: {fmt_usd(p.market_cap)}\n{p.url}"
        )
        add_signal(p.token,p.symbol,kind,p.market_cap,None,kind,text,e)
        notify(cfg,kind,text)
    if any(e["kind"] == "CLOSED" for e in events):
        cooldown = now_ts() + int(cfg["strategy"]["cooldown_minutes"]*60)
        update_state(p.token, stage="COOLDOWN", exit_ts=now_ts(), cooldown_until=cooldown)
        con = connect()
        con.execute("UPDATE tokens SET stage='COOLDOWN' WHERE token=?", (p.token,))
        con.commit(); con.close()

def process_pair(p, cfg, security=None):
    upsert_pair(p, p.source)
    history = get_history(p.token, cfg)
    a = assess(p.to_dict(), history, cfg, security)
    state = ensure_state(p.token)

    if get_open_trade(p.token):
        handle_paper_events(p, cfg)
    try:
        update_open_test_bets(p.token,p.market_cap,p.price_usd,cfg)
    except Exception as e:
        log("WARN", f"test bet update {p.token}: {e}")

    if (a.get("security") or {}).get("status") == "FAIL":
        update_state(p.token, stage="AVOID")
        update_token_assessment(p.token, a, "AVOID", None)
        return

    state = ensure_state(p.token)
    if state.get("cooldown_until",0) and now_ts() < int(state["cooldown_until"]):
        update_token_assessment(p.token, a, "COOLDOWN", state.get("setup_type"))
        return
    if state.get("stage") == "COOLDOWN" and now_ts() >= int(state.get("cooldown_until") or 0):
        update_state(p.token, stage="DISCOVERED")
        state["stage"] = "DISCOVERED"

    # PRE-PUMP is intentionally emitted before ENTRY. This gives us an earlier
    # timestamp/test-bet, then a later cycle can confirm the stronger ENTRY.
    if a.get("pre_pump") and state.get("stage") in {"DISCOVERED","WATCH"}:
        emit_prepump(p, a, cfg)
        update_state(p.token, stage="PRE_PUMP", last_signal_ts=now_ts(), setup_type="PRE_PUMP_ACCELERATION")
        update_token_assessment(p.token, a, "PRE_PUMP", "PRE_PUMP_ACCELERATION")
        return

    if a["entry"] and state.get("stage") != "ENTRY" and not get_open_trade(p.token):
        emit_entry(p, a, cfg)
        update_state(p.token, stage="ENTRY", entry_ts=now_ts(), entry_mc=p.market_cap,
                     peak_mc=p.market_cap, last_signal_ts=now_ts(), setup_type=a["entry_type"])
        update_token_assessment(p.token, a, "ENTRY", a["entry_type"])
        return

    if a["watch"] and state.get("stage") == "DISCOVERED":
        emit_watch(p, a, cfg)
        update_state(p.token, stage="WATCH", watch_ts=now_ts(), last_signal_ts=now_ts())
        update_token_assessment(p.token, a, "WATCH", None)
        return

    stage = state.get("stage") or "DISCOVERED"
    update_token_assessment(p.token, a, stage, state.get("setup_type"))

def cycle():
    global SECURITY_CHECKS_THIS_CYCLE
    SECURITY_CHECKS_THIS_CYCLE = 0
    cfg = load_config()
    set_runtime("engine_status","running")
    set_runtime("heartbeat",str(now_ts()))

    source_map, errors = discover(cfg)
    max_tokens = int(cfg["app"]["max_scan_tokens"])

    # Keep open trades/manual watch items even if discovery set is large.
    priority = [a for a,s in source_map.items() if s in {"paper_open","test_bet_open","manual_watch"}]
    rest = [a for a in source_map if a not in priority]
    addresses = (priority + rest)[:max_tokens]
    pairs = fetch_tokens(addresses, source_map)
    pairs = enrich_pairs(pairs, addresses, source_map)

    # First pass ranks candidates without spending GMGN security calls.
    ranked = []
    for p in pairs:
        m = market_score(p.to_dict(), cfg)
        ranked.append((m["base_score"], p, m))
    ranked.sort(key=lambda x: x[0], reverse=True)

    security_map = {}
    ready, _ = gmgn_ready()
    if cfg["discovery"].get("gmgn_enabled", True) and ready:
        threshold = float(cfg["strategy"]["security_check_score"])
        for base_score, p, m in ranked:
            if base_score < threshold:
                continue
            ev = get_security_cached(p.token, cfg, allow_fetch=True)
            if ev:
                security_map[p.token] = ev
            if SECURITY_CHECKS_THIS_CYCLE >= int(cfg["gmgn"]["max_security_checks_per_cycle"]):
                break

    for _, p, _ in ranked:
        sec = security_map.get(p.token) or get_security_cached(p.token, cfg, allow_fetch=False)
        try:
            process_pair(p, cfg, sec)
        except Exception as e:
            log("ERROR", f"process {p.token}: {e}\n{traceback.format_exc()[-1200:]}")

    for e in errors:
        log("WARN", e)

    prune(cfg)
    set_runtime("last_cycle_summary", json.dumps({
        "ts": now_ts(), "discovered": len(source_map), "fetched": len(pairs),
        "gmgn_ready": ready, "security_checks": SECURITY_CHECKS_THIS_CYCLE
    }, ensure_ascii=False))
    set_runtime("heartbeat",str(now_ts()))

def main():
    init_db()
    write_pid()
    signal.signal(signal.SIGINT, cleanup)
    try:
        signal.signal(signal.SIGTERM, cleanup)
    except Exception:
        pass
    log("INFO","Engine started")
    while True:
        cfg = load_config()
        started = time.time()
        try:
            cycle()
        except KeyboardInterrupt:
            cleanup()
        except Exception as e:
            log("ERROR", f"cycle: {e}\n{traceback.format_exc()[-1800:]}")
            set_runtime("engine_status","error")
        elapsed = time.time()-started
        wait = max(2, int(cfg["app"]["scan_interval_seconds"]) - elapsed)
        time.sleep(wait)

if __name__ == "__main__":
    main()
